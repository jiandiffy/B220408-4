<template>
  <div class="row">
    <div class="column left">
      <h1 class="proposition primary--text">家庭财务管理系统</h1>

      <p class="details">
        随时添加记录，分析收入和支出，查看个人消费，预算预警，年度财务报告等等...
      </p>

      <v-btn
        color="secondary"
        large
        class="cto"
        rounter
        to="/register"
        elevation="4"
      >
        <v-icon left>mdi-account-plus-outline</v-icon>
        注册
      </v-btn>
    </div>

    <div class="column right">
      <img
        src="/landing.svg"
        alt="Image of person analyzing finance."
        class="landing-img"
      />
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component
export default class Landing extends Vue {}
</script>

<style scoped>
.row {
  display: flex;
  height: calc(100vh - 4rem);
}

.column {
  width: 50%;
  display: flex;
  flex-direction: column;
}

.column.left {
  margin-top: 10%;
}

.column.right {
  justify-content: center;
  align-items: center;
}

.proposition {
  font-size: 5rem;
  line-height: 1.3;
}

.details {
  font-size: 1.5rem;
  margin-top: 2rem;
  margin-bottom: 2rem;
}

.cto {
  width: 12rem;
}

.landing-img {
  height: 35rem;
}

@media only screen and (max-width: 1200px) {
  .row {
    flex-direction: column;
    height: auto;
    min-height: calc(100vh - 4rem);
    justify-content: flex-end;
  }

  .column {
    width: 100%;
    margin-top: 3rem;
  }

  .column.left {
    margin-top: 4rem;
    order: 2;
  }

  .landing-img {
    height: 25rem;
  }

  .proposition {
    font-size: 4rem;
  }
}

@media only screen and (max-width: 800px) {
  .column.left {
    margin-top: 2rem;
  }

  .proposition {
    font-size: 4rem;
  }

  .details {
    font-size: 1.25rem;
    margin: 1rem auto;
  }

  .landing-img {
    height: 21rem;
  }

  .cto {
    align-self: center;
    justify-self: center;
    margin: 0 auto 0.5rem auto;
  }
}

@media only screen and (max-width: 600px) {
  .column.left,
  .column.right {
    margin-top: 1.5rem;
  }

  .proposition {
    font-size: 3rem;
  }

  .details {
    font-size: 1rem;
  }
}

@media only screen and (max-width: 500px) {
  .cto {
    width: 100%;
  }
}

@media only screen and (max-width: 400px) {
  .proposition {
    font-size: 2.5rem;
  }
}

@media only screen and (max-width: 420px) and (max-height: 740px) {
  .proposition {
    font-size: 2.25rem;
  }
}

@media only screen and (min-height: 1000px) {
  .cto {
    margin-bottom: 8rem;
  }
}
</style>
