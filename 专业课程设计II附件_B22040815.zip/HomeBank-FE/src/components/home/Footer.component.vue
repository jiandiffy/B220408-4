<template>
  <footer>
    <ul class="max-width">
      <li><a href="#start">首页</a></li>
      <li><a href="#about">关于</a></li>
    </ul>
  </footer>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component
export default class Footer extends Vue {}
</script>

<style scoped>
footer {
  background: linear-gradient(135deg, #22577a 0%, #38a3a5 100%);
  width: 100%;
  padding: 2rem 0;
}

ul {
  padding: 0;
  width: 100%;
  list-style: none;
  display: flex;
  gap: 3rem;
}

ul li a {
  text-decoration: none;
  color: white;
  font-weight: 500;
  font-size: 1.1rem;
  transition: color 0.3s ease;
}

ul li a:hover {
  color: #c7f9cc;
  text-decoration: underline;
}

@media only screen and (max-width: 960px) {
  ul {
    justify-content: center;
  }
}
</style>
