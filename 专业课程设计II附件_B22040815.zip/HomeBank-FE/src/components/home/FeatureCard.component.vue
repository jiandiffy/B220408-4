<template>
  <v-card class="card" :color="content.color" elevation="8">
    <v-card-title class="card-title">
      <v-icon large :color="content.iconColor" class="mr-2">{{
        content.icon
      }}</v-icon>
      {{ content.title }}
    </v-card-title>
    <v-card-text class="card-text">{{ content.text }}</v-card-text>
  </v-card>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

interface FeatureCardContent {
  title: string;
  text: string;
  icon: string;
  color?: string;
  iconColor?: string;
}

@Component
export default class FeatureCard extends Vue {
  @Prop({ required: true }) content!: FeatureCardContent;
}

export { FeatureCardContent };
</script>

<style scoped>
.card {
  padding: 1.5rem;
  width: 25rem;
  transition: transform 0.3s ease;
}

.card:hover {
  transform: translateY(-8px);
}

.card-title {
  font-size: 1.5rem;
  font-weight: bold;
  display: flex;
  align-items: center;
  margin-bottom: 0.5rem;
}

.card-text {
  font-size: 1rem;
  line-height: 1.6;
}

@media only screen and (max-width: 925px) {
  .card {
    width: 100%;
  }
}
</style>
