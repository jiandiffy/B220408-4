<template>
  <section id="about" class="about-section">
    <h2 class="about-title">关于</h2>
    <p class="about-text">
      HomeBank
      是一款简单的个人财务管理应用。可以追踪收入和支出，分析记录并通过图表可视化展示。可以创建多个账户，向这些账户添加交易，并将它们分类到各种类别中。
    </p>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component
export default class AboutSection extends Vue {}
</script>

<style scoped>
.about-section {
  padding: 5rem 2rem;
  background: linear-gradient(135deg, #c7f9cc 0%, #80ed99 100%);
  border-radius: 20px;
  margin-top: 4rem;
}

.about-title {
  font-size: 3rem;
  font-weight: bolder;
  margin-bottom: 2rem;
  color: #22577a;
}

.about-text {
  max-width: 50rem;
  font-size: 1.25rem;
  line-height: 175%;
  color: #22577a;
}

.about-text.highlight {
  font-weight: 600;
  color: #22577a;
  background: rgba(255, 255, 255, 0.5);
  padding: 1rem;
  border-radius: 10px;
  border-left: 4px solid #38a3a5;
}

@media only screen and (max-width: 400px) {
  .about-section {
    padding: 3rem 1rem;
  }

  .about-title {
    font-size: 2rem;
  }
}
</style>
