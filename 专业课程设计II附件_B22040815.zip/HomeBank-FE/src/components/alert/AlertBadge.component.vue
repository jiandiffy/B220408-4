<template>
  <v-badge :content="unreadCount" :value="unreadCount > 0" color="red" overlap>
    <v-icon>mdi-bell</v-icon>
  </v-badge>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component
export default class AlertBadge extends Vue {
  get unreadCount(): number {
    return this.$store.getters["alert/unreadCount"];
  }

  mounted(): void {
    this.$store.dispatch("alert/fetchUnreadCount");
    this.$store.dispatch("alert/startPolling");
  }

  beforeDestroy(): void {
    this.$store.dispatch("alert/stopPolling");
  }
}
</script>
