<template>
  <v-card class="mb-3" :class="{ unread: !alert.isRead }">
    <v-card-text>
      <v-row align="center">
        <v-col cols="auto">
          <v-icon :color="alertColor" large>
            {{ alertIcon }}
          </v-icon>
        </v-col>
        <v-col>
          <div class="text-body-1 font-weight-medium">
            {{ alert.message }}
          </div>
          <div class="text-caption text--secondary">
            {{ formatDate(alert.createdAt) }}
          </div>
        </v-col>
        <v-col cols="auto">
          <v-btn
            v-if="!alert.isRead"
            icon
            small
            @click="$emit('mark-read', alert.id)"
          >
            <v-icon small>mdi-check</v-icon>
          </v-btn>
          <v-btn icon small @click="$emit('delete', alert.id)">
            <v-icon small>mdi-delete</v-icon>
          </v-btn>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { Alert } from "@/api/alertApi";
import { formatDate } from "@/utils/formatDate";

@Component
export default class AlertCard extends Vue {
  @Prop({ required: true }) alert!: Alert;

  get alertColor(): string {
    return this.alert.type === "BUDGET_EXCEEDED" ? "red" : "orange";
  }

  get alertIcon(): string {
    return this.alert.type === "BUDGET_EXCEEDED"
      ? "mdi-alert-circle"
      : "mdi-alert";
  }

  formatDate(date: string): string {
    return formatDate(date);
  }
}
</script>

<style scoped>
.unread {
  border-left: 4px solid #1976d2;
}
</style>
