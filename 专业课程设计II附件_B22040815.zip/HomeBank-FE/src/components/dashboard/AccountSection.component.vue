<template>
  <section>
    <div class="heading-and-button">
      <h1 class="main primary--text">仪表板</h1>

      <v-btn
        color="secondary"
        @click="$router.push('/accounts/create')"
        elevation="4"
      >
        <v-icon left>mdi-plus</v-icon>
        <span>添加账户</span>
      </v-btn>
    </div>

    <div>
      <div v-if="accounts.length > 0 || accountsLoading" class="accounts">
        <div v-if="!accountsLoading">
          <AccountCard
            v-for="account in accounts"
            :key="account.id"
            :account="account"
          />
        </div>

        <div v-else>
          <v-skeleton-loader
            v-for="i in 3"
            :key="'account-loader' + i"
            type="image"
            class="skeleton"
          />
        </div>
      </div>

      <div v-else class="bigger-text">您还没有创建任何账户！</div>
    </div>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import AccountApi, { Account } from "@/api/accountApi";
import errorMessage from "@/services/errorMessage";
import { Action, Getter } from "vuex-class";
import AccountCard from "@/components/dashboard/AccountCard.component.vue";

@Component({
  components: { AccountCard },
})
export default class AccountsSection extends Vue {
  accounts = [] as Account[];
  accountsLoading = false;

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      return;
    }

    this.accountsLoading = true;
    AccountApi.getAll(this.familyId, true)
      .then((response) => (this.accounts = response.data))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.accountsLoading = false));
  }
}
</script>

<style scoped>
.accounts > div {
  display: flex;
  justify-content: flex-start;
  align-items: flex-end;
  gap: 2rem;
  flex-wrap: wrap;
}

.skeleton {
  width: 20rem;
  height: 11.25rem;
}

@media only screen and (max-width: 750px) {
  .accounts > div {
    flex-direction: column;
    align-items: center;
  }
}
</style>
