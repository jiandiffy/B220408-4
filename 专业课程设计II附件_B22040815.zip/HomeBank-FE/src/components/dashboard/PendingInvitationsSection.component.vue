<template>
  <v-alert
    v-if="invitations.length > 0"
    type="info"
    border="left"
    colored-border
    elevation="2"
    class="mb-4"
  >
    <v-row align="center">
      <v-col cols="12">
        <div class="text-h6 mb-2">
          <v-icon left>mdi-email-outline</v-icon>
          您有 {{ invitations.length }} 个待处理的家庭邀请
        </div>
      </v-col>
    </v-row>

    <v-list class="transparent">
      <v-list-item
        v-for="invitation in invitations"
        :key="invitation.id"
        class="px-0"
      >
        <v-list-item-content>
          <v-list-item-title class="font-weight-medium">
            邀请加入家庭: {{ invitation.familyName }}
          </v-list-item-title>
          <v-list-item-subtitle>
            角色:
            {{ invitation.role === "FAMILY_ADMIN" ? "家庭管理员" : "家庭成员" }}
            | 过期时间: {{ formatDate(invitation.expiresAt) }}
          </v-list-item-subtitle>
        </v-list-item-content>
        <v-list-item-action>
          <div class="d-flex gap-2">
            <v-btn
              small
              color="success"
              :loading="accepting === invitation.id"
              @click="acceptInvitation(invitation)"
            >
              接受
            </v-btn>
            <v-btn
              small
              outlined
              color="error"
              :loading="rejecting === invitation.id"
              @click="rejectInvitation(invitation)"
            >
              拒绝
            </v-btn>
          </div>
        </v-list-item-action>
      </v-list-item>
    </v-list>
  </v-alert>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import InvitationApi, { FamilyInvitation } from "@/api/invitationApi";
import { formatDate } from "@/utils/formatDate";
import { ErrorHandler } from "@/utils/errorHandler";

@Component
export default class PendingInvitationsSection extends Vue {
  invitations: FamilyInvitation[] = [];
  accepting: number | null = null;
  rejecting: number | null = null;

  async mounted(): Promise<void> {
    await this.loadInvitations();
  }

  async loadInvitations(): Promise<void> {
    try {
      const response = await InvitationApi.getMyInvitations();
      this.invitations = response.data;
    } catch (error) {
      console.error("Failed to load invitations:", error);
    }
  }

  async acceptInvitation(invitation: FamilyInvitation): Promise<void> {
    try {
      this.accepting = invitation.id;
      await InvitationApi.acceptInvitation(
        invitation.familyId,
        invitation.token
      );

      this.$store.dispatch("snackbar/showSnack", {
        text: "邀请已接受，正在刷新页面...",
        color: "success",
      });

      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      console.error("Failed to accept invitation:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
      this.accepting = null;
    }
  }

  async rejectInvitation(invitation: FamilyInvitation): Promise<void> {
    try {
      this.rejecting = invitation.id;
      await InvitationApi.rejectInvitation(
        invitation.familyId,
        invitation.token
      );

      this.$store.dispatch("snackbar/showSnack", {
        text: "邀请已拒绝",
        color: "success",
      });

      this.invitations = this.invitations.filter(
        (inv) => inv.id !== invitation.id
      );
    } catch (error) {
      console.error("Failed to reject invitation:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.rejecting = null;
    }
  }

  formatDate(date: string): string {
    return formatDate(date);
  }
}
</script>

<style scoped>
.gap-2 {
  gap: 8px;
}
</style>
