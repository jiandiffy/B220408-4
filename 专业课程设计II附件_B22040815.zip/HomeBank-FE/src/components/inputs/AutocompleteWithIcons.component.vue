<template>
  <div class="row">
    <v-autocomplete
      v-model="selectedItem"
      :items="items"
      item-text="name"
      item-value="id"
      :label="label"
      :prepend-icon="prependIcon ?? ''"
      :loading="itemsLoading"
      :rules="required ? requiredRule : []"
      :clearable="clearable"
      class="my-input"
    >
      <template #selection="{ item }">
        <v-icon :color="item.color" class="mr-2">{{ item.icon }}</v-icon>
        {{ item.name }}
      </template>

      <template #item="{ item, attrs, on }">
        <v-list-item v-bind="attrs" v-on="on">
          <v-icon :color="item.color" class="mr-2">{{ item.icon }}</v-icon>
          {{ item.name }}
        </v-list-item>
      </template>
    </v-autocomplete>
  </div>
</template>

<script lang="ts">
import { Component, VModel, Vue, Prop } from "vue-property-decorator";
import categoryApi from "@/api/categoryApi";
import accountApi from "@/api/accountApi";
import errorMessage from "@/services/errorMessage";
import { Action, Getter } from "vuex-class";

interface IconItem {
  id: number;
  icon: string;
  name: string;
}

enum ItemsType {
  CATEGORY,
  ACCOUNT,
}

@Component
export default class AutocompleteWithIcons extends Vue {
  @VModel({ type: Number }) selectedItem: number | undefined;

  @Prop({ required: true }) itemsType!: ItemsType;
  @Prop({ default: false }) clearable!: boolean;
  @Prop({ default: "" }) label!: string;
  @Prop({ default: false }) required!: boolean;
  @Prop({ default: "" }) prependIcon!: string;

  items = [] as IconItem[];
  itemsLoading = false;

  requiredRule = [
    (value: number): boolean | string => {
      return !!value || value === 0 || "此项为必填项";
    },
  ];

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    switch (this.itemsType) {
      case ItemsType.ACCOUNT:
        this.getAccounts();
        break;
      case ItemsType.CATEGORY:
        this.getCategories();
        break;
    }
  }

  getCategories(): void {
    this.itemsLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.itemsLoading = false;
      return;
    }
    categoryApi
      .getAll(this.familyId)
      .then((response) => (this.items = response.data))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.itemsLoading = false));
  }

  getAccounts(): void {
    this.itemsLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.itemsLoading = false;
      return;
    }
    accountApi
      .getAll(this.familyId)
      .then((response) => (this.items = response.data))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.itemsLoading = false));
  }
}

export { ItemsType };
</script>

<style scoped>
.my-input {
  padding: 0;
  margin: 0;
  width: 100%;
}
</style>
