<template>
  <v-card class="mb-3">
    <v-card-title>
      <v-icon color="primary" left> mdi-wallet </v-icon>
      {{ budget.categoryName }}
      <v-spacer></v-spacer>
      <v-chip small :color="statusColor" text-color="white">
        {{ budget.period }}
      </v-chip>
    </v-card-title>

    <v-card-text>
      <div class="text-h6 mb-2">
        {{ formatCurrency(budget.amount) }}
      </div>

      <BudgetProgressBar
        v-if="budgetStatus"
        :used="budgetStatus.spentAmount"
        :total="budgetStatus.budgetAmount"
        :percentage="budgetStatus.usagePercentage"
      />

      <v-row class="mt-2" dense>
        <v-col cols="6">
          <div class="text-caption text--secondary">已使用</div>
          <div class="text-body-2">
            {{ budgetStatus ? formatCurrency(budgetStatus.spentAmount) : "-" }}
          </div>
        </v-col>
        <v-col cols="6">
          <div class="text-caption text--secondary">剩余</div>
          <div class="text-body-2">
            {{
              budgetStatus ? formatCurrency(budgetStatus.remainingAmount) : "-"
            }}
          </div>
        </v-col>
      </v-row>

      <div v-if="budgetStatus" class="mt-2">
        <v-chip
          v-if="budgetStatus.isExceeded"
          color="red"
          small
          text-color="white"
        >
          <v-icon left small>mdi-alert-circle</v-icon>
          已超支
        </v-chip>
        <v-chip
          v-else-if="budgetStatus.isWarning"
          color="orange"
          small
          text-color="white"
        >
          <v-icon left small>mdi-alert</v-icon>
          接近上限 ({{ budgetStatus.usagePercentage.toFixed(0) }}%)
        </v-chip>
        <v-chip v-else color="green" small text-color="white">
          <v-icon left small>mdi-check</v-icon>
          正常 ({{ budgetStatus.usagePercentage.toFixed(0) }}%)
        </v-chip>
      </div>
    </v-card-text>

    <v-card-actions v-if="showActions">
      <v-btn text @click="$emit('view-details', budget.id)">详情</v-btn>
      <v-btn text @click="$emit('edit', budget.id)" v-if="isFamilyAdmin"
        >编辑</v-btn
      >
      <v-spacer></v-spacer>
      <v-btn icon @click="$emit('delete', budget.id)" v-if="isFamilyAdmin">
        <v-icon>mdi-delete</v-icon>
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { Budget, BudgetStatus } from "@/api/budgetApi";
import BudgetProgressBar from "./BudgetProgressBar.component.vue";

@Component({
  components: {
    BudgetProgressBar,
  },
})
export default class BudgetCard extends Vue {
  @Prop({ required: true }) budget!: Budget;
  @Prop({ default: null }) budgetStatus!: BudgetStatus | null;
  @Prop({ default: true }) showActions!: boolean;

  get isFamilyAdmin(): boolean {
    return this.$store.getters["user/isFamilyAdmin"];
  }

  get statusColor(): string {
    if (!this.budgetStatus) return "grey";
    if (this.budgetStatus.isExceeded) return "red";
    if (this.budgetStatus.isWarning) return "orange";
    return "green";
  }

  formatCurrency(amount: number | null | undefined): string {
    if (amount === null || amount === undefined) return "-";
    const currency = this.$store.getters["user/currency"] || "CNY";
    try {
      return new Intl.NumberFormat("zh-CN", {
        style: "currency",
        currency: currency,
      }).format(amount);
    } catch (error) {
      console.error("Currency formatting error:", error);
      return `${currency} ${amount}`;
    }
  }
}
</script>
