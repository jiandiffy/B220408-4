<template>
  <div class="container">
    <h2
      v-if="!totalAnalyticLoading && totalAnalytic"
      class="main primary--text"
    >
      年度财务报告
    </h2>
    <div v-if="!totalAnalyticLoading && totalAnalytic" class="content">
      <div class="core-metrics-banner">
        <div class="metric-card savings-card">
          <div class="metric-icon">
            <v-icon size="50" color="white">mdi-piggy-bank</v-icon>
          </div>
          <div class="metric-content">
            <span class="metric-title">储蓄率</span>
            <span class="metric-main-value">{{ savingsRate.toFixed(1) }}%</span>
            <span class="metric-subtitle">{{ savingsRateDescription }}</span>
          </div>
        </div>

        <div class="metric-card cashflow-card">
          <div class="metric-icon">
            <v-icon size="50" color="white">{{ cashFlowIcon }}</v-icon>
          </div>
          <div class="metric-content">
            <span class="metric-title">现金流</span>
            <span class="metric-main-value"
              >{{ totalAnalytic.cashFlow.toFixed(2) }}
              {{ totalAnalytic.currency }}</span
            >
            <span class="metric-subtitle">{{ cashFlowStatus }}</span>
          </div>
        </div>

        <div class="metric-card balance-card">
          <div class="metric-icon">
            <v-icon size="50" color="white">mdi-wallet</v-icon>
          </div>
          <div class="metric-content">
            <span class="metric-title">总余额</span>
            <span class="metric-main-value"
              >{{ totalAnalytic.balance.toFixed(2) }}
              {{ totalAnalytic.currency }}</span
            >
            <span class="metric-subtitle">当前可用资金</span>
          </div>
        </div>
      </div>

      <div class="middle-section">
        <div class="comparison-card">
          <h3>收支对比</h3>
          <div class="comparison-circles">
            <div class="circle-item income-circle">
              <div class="circle-content">
                <v-icon size="40" color="#80ed99">mdi-trending-up</v-icon>
                <span class="circle-label">收入</span>
                <span class="circle-value">
                  {{ totalAnalytic.incomes.toFixed(2) }}
                </span>
                <span class="circle-currency">{{
                  totalAnalytic.currency
                }}</span>
              </div>
            </div>

            <div class="vs-divider">VS</div>

            <div class="circle-item expense-circle">
              <div class="circle-content">
                <v-icon size="40" color="#ff6b6b">mdi-trending-down</v-icon>
                <span class="circle-label">支出</span>
                <span class="circle-value">
                  {{ Math.abs(totalAnalytic.expenses).toFixed(2) }}
                </span>
                <span class="circle-currency">{{
                  totalAnalytic.currency
                }}</span>
              </div>
            </div>
          </div>
          <div class="comparison-result">
            <span class="result-label">结余：</span>
            <span
              class="result-value"
              :style="{
                color: totalAnalytic.cashFlow >= 0 ? '#57cc99' : '#ff6b6b',
              }"
            >
              {{ totalAnalytic.cashFlow >= 0 ? "+" : ""
              }}{{ totalAnalytic.cashFlow.toFixed(2) }}
              {{ totalAnalytic.currency }}
            </span>
          </div>
        </div>

        <div class="monthly-cards">
          <h3>月均数据分析</h3>
          <div class="monthly-grid">
            <div class="monthly-card income-monthly">
              <v-icon size="35" color="white">mdi-cash-plus</v-icon>
              <span class="monthly-label">月均收入</span>
              <span class="monthly-value">
                {{ monthlyAverageIncome.toFixed(2) }}
              </span>
              <span class="monthly-currency">{{ totalAnalytic.currency }}</span>
            </div>

            <div class="monthly-card expense-monthly">
              <v-icon size="35" color="white">mdi-cash-minus</v-icon>
              <span class="monthly-label">月均支出</span>
              <span class="monthly-value">
                {{ monthlyAverageExpense.toFixed(2) }}
              </span>
              <span class="monthly-currency">{{ totalAnalytic.currency }}</span>
            </div>

            <div
              class="monthly-card savings-monthly"
              :class="monthlyAverageSavings >= 0 ? 'positive' : 'negative'"
            >
              <v-icon size="35" color="white">mdi-chart-line-variant</v-icon>
              <span class="monthly-label">月均储蓄</span>
              <span class="monthly-value">
                {{ monthlyAverageSavings >= 0 ? "+" : ""
                }}{{ monthlyAverageSavings.toFixed(2) }}
              </span>
              <span class="monthly-currency">{{ totalAnalytic.currency }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      v-else-if="!totalAnalyticLoading && !totalAnalytic"
      class="bigger-text"
    >
      暂无数据
    </div>
    <v-skeleton-loader v-else type="image" class="skeleton" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import userApi, { TotalAnalytic } from "@/api/userApi";
import { Action, Getter } from "vuex-class";
import errorMessage from "@/services/errorMessage";
import getDateIntervalApiParameters from "@/utils/dateIntervalApiParameters";

@Component
export default class AnnualFinancialReport extends Vue {
  @Prop({ default: () => [] }) dateInterval!: string[];
  @Prop({ default: null }) scopeUserId!: number | null;

  totalAnalyticLoading = false;
  totalAnalytic = null as null | TotalAnalytic;

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    this.getTotalAnalytic();
  }

  getTotalAnalytic() {
    this.totalAnalyticLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.totalAnalyticLoading = false;
      return;
    }

    const parameters = getDateIntervalApiParameters(this.dateInterval);
    if (this.scopeUserId !== null) {
      parameters.push({ name: "scope_user_id", value: this.scopeUserId });
    }

    userApi
      .getTotalAnalytic(this.familyId, parameters)
      .then((response) => (this.totalAnalytic = response.data))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.totalAnalyticLoading = false));
  }

  get savingsRate(): number {
    if (!this.totalAnalytic || this.totalAnalytic.incomes === 0) {
      return 0;
    }
    return (this.totalAnalytic.cashFlow / this.totalAnalytic.incomes) * 100;
  }

  get savingsRateColor(): string {
    if (this.savingsRate >= 30) return "success";
    if (this.savingsRate >= 10) return "warning";
    return "error";
  }

  get savingsRateClass(): string {
    if (this.savingsRate >= 30) return "success--text";
    if (this.savingsRate >= 10) return "warning--text";
    return "error--text";
  }

  get savingsRateDescription(): string {
    if (this.savingsRate >= 30) return "优秀！保持良好的储蓄习惯";
    if (this.savingsRate >= 10) return "不错，可以继续优化支出";
    if (this.savingsRate >= 0) return "储蓄率偏低，建议控制开支";
    return "支出超过收入，需要立即调整";
  }

  get expensePercentage(): number {
    if (!this.totalAnalytic || this.totalAnalytic.incomes === 0) {
      return 0;
    }
    return (
      (Math.abs(this.totalAnalytic.expenses) / this.totalAnalytic.incomes) * 100
    );
  }

  get cashFlowIcon(): string {
    if (!this.totalAnalytic) return "mdi-cash";
    return this.totalAnalytic.cashFlow >= 0
      ? "mdi-trending-up"
      : "mdi-trending-down";
  }

  get cashFlowIconColor(): string {
    if (!this.totalAnalytic) return "grey";
    return this.totalAnalytic.cashFlow >= 0 ? "success" : "error";
  }

  get cashFlowStatus(): string {
    if (!this.totalAnalytic) return "";
    return this.totalAnalytic.cashFlow >= 0 ? "盈余" : "赤字";
  }

  get balanceIconColor(): string {
    if (!this.totalAnalytic) return "grey";
    if (this.totalAnalytic.balance >= 10000) return "success";
    if (this.totalAnalytic.balance >= 1000) return "info";
    return "warning";
  }

  get monthsCount(): number {
    if (this.dateInterval.length !== 2) return 12;
    const start = new Date(this.dateInterval[0]);
    const end = new Date(this.dateInterval[1]);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(1, Math.ceil(diffDays / 30));
  }

  get monthlyAverageIncome(): number {
    if (!this.totalAnalytic) return 0;
    return this.totalAnalytic.incomes / this.monthsCount;
  }

  get monthlyAverageExpense(): number {
    if (!this.totalAnalytic) return 0;
    return Math.abs(this.totalAnalytic.expenses) / this.monthsCount;
  }

  get monthlyAverageSavings(): number {
    if (!this.totalAnalytic) return 0;
    return this.totalAnalytic.cashFlow / this.monthsCount;
  }

  @Watch("dateInterval")
  onDateIntervalChange(): void {
    if (this.dateInterval.length === 2) {
      this.getTotalAnalytic();
    }
  }

  @Watch("scopeUserId")
  onScopeUserIdChange(): void {
    this.getTotalAnalytic();
  }
}
</script>

<style scoped>
.container {
  width: 100%;
  padding: 2rem;
}

.content {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

h2 {
  text-align: center;
  margin-bottom: 2rem;
  font-size: 2rem;
}

h3 {
  font-size: 1.3rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
  color: #22577a;
}

.core-metrics-banner {
  display: flex;
  gap: 1.5rem;
  justify-content: space-between;
}

.metric-card {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 2rem;
  border-radius: 20px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease;
}

.metric-card:hover {
  transform: translateY(-5px);
}

.savings-card {
  background: linear-gradient(135deg, #57cc99 0%, #38a3a5 100%);
}

.cashflow-card {
  background: linear-gradient(135deg, #38a3a5 0%, #22577a 100%);
}

.balance-card {
  background: linear-gradient(135deg, #80ed99 0%, #57cc99 100%);
}

.metric-icon {
  background: rgba(255, 255, 255, 0.2);
  padding: 1rem;
  border-radius: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.metric-content {
  display: flex;
  flex-direction: column;
  color: white;
}

.metric-title {
  font-size: 0.9rem;
  opacity: 0.9;
  margin-bottom: 0.5rem;
}

.metric-main-value {
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 0.3rem;
}

.metric-subtitle {
  font-size: 0.85rem;
  opacity: 0.85;
}

.middle-section {
  display: flex;
  gap: 2rem;
}

.comparison-card {
  flex: 1;
  background: white;
  padding: 2rem;
  border-radius: 20px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.comparison-circles {
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin: 2rem 0;
}

.circle-item {
  width: 180px;
  height: 180px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease;
}

.circle-item:hover {
  transform: scale(1.05);
}

.income-circle {
  background: linear-gradient(135deg, #c7f9cc 0%, #80ed99 100%);
}

.expense-circle {
  background: linear-gradient(135deg, #ffb3ba 0%, #ff6b6b 100%);
}

.circle-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  color: #22577a;
}

.circle-label {
  font-size: 0.9rem;
  font-weight: 500;
}

.circle-value {
  font-size: 1.5rem;
  font-weight: bold;
}

.circle-currency {
  font-size: 0.8rem;
  opacity: 0.7;
}

.vs-divider {
  font-size: 2rem;
  font-weight: bold;
  color: #22577a;
  opacity: 0.3;
}

.comparison-result {
  text-align: center;
  padding: 1.5rem;
  background: #f8f9fa;
  border-radius: 15px;
  margin-top: 1rem;
}

.result-label {
  font-size: 1.1rem;
  color: #666;
  margin-right: 0.5rem;
}

.result-value {
  font-size: 1.8rem;
  font-weight: bold;
}

.monthly-cards {
  flex: 1;
  background: white;
  padding: 2rem;
  border-radius: 20px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.monthly-grid {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.monthly-card {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  border-radius: 15px;
  color: white;
  transition: transform 0.3s ease;
}

.monthly-card:hover {
  transform: translateX(10px);
}

.income-monthly {
  background: linear-gradient(135deg, #80ed99 0%, #57cc99 100%);
}

.expense-monthly {
  background: linear-gradient(135deg, #ff8787 0%, #ff6b6b 100%);
}

.savings-monthly.positive {
  background: linear-gradient(135deg, #57cc99 0%, #38a3a5 100%);
}

.savings-monthly.negative {
  background: linear-gradient(135deg, #ffd93d 0%, #ffb800 100%);
}

.monthly-label {
  flex: 1;
  font-size: 1rem;
  opacity: 0.9;
}

.monthly-value {
  font-size: 1.5rem;
  font-weight: bold;
}

.monthly-currency {
  font-size: 0.9rem;
  opacity: 0.85;
}

.skeleton {
  width: 100%;
  height: 600px;
}

@media only screen and (max-width: 1200px) {
  .core-metrics-banner {
    flex-direction: column;
  }

  .middle-section {
    flex-direction: column;
  }
}

@media only screen and (max-width: 768px) {
  .container {
    padding: 1rem;
  }

  h2 {
    font-size: 1.5rem;
  }

  .metric-card {
    padding: 1.5rem;
  }

  .metric-main-value {
    font-size: 1.5rem;
  }

  .comparison-circles {
    flex-direction: column;
    gap: 2rem;
  }

  .vs-divider {
    transform: rotate(90deg);
  }

  .circle-item {
    width: 150px;
    height: 150px;
  }
}
</style>
