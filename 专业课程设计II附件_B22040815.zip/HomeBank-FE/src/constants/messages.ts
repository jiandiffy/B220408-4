export const ERROR_MESSAGES = {
  NETWORK_ERROR: "网络连接失败，请检查网络",
  TIMEOUT_ERROR: "请求超时，请稍后重试",

  BAD_REQUEST: "输入信息有误，请检查",
  UNAUTHORIZED: "认证失败，请重新登录",
  FORBIDDEN: "没有权限执行此操作",
  NOT_FOUND: "请求的资源不存在",
  CONFLICT: "数据冲突，请刷新后重试",
  SERVER_ERROR: "服务器错误，请稍后再试",

  LOGIN_FAILED: "登录失败，请检查邮箱和密码",
  REGISTER_FAILED: "注册失败，请检查输入信息",
  EMAIL_EXISTS: "该邮箱已被注册",
  PERMISSION_DENIED: "仅家庭管理员可访问此页面",
  INVALID_INPUT: "输入信息不完整或格式错误",

  LOAD_FAILED: "加载数据失败",
  SAVE_FAILED: "保存失败",
  DELETE_FAILED: "删除失败",
  UPDATE_FAILED: "更新失败",

  UNKNOWN_ERROR: "操作失败，请稍后重试",
};

export const SUCCESS_MESSAGES = {
  LOGIN_SUCCESS: "登录成功",
  REGISTER_SUCCESS: "注册成功",
  LOGOUT_SUCCESS: "已登出",

  BUDGET_CREATED: "预算创建成功",
  BUDGET_UPDATED: "预算更新成功",
  BUDGET_DELETED: "预算已删除",

  MEMBER_ADDED: "成员添加成功",
  MEMBER_REMOVED: "成员已移除",
  MEMBER_UPDATED: "成员信息已更新",

  ALERT_MARKED_READ: "已标记为已读",
  ALERT_DELETED: "预警已删除",

  SAVE_SUCCESS: "保存成功",
  UPDATE_SUCCESS: "更新成功",
  DELETE_SUCCESS: "删除成功",
};

export const VALIDATION_MESSAGES = {
  REQUIRED: "此项为必填项",
  EMAIL_INVALID: "邮箱格式不正确",
  PASSWORD_MIN_LENGTH: "密码至少需要6个字符",
  PASSWORD_MAX_LENGTH: "密码不能超过50个字符",
  CURRENCY_INVALID: "货币代码必须是3个大写字母（如CNY, USD）",
  NAME_MIN_LENGTH: "名称至少需要2个字符",
  NAME_MAX_LENGTH: "名称不能超过50个字符",
  AMOUNT_POSITIVE: "金额必须大于0",
  DATE_INVALID: "日期格式不正确",
};
