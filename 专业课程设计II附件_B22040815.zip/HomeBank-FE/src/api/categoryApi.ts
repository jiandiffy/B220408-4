import API, { ApiParameter } from "@/api/api";
import { AxiosResponse as Response } from "axios";

interface Category {
  id: number;
  familyId: number;
  name: string;
  type: "INCOME" | "EXPENSE";
  icon: string;
  color: string;
  isCustom: boolean;
}

interface CategoryAnalytic {
  category: Category;
  amount: number;
  numberOfRecords: number;
}

const categoryApi = {
  API: API.getInstance(),

  getAll(familyId: number): Promise<Response<Category[]>> {
    return this.API.get(`/families/${familyId}/categories`);
  },

  getAnalytic(
    familyId: number,
    parameters = [] as ApiParameter[]
  ): Promise<Response<CategoryAnalytic[]>> {
    return this.API.get(
      `/families/${familyId}/categories/analytics`,
      parameters
    );
  },

  create(
    familyId: number,
    category: Omit<Category, "id" | "familyId" | "isCustom">
  ): Promise<Response<Category>> {
    return this.API.post(`/families/${familyId}/categories`, category);
  },

  update(
    familyId: number,
    categoryId: number,
    category: Partial<Category>
  ): Promise<Response<Category>> {
    return this.API.put(
      `/families/${familyId}/categories/${categoryId}`,
      category
    );
  },

  delete(familyId: number, categoryId: number): Promise<Response<void>> {
    return this.API.delete(`/families/${familyId}/categories/${categoryId}`);
  },
};

export default categoryApi;
export { Category, CategoryAnalytic };
