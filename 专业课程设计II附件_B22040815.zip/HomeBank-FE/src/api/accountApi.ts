import API from "./api";
import { AxiosResponse as Response } from "axios";

type AccountPermissionType = "VISIBLE" | "EDIT";

interface AccountPermissionInfo {
  userId: number;
  userEmail: string;
  userFirstName: string;
  userLastName: string;
  permission: AccountPermissionType;
  grantedAt: string;
}

interface Account {
  id: number;
  familyId: number;
  name: string;
  currency: string;
  balance: number;
  color: string;
  icon: string;
  includeInStatistics: boolean;
  incomes: number | null;
  expenses: number | null;
  createdAt: string;
  updatedAt: string;

  currentUserPermission?: AccountPermissionType;
  permissions?: AccountPermissionInfo[];
}

interface AccountReduced {
  id: number;
  name: string;
  currency: string;
  color: string;
  icon: string;
}

interface CreateUpdateAccountRequest {
  name: string;
  type?: string;
  balance: number;
  currency: string;
  color: string;
  icon: string;
  description?: string;
  includeInStatistics: boolean;
}

const AccountApi = {
  API: API.getInstance(),

  getAll(
    familyId: number,
    withIncomesAndExpenses = false
  ): Promise<Response<Account[]>> {
    return this.API.get(`/families/${familyId}/accounts`, [
      { name: "withIncomesAndExpenses", value: withIncomesAndExpenses },
    ]);
  },

  getById(familyId: number, accountId: number): Promise<Response<Account>> {
    return this.API.get(`/families/${familyId}/accounts/${accountId}`);
  },

  createAccount(
    familyId: number,
    account: CreateUpdateAccountRequest
  ): Promise<Response<Account>> {
    return this.API.post(`/families/${familyId}/accounts`, account);
  },

  updateAccount(
    familyId: number,
    accountId: number,
    account: CreateUpdateAccountRequest
  ): Promise<Response<Account>> {
    return this.API.put(`/families/${familyId}/accounts/${accountId}`, account);
  },

  deleteAccount(familyId: number, accountId: number): Promise<Response> {
    return this.API.delete(`/families/${familyId}/accounts/${accountId}`);
  },

  getAccountPermissions(
    familyId: number,
    accountId: number
  ): Promise<Response<AccountPermissionInfo[]>> {
    return this.API.get(
      `/families/${familyId}/accounts/${accountId}/permissions`
    );
  },

  grantPermission(
    familyId: number,
    accountId: number,
    targetUserId: number,
    permissionType: AccountPermissionType
  ): Promise<Response<AccountPermissionInfo>> {
    return this.API.post(
      `/families/${familyId}/accounts/${accountId}/permissions`,
      null,
      [
        { name: "targetUserId", value: targetUserId },
        { name: "permissionType", value: permissionType },
      ]
    );
  },

  revokePermission(
    familyId: number,
    accountId: number,
    targetUserId: number
  ): Promise<Response> {
    return this.API.delete(
      `/families/${familyId}/accounts/${accountId}/permissions/${targetUserId}`
    );
  },
};

export default AccountApi;
export {
  AccountApi,
  Account,
  AccountReduced,
  CreateUpdateAccountRequest,
  AccountPermissionType,
  AccountPermissionInfo,
};
