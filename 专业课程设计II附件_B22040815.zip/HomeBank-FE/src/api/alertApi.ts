import API from "./api";
import { AxiosResponse as Response } from "axios";

interface Alert {
  id: number;
  budgetId: number;
  userId: number;
  message: string;
  type: "BUDGET_WARNING" | "BUDGET_EXCEEDED";
  thresholdPercentage: number;
  isRead: boolean;
  createdAt: string;
}

const AlertApi = {
  API: API.getInstance(),
  DOMAIN: "/alerts",

  getAll(): Promise<Response<Alert[]>> {
    return this.API.get(this.DOMAIN);
  },

  getUnread(): Promise<Response<Alert[]>> {
    return this.API.get(`${this.DOMAIN}/unread`);
  },

  markAsRead(id: number): Promise<Response> {
    return this.API.put(`${this.DOMAIN}/${id}/read`, {});
  },

  delete(id: number): Promise<Response> {
    return this.API.delete(`${this.DOMAIN}/${id}`);
  },
};

export default AlertApi;
export { AlertApi, Alert };
