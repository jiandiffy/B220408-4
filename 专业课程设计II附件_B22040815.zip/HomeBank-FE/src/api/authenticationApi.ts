import API from "@/api/api";
import { AxiosResponse as Response } from "axios";
import { User } from "@/store/modules/user";

interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;

  invitationToken?: string;

  adminEmail?: string;

  familyName?: string;

  currency?: string;
}

interface AuthenticationRequest {
  email: string;
  password: string;
}

interface AuthenticationResponse {
  token: string;
  user: User;
}

const AuthentizationApi = {
  API: API.getInstance(),
  DOMAIN: "/auth",

  register(user: RegisterRequest): Promise<Response<AuthenticationResponse>> {
    return this.API.post(this.DOMAIN + "/register", user);
  },

  login(
    request: AuthenticationRequest
  ): Promise<Response<AuthenticationResponse>> {
    return this.API.post(this.DOMAIN + "/login", request);
  },
};

export default AuthentizationApi;
export { RegisterRequest, AuthenticationRequest, AuthenticationResponse };
