import API, { ApiParameter } from "./api";
import { AxiosResponse as Response } from "axios";

interface MonthlyTrendData {
  month: string;
  income: number;
  expense: number;
}

interface TopCategory {
  id: number;
  name: string;
  icon: string;
  color: string;
  amount: number;
  percentage: number;
}

interface MemberContribution {
  userId: number;
  name: string;
  income: number;
  expense: number;
  netContribution: number;
}

interface AnnualReport {
  year: number;
  familyId: number;
  totalIncome: number;
  totalExpense: number;
  savingRate: number;
  topCategories: TopCategory[];
  monthlyTrend: MonthlyTrendData[];
  memberContributions: MemberContribution[];
}

interface MonthlyReport {
  year: number;
  month: number;
  familyId: number;
  totalIncome: number;
  totalExpense: number;
  categoryBreakdown: TopCategory[];
}

const ReportApi = {
  API: API.getInstance(),
  DOMAIN: "/reports",

  getAnnualReport(
    parameters: ApiParameter[] = []
  ): Promise<Response<AnnualReport>> {
    return this.API.get(`${this.DOMAIN}/annual`, parameters);
  },

  getMonthlyReport(
    parameters: ApiParameter[] = []
  ): Promise<Response<MonthlyReport>> {
    return this.API.get(`${this.DOMAIN}/monthly`, parameters);
  },
};

export default ReportApi;
export {
  ReportApi,
  AnnualReport,
  MonthlyReport,
  MonthlyTrendData,
  TopCategory,
  MemberContribution,
};
