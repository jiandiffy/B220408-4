import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";
import Home from "../views/Home.vue";
import store from "@/store";

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    component: () => import("../views/Dashboard.vue"),
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: "/accounts/create",
    name: "CreateAccount",
    component: () => import("../views/CreateUpdateAccount.vue"),
    meta: {
      requiresAuth: true,
    },
    props: {
      update: false,
      title: "Create account",
    },
  },
  {
    path: "/accounts/:accountId",
    name: "UpdateAccount",
    component: () => import("../views/CreateUpdateAccount.vue"),
    meta: {
      requiresAuth: true,
      title: "Update account",
    },
    props: {
      update: true,
    },
  },
  {
    path: "/records/create",
    name: "CreateRecord",
    component: () => import("../views/CreateUpdateRecord.vue"),
    meta: {
      requiresAuth: true,
    },
    props: {
      update: false,
      title: "Create record",
    },
  },
  {
    path: "/records/:recordId",
    name: "UpdateRecord",
    component: () => import("../views/CreateUpdateRecord.vue"),
    meta: {
      requiresAuth: true,
      title: "Update record",
    },
    props: {
      update: true,
    },
  },
  {
    path: "/records",
    name: "Records",
    component: () => import("../views/Records.vue"),
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: "/analytic",
    name: "Analytic",
    component: () => import("../views/Analytic.vue"),
    meta: {
      requiresAuth: true,
    },
  },

  {
    path: "/family",
    name: "FamilyManagement",
    component: () => import("../views/FamilyManagement.vue"),
    meta: {
      requiresAuth: true,
      requiresAdmin: true,
    },
  },

  {
    path: "/budgets",
    name: "Budgets",
    component: () => import("../views/Budgets.vue"),
    meta: {
      requiresAuth: true,
      requiresAdmin: true,
    },
  },
  {
    path: "/budgets/create",
    name: "CreateBudget",
    component: () => import("../views/CreateUpdateBudget.vue"),
    meta: {
      requiresAuth: true,
      requiresAdmin: true,
    },
    props: {
      update: false,
    },
  },
  {
    path: "/budgets/:budgetId",
    name: "UpdateBudget",
    component: () => import("../views/CreateUpdateBudget.vue"),
    meta: {
      requiresAuth: true,
      requiresAdmin: true,
    },
    props: {
      update: true,
    },
  },

  {
    path: "/alerts",
    name: "Alerts",
    component: () => import("../views/Alerts.vue"),
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: "/register",
    name: "Register",
    component: () => import("../views/Register.vue"),
  },
  {
    path: "/login",
    name: "Login",
    component: () => import("../views/LogIn.vue"),
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

router.beforeEach((to, from, next) => {
  if (to.path === "/login" && store.getters["user/loggedIn"]) {
    next("/dashboard");
    return;
  }

  if (
    to.matched.some((record) => record.meta.requiresAuth) &&
    !store.getters["user/loggedIn"]
  ) {
    next("/login");
    return;
  }

  if (
    to.matched.some((record) => record.meta.requiresAdmin) &&
    !store.getters["user/isFamilyAdmin"]
  ) {
    store.dispatch("snackbar/showSnack", {
      text: "仅家庭管理员可访问此页面",
      color: "error",
    });
    next("/dashboard");
    return;
  }

  next();
});

export default router;
