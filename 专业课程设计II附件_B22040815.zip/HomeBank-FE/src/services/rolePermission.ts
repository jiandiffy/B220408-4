import store from "@/store";

export const RolePermission = {
  isFamilyAdmin(): boolean {
    const user = store.getters["user/user"];
    return user && user.role === "FAMILY_ADMIN";
  },

  isFamilyMember(): boolean {
    const user = store.getters["user/user"];
    return user && user.role === "FAMILY_MEMBER";
  },

  canManageFamily(): boolean {
    return this.isFamilyAdmin();
  },

  canManageBudget(): boolean {
    return this.isFamilyAdmin();
  },

  canViewFamilyAnalytic(): boolean {
    return this.isFamilyAdmin();
  },

  canAddMember(): boolean {
    return this.isFamilyAdmin();
  },

  canRemoveMember(): boolean {
    return this.isFamilyAdmin();
  },

  canCreateCustomCategory(): boolean {
    return this.isFamilyAdmin();
  },

  requireAdmin(): void {
    if (!this.isFamilyAdmin()) {
      store.dispatch("snackbar/showSnack", {
        text: "仅家庭管理员可访问此功能",
        color: "error",
      });
      throw new Error("Permission denied: Admin role required");
    }
  },

  getFamilyId(): number | null {
    const user = store.getters["user/user"];
    return user ? user.familyId : null;
  },
};

export default RolePermission;
