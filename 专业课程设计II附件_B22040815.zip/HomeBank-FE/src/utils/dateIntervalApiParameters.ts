import { ApiParameter } from "@/api/api";
import { formatYYYYMMDD } from "@/utils/formatDate";

function getDateIntervalApiParameters(dateInterval: string[]): ApiParameter[] {
  if (dateInterval.length != 2) {
    return [];
  }

  const endInclusiveDate = new Date(dateInterval[1]);
  endInclusiveDate.setDate(endInclusiveDate.getDate() + 1);

  return [
    { name: "dateGe", value: dateInterval[0] },
    { name: "dateLt", value: formatYYYYMMDD(endInclusiveDate) },
  ];
}

export default getDateIntervalApiParameters;
