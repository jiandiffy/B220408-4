import { ERROR_MESSAGES } from "@/constants/messages";
import { AxiosError } from "axios";

export class ErrorHandler {
  static getErrorMessage(error: unknown): string {
    if (!error) {
      return ERROR_MESSAGES.UNKNOWN_ERROR;
    }

    if (this.isAxiosError(error)) {
      return this.handleAxiosError(error);
    }

    if (error instanceof Error) {
      return error.message || ERROR_MESSAGES.UNKNOWN_ERROR;
    }

    if (typeof error === "string") {
      return error;
    }

    return ERROR_MESSAGES.UNKNOWN_ERROR;
  }

  private static handleAxiosError(error: AxiosError): string {
    if (error.response) {
      const status = error.response.status;
      const data = error.response.data as { message?: string };

      if (data?.message) {
        return data.message;
      }

      switch (status) {
        case 400:
          return ERROR_MESSAGES.BAD_REQUEST;
        case 401:
          return ERROR_MESSAGES.UNAUTHORIZED;
        case 403:
          return ERROR_MESSAGES.FORBIDDEN;
        case 404:
          return ERROR_MESSAGES.NOT_FOUND;
        case 409:
          return ERROR_MESSAGES.CONFLICT;
        case 500:
        case 502:
        case 503:
        case 504:
          return ERROR_MESSAGES.SERVER_ERROR;
        default:
          return `${ERROR_MESSAGES.UNKNOWN_ERROR} (HTTP ${status})`;
      }
    }

    if (error.request) {
      if (error.code === "ECONNABORTED") {
        return ERROR_MESSAGES.TIMEOUT_ERROR;
      }
      return ERROR_MESSAGES.NETWORK_ERROR;
    }

    return error.message || ERROR_MESSAGES.UNKNOWN_ERROR;
  }

  private static isAxiosError(error: unknown): error is AxiosError {
    return (
      typeof error === "object" &&
      error !== null &&
      "isAxiosError" in error &&
      (error as AxiosError).isAxiosError === true
    );
  }

  static isAuthError(error: unknown): boolean {
    if (!this.isAxiosError(error)) return false;
    return error.response?.status === 401;
  }

  static isPermissionError(error: unknown): boolean {
    if (!this.isAxiosError(error)) return false;
    return error.response?.status === 403;
  }

  static isNetworkError(error: unknown): boolean {
    if (!this.isAxiosError(error)) return false;
    return !!error.request && !error.response;
  }

  static isServerError(error: unknown): boolean {
    if (!this.isAxiosError(error)) return false;
    const status = error.response?.status;
    return status !== undefined && status >= 500 && status < 600;
  }
}
