<template>
  <div class="max-width">
    <v-card class="form" justify="center">
      <v-form ref="form" @submit.prevent="submit">
        <v-card-text>
          <h1 class="formHeading">注册</h1>

          <v-radio-group v-model="registrationType" row class="mb-4">
            <v-radio label="创建新家庭" value="newFamily"></v-radio>
            <v-radio label="使用邀请码" value="invitation"></v-radio>
            <v-radio label="加入已有家庭" value="adminEmail"></v-radio>
          </v-radio-group>

          <v-text-field
            v-model="registerForm.firstName"
            :rules="rules.requiredAndMaxLength"
            :counter="maxLength"
            label="名字"
            placeholder="三"
            prepend-icon="mdi-account-outline"
            required
          />

          <v-text-field
            v-model="registerForm.lastName"
            :rules="rules.requiredAndMaxLength"
            :counter="maxLength"
            label="姓氏"
            placeholder="张"
            prepend-icon="mdi-account-outline"
            required
          />

          <v-text-field
            v-if="registrationType === 'invitation'"
            v-model="registerForm.invitationToken"
            :rules="rules.requiredAndMaxLength"
            :counter="maxLength"
            label="邀请码"
            placeholder="输入邀请码"
            prepend-icon="mdi-ticket-confirmation"
            required
          />

          <v-text-field
            v-if="registrationType === 'adminEmail'"
            v-model="registerForm.adminEmail"
            :rules="[...rules.requiredAndMaxLength, rules.email]"
            :counter="maxLength"
            label="管理员邮箱"
            placeholder="admin@example.com"
            prepend-icon="mdi-account-supervisor"
            required
          />

          <v-text-field
            v-if="registrationType === 'newFamily'"
            v-model="registerForm.familyName"
            :rules="rules.requiredAndMaxLength"
            :counter="maxLength"
            label="家庭名称"
            placeholder="张家"
            prepend-icon="mdi-home-group"
            required
          />

          <v-text-field
            v-if="registrationType === 'newFamily'"
            v-model="registerForm.currency"
            :rules="rules.requiredAndMaxLength"
            :counter="maxLength"
            label="货币"
            placeholder="CNY"
            prepend-icon="mdi-currency-eur"
            required
          />

          <v-text-field
            v-model="registerForm.email"
            :rules="[...rules.requiredAndMaxLength, rules.email]"
            :counter="maxLength"
            label="邮箱"
            placeholder="zhangsan@example.com"
            prepend-icon="mdi-email-outline"
            required
          />

          <v-text-field
            v-model="registerForm.password"
            :rules="[...rules.requiredAndMaxLength, rules.password]"
            :counter="maxLength"
            :type="showPassword ? 'text' : 'password'"
            label="密码"
            prepend-icon="mdi-lock-outline"
            :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
            hint="至少6个字符"
            required
            @click:append="showPassword = !showPassword"
          />

          <span>已有账号？</span>
          <router-link to="/login">立即登录</router-link>
        </v-card-text>

        <v-card-actions>
          <v-btn color="primary px-4" type="submit" :loading="formLoading">
            提交
            <v-icon right>mdi-send-outline</v-icon>
          </v-btn>
        </v-card-actions>
      </v-form>
    </v-card>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { RegisterRequest } from "@/api/authenticationApi";
import authenticationApi from "@/api/authenticationApi";
import errorMessage from "@/services/errorMessage";
import { Action, Mutation } from "vuex-class";
import { User } from "@/store/modules/user";

@Component
export default class Register extends Vue {
  registrationType = "newFamily";

  registerForm: RegisterRequest = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    invitationToken: "",
    adminEmail: "",
    familyName: "",
    currency: "",
  };

  formLoading = false;
  maxLength = 64;
  maxLengthFieldErrorMsg = "不能超过 " + this.maxLength + " 个字符";
  fieldRequiredErrorMsg = "此项为必填项";
  showPassword = false;
  emailPattern =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  rules = {
    requiredAndMaxLength: [
      (value: string): boolean | string =>
        !!value || this.fieldRequiredErrorMsg,
      (value: string): boolean | string =>
        (!!value && value.length <= this.maxLength) ||
        this.maxLengthFieldErrorMsg,
    ],
    email: (value: string): boolean | string =>
      this.emailPattern.test(value) || "邮箱格式不正确",
    password: (value: string): boolean | string =>
      (!!value && value.length >= 6) || "密码长度至少为6个字符",
  };

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;

  @Mutation("user/setTokenAndUser") setTokenAndUser!: ({
    token,
    user,
  }: {
    token: string;
    user: User;
  }) => void;

  submit(): void {
    this.formLoading = true;

    if (!(this.$refs["form"] as any)?.validate()) {
      this.formLoading = false;
      return;
    }

    const request: RegisterRequest = {
      firstName: this.registerForm.firstName,
      lastName: this.registerForm.lastName,
      email: this.registerForm.email,
      password: this.registerForm.password,
    };

    if (this.registrationType === "invitation") {
      request.invitationToken = this.registerForm.invitationToken;
    } else if (this.registrationType === "adminEmail") {
      request.adminEmail = this.registerForm.adminEmail;
    } else if (this.registrationType === "newFamily") {
      request.familyName = this.registerForm.familyName;
      request.currency = this.registerForm.currency;
    }

    authenticationApi
      .register(request)
      .then((response: any) => {
        this.setTokenAndUser({
          token: response.data.token,
          user: response.data.user,
        });
        this.$router.push("/dashboard");
      })
      .catch((error: any) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.formLoading = false));
  }
}
</script>

<style scoped>
.form {
  max-width: 40rem;
  padding: 1.5rem;
  margin: 4rem auto;
}

.formHeading {
  font-weight: normal;
  margin-bottom: 1rem;
}

@media only screen and (max-width: 500px) {
  .form {
    padding: 1rem;
  }
}
</style>
