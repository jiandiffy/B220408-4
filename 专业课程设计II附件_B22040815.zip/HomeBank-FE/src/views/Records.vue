<!-- eslint-disable vue/valid-v-slot -->
<template>
  <section class="max-width main" @keyup.enter="getRecords">
    <ConfirmationDialog
      :show.sync="showDialog"
      :label="`确定删除 '${recordToDelete?.label}' 吗？`"
      @confirm="deleteRecord"
    />

    <div class="heading-and-button">
      <h1 class="main primary--text">记录</h1>

      <v-btn
        color="secondary"
        @click="$router.push('/records/create')"
        elevation="4"
      >
        <v-icon left>mdi-plus</v-icon>
        <span>添加记录</span>
      </v-btn>
    </div>

    <v-data-table
      :items="records"
      item-key="id"
      :headers="tableHeaders"
      :loading="recordsLoading"
      :single-expand="true"
      :options.sync="pagination"
      :server-items-length="pagination.itemsLength"
      :footer-props="{ itemsPerPageOptions: [15, 20, 50] }"
      mobile-breakpoint="900"
      show-expand
      class="elevation-1 mb-8"
      @update:options="getRecords"
    >
      <template #top>
        <div class="filters">
          <div class="filter-input">
            <v-text-field
              v-model="filterValues.label"
              label="标签"
              placeholder="iPhone"
              clearable
              class="mr-0 pr-0"
              @blur="getRecords"
              hint="按回车搜索"
              @click:clear="
                filterValues.label = '';
                filterRecords();
              "
            />
          </div>

          <div class="filter-input">
            <AutocompleteWithIcons
              v-model="filterValues.categoryId"
              :items-type="itemType.CATEGORY"
              label="分类"
              class="pt-4 ma-0"
              clearable
              @input="filterRecords"
            />
          </div>

          <div class="filter-input">
            <AutocompleteWithIcons
              v-model="filterValues.accountId"
              :items-type="itemType.ACCOUNT"
              label="账户"
              class="pt-4 ma-0"
              clearable
              @input="filterRecords"
            />
          </div>

          <div class="filter-input">
            <DateIntervalPicker
              v-model="filterValues.dateInterval"
              @input="filterRecords"
            />
          </div>

          <div class="filter-input">
            <v-autocomplete
              v-model="filterValues.transactionType"
              :items="transactionTypes"
              label="收入 / 支出"
              clearable
              @input="filterRecords"
            />
          </div>

          <div class="filter-input">
            <v-autocomplete
              v-model="filterValues.userId"
              :items="familyMembers"
              item-text="displayName"
              item-value="id"
              label="成员"
              clearable
              @input="filterRecords"
            />
          </div>

          <v-tooltip top>
            <template v-slot:activator="{ on, attrs }">
              <v-icon v-bind="attrs" v-on="on" @click="resetFilterValues">
                mdi-trash-can-outline
              </v-icon>
            </template>
            <span>清除筛选</span>
          </v-tooltip>
        </div>
      </template>

      <template #item.label="{ item }">
        <span class="font-weight-bold">{{ item.label }}</span>
      </template>

      <template #item.category="{ item }">
        <ChipWithIcon :config="item.category" />
      </template>

      <template #item.account="{ item }">
        <ChipWithIcon :config="item.account" />
      </template>

      <template #item.creator="{ item }">
        <span>{{ item.userFirstName }} {{ item.userLastName }}</span>
      </template>

      <template #item.date="{ item }">
        {{ formatDateAndTime(item.date) }}
      </template>

      <template #item.amount="{ item }">
        <span
          class="font-weight-bold"
          :class="item.type === 'EXPENSE' ? 'red--text' : 'green--text'"
        >
          {{ item.type === "EXPENSE" ? "-" : "+" }}{{ item.amount.toFixed(2) }}
          {{ item.account.currency }}
        </span>
      </template>

      <template #expanded-item="{ headers, item }">
        <td :colspan="headers.length">
          <span class="font-weight-bold ml-4">备注：</span>
          {{ item.note }}
        </td>
      </template>

      <template #item.actions="{ item }">
        <v-icon
          small
          @click="
            recordToDelete = item;
            showDialog = true;
          "
          >mdi-trash-can-outline</v-icon
        >

        <v-icon
          small
          class="ml-4"
          @click="
            $router.push({
              name: 'UpdateRecord',
              params: { recordId: item.id },
            })
          "
          >mdi-pencil</v-icon
        >
      </template>
    </v-data-table>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Action, Getter } from "vuex-class";
import recordApi, { Record } from "@/api/recordApi";
import { ApiParameter } from "@/api/api";
import errorMessage from "@/services/errorMessage";
import { formatDateAndTime } from "@/utils/formatDate";
import VuetifyDataTablePagination from "@/definitions/VuetifyDataTablePagination";
import { ItemsType } from "@/components/inputs/AutocompleteWithIcons.component.vue";
import ChipWithIcon from "@/components/ChipWithIcon.component.vue";
import ConfirmationDialog from "@/components/ConfirmationDialog.component.vue";
import AutocompleteWithIcons from "@/components/inputs/AutocompleteWithIcons.component.vue";
import DateIntervalPicker from "@/components/inputs/DateIntervalPicker.component.vue";
import getDateIntervalApiParameters from "@/utils/dateIntervalApiParameters";
import FamilyApi, { User } from "@/api/familyApi";

@Component({
  components: {
    ChipWithIcon,
    ConfirmationDialog,
    AutocompleteWithIcons,
    DateIntervalPicker,
  },
})
export default class Records extends Vue {
  records = [] as Record[];
  recordsLoading = false;
  showDialog = false;
  recordToDelete = null as null | Record;
  familyMembers = [] as Array<User & { displayName: string }>;

  pagination = {
    page: 1,
    itemsPerPage: 15,
    pageCount: 1,
    itemsLength: 0,
    sortBy: ["date"],
    sortDesc: [true],
  } as VuetifyDataTablePagination;
  filterValues = {
    label: null as null | string,
    categoryId: null as null | number,
    accountId: null as null | number,
    userId: null as null | number,
    transactionType: null as null | string,
    dateInterval: [] as string[],
  };

  itemType = ItemsType;

  transactionTypeOption = {
    INCOMES: "收入",
    EXPENSES: "支出",
  };
  transactionTypes = [
    this.transactionTypeOption.INCOMES,
    this.transactionTypeOption.EXPENSES,
  ];

  tableHeaders = [
    {
      text: "",
      value: "data-table-expand",
    },
    {
      text: "标签",
      align: "start",
      value: "label",
    },
    {
      text: "分类",
      align: "start",
      sortable: false,
      value: "category",
    },
    {
      text: "账户",
      align: "start",
      sortable: false,
      value: "account",
    },
    {
      text: "创建人",
      align: "start",
      sortable: false,
      value: "creator",
    },
    {
      text: "日期",
      align: "end",
      value: "date",
    },
    {
      text: "金额",
      align: "end",
      value: "amount",
    },
    {
      text: "操作",
      value: "actions",
      sortable: false,
      align: "center",
    },
  ];

  formatDateAndTime(date: string): string {
    return formatDateAndTime(date);
  }

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    this.resetFilterValues();
    this.loadFamilyMembers();
    this.getRecords();
  }

  loadFamilyMembers(): void {
    if (!this.familyId) return;
    FamilyApi.getMembers(this.familyId)
      .then((response) => {
        this.familyMembers = response.data.map((member) => ({
          ...member,
          displayName: `${member.firstName} ${member.lastName}`,
        }));
      })
      .catch((error) => this.showSnack(errorMessage.get(error)));
  }

  getRecords(): void {
    this.recordsLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.recordsLoading = false;
      return;
    }

    recordApi
      .getAll(
        this.familyId,
        this.pagination.page - 1,
        this.pagination.itemsPerPage,
        [
          { name: "sort", value: this.sortParameterValue },
          ...this.filterParameters,
        ]
      )
      .then((response) => {
        this.records = response.data.content;
        this.pagination.page = response.data.number + 1;
        this.pagination.itemsPerPage = response.data.size;
        this.pagination.pageCount = response.data.totalPages;
        this.pagination.itemsLength = response.data.totalElements;
      })
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.recordsLoading = false));
  }

  deleteRecord(): void {
    this.recordsLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.recordsLoading = false;
      return;
    }
    if (!this.recordToDelete) {
      this.showSnack("无法删除记录，ID为空");
      return;
    }
    recordApi
      .deleteRecord(this.familyId, this.recordToDelete.id)
      .then(() => this.getRecords())
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.recordsLoading = false));
  }

  get sortParameterValue(): string {
    let sort = "date,desc";
    if (this.pagination.sortBy.length > 0) {
      sort = this.pagination.sortBy[0];
      if (this.pagination.sortDesc[0]) {
        sort += ",desc";
      }
    }
    return sort;
  }

  filterRecords(): void {
    this.pagination.page = 0;
    this.getRecords();
  }

  resetFilterValues(): void {
    this.filterValues = {
      label: null,
      categoryId: null,
      accountId: null,
      userId: null,
      transactionType: null,
      dateInterval: [],
    };
    this.filterRecords();
  }

  get filterParameters(): ApiParameter[] {
    let parameters = [];

    if (this.filterValues.dateInterval.length === 2) {
      parameters.push(
        ...getDateIntervalApiParameters(this.filterValues.dateInterval)
      );
    }

    if (
      this.filterValues.transactionType === this.transactionTypeOption.EXPENSES
    ) {
      parameters.push({
        name: "type",
        value: "EXPENSE",
      });
    } else if (
      this.filterValues.transactionType === this.transactionTypeOption.INCOMES
    ) {
      parameters.push({
        name: "type",
        value: "INCOME",
      });
    }

    if (this.filterValues.label) {
      parameters.push({ name: "label", value: this.filterValues.label });
    }

    if (this.filterValues.categoryId != null) {
      parameters.push({
        name: "categoryId",
        value: this.filterValues.categoryId,
      });
    }

    if (this.filterValues.accountId != null) {
      parameters.push({
        name: "accountId",
        value: this.filterValues.accountId,
      });
    }

    if (this.filterValues.userId != null) {
      parameters.push({
        name: "userId",
        value: this.filterValues.userId,
      });
    }

    return parameters;
  }
}
</script>

<style scoped>
.filters {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 2rem;
  padding: 1rem 2rem 0 2rem;
}

.filter-input {
  width: 100%;
}

@media only screen and (max-width: 900px) {
  .filters {
    flex-direction: column;
  }
}
</style>
