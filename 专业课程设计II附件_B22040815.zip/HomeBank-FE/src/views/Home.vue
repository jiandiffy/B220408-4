<template>
  <div>
    <section id="start" class="max-width">
      <Landing />

      <div class="cards">
        <FeatureCard
          v-for="(featureCard, index) in featureCards"
          :key="index"
          :content="featureCard"
        />
      </div>

      <AboutSection />
    </section>

    <Footer />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Landing from "@/components/home/Landing.component.vue";
import FeatureCard from "@/components/home/FeatureCard.component.vue";
import { FeatureCardContent } from "@/components/home/FeatureCard.component.vue";
import AboutSection from "@/components/home/AboutSection.component.vue";
import Footer from "@/components/home/Footer.component.vue";

@Component({
  components: { Landing, FeatureCard, AboutSection, Footer },
})
export default class Home extends Vue {
  featureCards = [
    {
      title: "交易追踪",
      text: "追踪并分类您的所有收入和支出。跟踪您的消费历史。改善您的财务健康状况，学会省钱和预算。",
      icon: "mdi-cash-multiple",
      color: "#c7f9cc",
      iconColor: "#22577a",
    },
    {
      title: "多账户管理",
      text: "为不同目的创建多个账户，如活期账户、储蓄账户、投资账户和现金账户等...",
      icon: "mdi-bank-outline",
      color: "#80ed99",
      iconColor: "#22577a",
    },
    {
      title: "数据分析",
      text: "分析您的收入、支出和现金流的财务报告。可视化按类别分类的余额变化趋势等...",
      icon: "mdi-finance",
      color: "#57cc99",
      iconColor: "#22577a",
    },
  ] as FeatureCardContent[];
}
</script>

<style scoped>
.cards {
  display: flex;
  gap: 2.5rem;
  width: 100%;
  justify-content: center;
  flex-wrap: wrap;
  margin-top: 3rem;
}

#start {
  margin-bottom: 8rem;
}

@media only screen and (max-width: 1250px) {
  .cards {
    margin-top: 8rem;
  }
}

@media only screen and (max-width: 400px) {
  .cards {
    margin-top: 4rem;
  }
}
</style>
