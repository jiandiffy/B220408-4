<template>
  <section class="max-width main">
    <ConfirmationDialog
      :show.sync="showDeleteDialog"
      :label="`确定删除 '${account.name}' 吗？`"
      @confirm="deleteAccount"
    />

    <h1 class="main">
      {{ update ? `编辑 "${account.name}"` : "创建账户" }}
    </h1>

    <v-form class="mt-8" ref="form" @submit.prevent="submit">
      <div class="row">
        <v-text-field
          v-model="account.name"
          :rules="rules.requiredAndMaxLength"
          :counter="maxLength"
          :loading="accountLoading"
          label="名称"
          placeholder="储蓄"
          prepend-icon="mdi-wallet-outline"
          class="input"
          required
        />
      </div>

      <div class="row">
        <v-text-field
          v-model="account.balance"
          :rules="rules.balance"
          :loading="accountLoading"
          label="余额"
          placeholder="1000.00"
          prepend-icon="mdi-cash"
          class="input"
          type="number"
          required
        />

        <v-text-field
          v-model="account.currency"
          :rules="rules.requiredAndMaxLength"
          :counter="maxLength"
          :loading="accountLoading"
          label="货币"
          prepend-icon="mdi-currency-eur"
          class="input"
          required
          disabled
        />
      </div>

      <div class="row">
        <ColorSelect
          v-model="account.color"
          :loading="accountLoading"
          class="input"
        />

        <IconSelect
          v-model="account.icon"
          :loading="accountLoading"
          class="input"
        />
      </div>

      <div class="row last-row">
        <v-checkbox
          v-model="account.includeInStatistics"
          label="包含在统计中"
          class="input"
        />

        <div>
          <v-btn
            v-if="update"
            :loading="deleteLoading"
            color="red"
            class="white--text ml-4"
            @click="showDeleteDialog = true"
          >
            <v-icon left>mdi-trash-can-outline</v-icon>
            删除
          </v-btn>

          <v-btn
            color="secondary"
            :loading="submitLoading"
            type="submit"
            class="mx-4"
          >
            <v-icon left>{{ update ? "mdi-update" : "mdi-plus" }}</v-icon>
            {{ update ? "更新" : "创建" }}
          </v-btn>
        </div>
      </div>
    </v-form>

    <v-card v-if="update && isAdmin" class="mt-8 pa-6" elevation="4">
      <h2 class="mb-4">权限管理</h2>
      <p class="text-body-2 mb-4">管理哪些家庭成员可以查看或编辑此账户</p>

      <v-list v-if="permissions.length > 0">
        <v-list-item v-for="perm in permissions" :key="perm.userId">
          <v-list-item-content>
            <v-list-item-title>
              {{ perm.userFirstName }} {{ perm.userLastName }}
            </v-list-item-title>
            <v-list-item-subtitle>{{ perm.userEmail }}</v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action>
            <div class="d-flex align-center">
              <v-select
                v-model="perm.permission"
                :items="permissionTypeOptions"
                item-text="text"
                item-value="value"
                dense
                @change="updatePermission(perm)"
                class="mr-2"
                style="width: 120px"
              />
              <v-btn icon color="error" @click="removePermission(perm.userId)">
                <v-icon>mdi-delete</v-icon>
              </v-btn>
            </div>
          </v-list-item-action>
        </v-list-item>
      </v-list>
      <div v-else class="text-body-2 grey--text mb-4">
        暂无成员有权限访问此账户
      </div>

      <v-divider class="my-4"></v-divider>
      <div class="d-flex align-center gap-2">
        <v-select
          v-model="newPermission.userId"
          :items="availableMembers"
          item-text="displayName"
          item-value="id"
          label="选择成员"
          dense
          outlined
          style="flex: 1"
        />
        <v-select
          v-model="newPermission.permissionType"
          :items="permissionTypeOptions"
          item-text="text"
          item-value="value"
          label="权限类型"
          dense
          outlined
          style="width: 150px"
        />
        <v-btn
          color="primary"
          @click="addPermission"
          :disabled="!newPermission.userId"
        >
          <v-icon left>mdi-plus</v-icon>
          添加
        </v-btn>
      </div>
    </v-card>
  </section>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import accountApi, {
  CreateUpdateAccountRequest,
  AccountPermissionInfo,
  AccountPermissionType,
} from "@/api/accountApi";
import errorMessage from "@/services/errorMessage";
import ConfirmationDialog from "@/components/ConfirmationDialog.component.vue";
import ColorSelect from "@/components/inputs/ColorSelect.component.vue";
import IconSelect from "@/components/IconSelect.component.vue";
import { Action, Getter } from "vuex-class";
import FamilyApi, { User } from "@/api/familyApi";

@Component({
  components: {
    ConfirmationDialog,
    ColorSelect,
    IconSelect,
  },
})
export default class CreateUpdateAccount extends Vue {
  @Prop({ default: false }) update!: boolean;

  accountId = null as null | string;
  submitLoading = false;
  accountLoading = false;
  deleteLoading = false;
  maxLength = 40;
  maxLengthFieldErrorMsg = "不能超过 " + this.maxLength + " 个字符";
  fieldRequiredErrorMsg = "此项为必填项";
  showDeleteDialog = false;

  permissions = [] as AccountPermissionInfo[];
  familyMembers = [] as Array<User & { displayName: string }>;
  newPermission = {
    userId: null as number | null,
    permissionType: "VISIBLE" as AccountPermissionType,
  };
  permissionTypeOptions = [
    { text: "可见", value: "VISIBLE" },
    { text: "可编辑", value: "EDIT" },
  ];

  @Getter("user/currency") currency: string | undefined;
  @Getter("user/familyId") familyId!: number | null;
  @Getter("user/user") currentUser!: { id: number; role: string } | null;

  get isAdmin(): boolean {
    return this.currentUser?.role === "FAMILY_ADMIN";
  }

  get availableMembers(): Array<User & { displayName: string }> {
    const permissionUserIds = this.permissions.map((p) => p.userId);
    return this.familyMembers.filter(
      (member) => !permissionUserIds.includes(member.id)
    );
  }

  account = {
    id: null,
    name: "",
    balance: 0,
    currency: "",
    color: "#6290ff",
    icon: "mdi-piggy-bank-outline",
    includeInStatistics: true,
  } as CreateUpdateAccountRequest;

  rules = {
    requiredAndMaxLength: [
      (value: string): boolean | string =>
        !!value || this.fieldRequiredErrorMsg,
      (value: string): boolean | string =>
        (!!value && value.length <= this.maxLength) ||
        this.maxLengthFieldErrorMsg,
    ],
    balance: [
      (value: number): boolean | string =>
        !!value || value === 0 || this.fieldRequiredErrorMsg,
    ],
  };

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    if (!this.update) {
      this.account.currency = this.currency || "";
      return;
    }
    this.accountId = this.$route.params.accountId;
    this.getAccount();

    if (this.isAdmin) {
      this.loadFamilyMembers();
      this.loadPermissions();
    }
  }

  submit(): void {
    this.submitLoading = true;

    if (!(this.$refs["form"] as any)?.validate()) {
      this.submitLoading = false;
      return;
    }
    if (this.update) {
      this.updateAccount();
    } else {
      this.createAccount();
    }
  }

  getAccount(): void {
    this.accountLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.accountLoading = false;
      return;
    }
    if (!this.accountId) {
      this.showSnack("无法加载账户，ID为空");
      this.accountLoading = false;
      return;
    }
    accountApi
      .getById(this.familyId, parseInt(this.accountId))
      .then((response) => {
        this.account = response.data;
      })
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.accountLoading = false));
  }

  createAccount(): void {
    this.submitLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.submitLoading = false;
      return;
    }
    accountApi
      .createAccount(this.familyId, this.account)
      .then(() => this.$router.push("/dashboard"))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.submitLoading = false));
  }

  updateAccount(): void {
    this.submitLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.submitLoading = false;
      return;
    }
    if (!this.accountId) {
      this.showSnack("无法加载账户，ID为空");
      this.submitLoading = false;
      return;
    }
    accountApi
      .updateAccount(this.familyId, parseInt(this.accountId), this.account)
      .then(() => this.$router.push("/dashboard"))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.submitLoading = false));
  }

  deleteAccount(): void {
    this.deleteLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.deleteLoading = false;
      return;
    }
    if (!this.accountId) {
      this.showSnack("无法加载账户，ID为空");
      this.deleteLoading = false;
      return;
    }
    accountApi
      .deleteAccount(this.familyId, parseInt(this.accountId))
      .then(() => this.$router.push("/dashboard"))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.deleteLoading = false));
  }

  loadFamilyMembers(): void {
    if (!this.familyId) return;
    FamilyApi.getMembers(this.familyId)
      .then((response) => {
        this.familyMembers = response.data.map((member) => ({
          ...member,
          displayName: `${member.firstName} ${member.lastName}`,
        }));
      })
      .catch((error) => this.showSnack(errorMessage.get(error)));
  }

  loadPermissions(): void {
    if (!this.familyId || !this.accountId) return;
    accountApi
      .getAccountPermissions(this.familyId, parseInt(this.accountId))
      .then((response) => {
        this.permissions = response.data;
      })
      .catch((error) => this.showSnack(errorMessage.get(error)));
  }

  addPermission(): void {
    if (!this.familyId || !this.accountId || !this.newPermission.userId) return;
    accountApi
      .grantPermission(
        this.familyId,
        parseInt(this.accountId),
        this.newPermission.userId,
        this.newPermission.permissionType
      )
      .then(() => {
        this.showSnack("权限已添加");
        this.loadPermissions();
        this.newPermission.userId = null;
        this.newPermission.permissionType = "VISIBLE";
      })
      .catch((error) => this.showSnack(errorMessage.get(error)));
  }

  updatePermission(perm: AccountPermissionInfo): void {
    if (!this.familyId || !this.accountId) return;

    accountApi
      .revokePermission(this.familyId, parseInt(this.accountId), perm.userId)
      .then(() => {
        return accountApi.grantPermission(
          this.familyId!,
          parseInt(this.accountId!),
          perm.userId,
          perm.permission
        );
      })
      .then(() => {
        this.showSnack("权限已更新");
        this.loadPermissions();
      })
      .catch((error) => this.showSnack(errorMessage.get(error)));
  }

  removePermission(userId: number): void {
    if (!this.familyId || !this.accountId) return;
    accountApi
      .revokePermission(this.familyId, parseInt(this.accountId), userId)
      .then(() => {
        this.showSnack("权限已删除");
        this.loadPermissions();
      })
      .catch((error) => this.showSnack(errorMessage.get(error)));
  }
}
</script>

<style scoped>
.row {
  display: flex;
  gap: 2rem;
  align-items: center;
  justify-content: space-between;
}

.row .input {
  width: calc(50% - 1rem);
  padding: 0.5rem 1rem;
}

@media only screen and (max-width: 750px) {
  .row {
    flex-direction: column;
    align-items: start;
    gap: 0;
  }

  .row .input {
    width: 100%;
  }
}
</style>
