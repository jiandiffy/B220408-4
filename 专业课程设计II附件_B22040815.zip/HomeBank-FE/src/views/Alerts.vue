<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <h1 class="text-h4 mb-4">
          预警中心
          <v-chip
            class="ml-2"
            v-if="unreadCount > 0"
            color="red"
            text-color="white"
          >
            {{ unreadCount }} 条未读
          </v-chip>
        </h1>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12">
        <v-btn-toggle v-model="filterType" mandatory>
          <v-btn value="all">全部</v-btn>
          <v-btn value="unread">未读</v-btn>
          <v-btn value="warning">预警</v-btn>
          <v-btn value="exceeded">超支</v-btn>
        </v-btn-toggle>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12">
        <v-progress-circular
          v-if="loading"
          indeterminate
          color="primary"
        ></v-progress-circular>
        <div v-else>
          <AlertCard
            v-for="alert in filteredAlerts"
            :key="alert.id"
            :alert="alert"
            @mark-read="markAsRead"
            @delete="deleteAlert"
          />
          <div
            v-if="filteredAlerts.length === 0"
            class="text-center text--secondary"
          >
            暂无{{ filterTypeText }}预警
          </div>
        </div>
      </v-col>
    </v-row>

    <v-dialog v-model="deleteDialog" max-width="400">
      <v-card>
        <v-card-title>确认删除</v-card-title>
        <v-card-text>确定要删除此预警吗？此操作不可撤销。</v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn text @click="deleteDialog = false">取消</v-btn>
          <v-btn color="error" @click="confirmDelete">删除</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Alert } from "@/api/alertApi";
import AlertCard from "@/components/alert/AlertCard.component.vue";
import { ErrorHandler } from "@/utils/errorHandler";
import { SUCCESS_MESSAGES } from "@/constants/messages";

@Component({
  components: {
    AlertCard,
  },
})
export default class Alerts extends Vue {
  filterType = "all";
  loading = false;
  deleteDialog = false;
  alertToDelete: number | null = null;

  get alerts(): Alert[] {
    return this.$store.getters["alert/alerts"];
  }

  get unreadCount(): number {
    return this.$store.getters["alert/unreadCount"];
  }

  get filteredAlerts(): Alert[] {
    switch (this.filterType) {
      case "unread":
        return this.alerts.filter((a) => !a.isRead);
      case "warning":
        return this.alerts.filter((a) => a.type === "BUDGET_WARNING");
      case "exceeded":
        return this.alerts.filter((a) => a.type === "BUDGET_EXCEEDED");
      default:
        return this.alerts;
    }
  }

  get filterTypeText(): string {
    const typeMap: Record<string, string> = {
      all: "",
      unread: "未读",
      warning: "预警",
      exceeded: "超支",
    };
    return typeMap[this.filterType] || "";
  }

  async mounted(): Promise<void> {
    await this.loadAlerts();
  }

  async loadAlerts(): Promise<void> {
    this.loading = true;
    try {
      await this.$store.dispatch("alert/fetchAlerts");
    } catch (error) {
      console.error("Failed to load alerts:", error);
    } finally {
      this.loading = false;
    }
  }

  async markAsRead(alertId: number): Promise<void> {
    try {
      await this.$store.dispatch("alert/markAlertAsRead", alertId);
      this.$store.dispatch("snackbar/showSnack", {
        text: SUCCESS_MESSAGES.ALERT_MARKED_READ,
        color: "success",
      });
    } catch (error) {
      console.error("Failed to mark alert as read:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    }
  }

  deleteAlert(alertId: number): void {
    this.alertToDelete = alertId;
    this.deleteDialog = true;
  }

  async confirmDelete(): Promise<void> {
    if (!this.alertToDelete) return;

    try {
      await this.$store.dispatch("alert/deleteAlert", this.alertToDelete);
      this.$store.dispatch("snackbar/showSnack", {
        text: SUCCESS_MESSAGES.ALERT_DELETED,
        color: "success",
      });
    } catch (error) {
      console.error("Failed to delete alert:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.deleteDialog = false;
      this.alertToDelete = null;
    }
  }
}
</script>
