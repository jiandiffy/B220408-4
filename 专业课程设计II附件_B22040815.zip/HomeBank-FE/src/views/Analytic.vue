<template>
  <section class="max-width main">
    <div class="heading-row">
      <h1 class="main primary--text mb-8">分析</h1>

      <v-autocomplete
        v-if="isAdmin"
        v-model="selectedUserId"
        :items="memberOptions"
        item-text="text"
        item-value="value"
        label="成员"
        class="member-selector"
        dense
        outlined
      />
    </div>

    <AnalyticIntervalPicker v-model="dateInterval" />

    <div class="row">
      <v-card class="full-width" elevation="8">
        <AnnualFinancialReport
          :date-interval="dateInterval"
          :scope-user-id="selectedUserId"
        />
      </v-card>
    </div>

    <div class="row">
      <v-card class="card-half" elevation="8">
        <TotalAnalyticComponent
          :date-interval="dateInterval"
          :scope-user-id="selectedUserId"
        />
      </v-card>

      <v-card class="card-half" elevation="8">
        <CategoryAnalyticPiChart
          :date-interval="dateInterval"
          :scope-user-id="selectedUserId"
        />
      </v-card>
    </div>

    <div class="row">
      <v-card class="full-width balance-card" elevation="8">
        <BalanceEvolution
          :date-interval="dateInterval"
          :scope-user-id="selectedUserId"
        />
      </v-card>
    </div>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Getter } from "vuex-class";
import CategoryAnalyticPiChart from "@/components/analytic/CategoryAnalyticPiChart.component.vue";
import TotalAnalyticComponent from "@/components/analytic/TotalAnalytic.component.vue";
import AnalyticIntervalPicker from "@/components/analytic/AnalyticIntervalPicker.component.vue";
import BalanceEvolution from "@/components/analytic/BalanceEvolution.component.vue";
import AnnualFinancialReport from "@/components/analytic/AnnualFinancialReport.component.vue";
import { formatYYYYMMDD } from "@/utils/formatDate";
import FamilyApi, { User } from "@/api/familyApi";

@Component({
  components: {
    CategoryAnalyticPiChart,
    TotalAnalyticComponent,
    AnalyticIntervalPicker,
    BalanceEvolution,
    AnnualFinancialReport,
  },
})
export default class Analytic extends Vue {
  dateInterval = ["", ""];
  selectedUserId: number | null = null;
  familyMembers = [] as User[];

  @Getter("user/familyId") familyId!: number | null;
  @Getter("user/user") currentUser!: { id: number; role: string } | null;

  get isAdmin(): boolean {
    return this.currentUser?.role === "FAMILY_ADMIN";
  }

  get memberOptions(): Array<{ text: string; value: number | null }> {
    const options: Array<{ text: string; value: number | null }> = [
      { text: "全家庭", value: null },
    ];
    this.familyMembers.forEach((member) => {
      options.push({
        text: `${member.firstName} ${member.lastName}`,
        value: member.id,
      });
    });
    return options;
  }

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    this.initDateInterval();
    this.loadFamilyMembers();
    this.initSelectedUserId();
  }

  initDateInterval(): void {
    const thisMonth = new Date().getMonth();
    const thisYear = new Date().getFullYear();

    this.dateInterval = [
      formatYYYYMMDD(new Date(thisYear, thisMonth, 1)),
      formatYYYYMMDD(new Date(thisYear, thisMonth + 1, 0)),
    ];
  }

  loadFamilyMembers(): void {
    if (!this.familyId) return;
    FamilyApi.getMembers(this.familyId)
      .then((response) => {
        this.familyMembers = response.data;
      })
      .catch((error) => {
        console.error("Failed to load family members:", error);
      });
  }

  initSelectedUserId(): void {
    if (this.isAdmin) {
      this.selectedUserId = null;
    } else {
      this.selectedUserId = this.currentUser?.id || null;
    }
  }
}
</script>

<style scoped>
.heading-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 2rem;
  margin-bottom: 1rem;
}

.member-selector {
  max-width: 250px;
  margin-bottom: 0;
}

.row {
  display: flex;
  justify-content: space-between;
  gap: 2rem;
  margin-bottom: 2rem;
  width: 100%;
}

.card-half {
  width: 48%;
  min-height: 400px;
}

.full-width {
  width: 100%;
}

.balance-card {
  min-height: 450px;
  overflow: hidden;
}

@media only screen and (max-width: 1200px) {
  .row {
    flex-direction: column;
  }

  .card-half {
    width: 100%;
  }
}

@media only screen and (max-width: 600px) {
  .card-half {
    min-height: auto;
  }

  .balance-card {
    min-height: auto;
  }
}
</style>
