<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <h1 class="text-h4 mb-4">家庭管理</h1>
      </v-col>
    </v-row>

    <v-row v-if="familyInfo">
      <v-col cols="12" md="6">
        <v-card>
          <v-card-title>家庭信息</v-card-title>
          <v-card-text>
            <v-text-field
              label="家庭名称"
              v-model="familyInfo.name"
              readonly
            ></v-text-field>
            <v-text-field
              label="货币"
              v-model="familyInfo.currency"
              readonly
            ></v-text-field>
            <v-text-field
              label="创建时间"
              :value="formatDate(familyInfo.createdAt)"
              readonly
            ></v-text-field>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12">
        <v-card>
          <v-card-title>
            家庭成员
            <v-spacer></v-spacer>
            <v-btn color="primary" @click="showAddMemberDialog = true">
              <v-icon left>mdi-account-plus</v-icon>
              添加成员
            </v-btn>
          </v-card-title>
          <v-card-text>
            <v-progress-circular
              v-if="loadingMembers"
              indeterminate
              color="primary"
            ></v-progress-circular>
            <div v-else>
              <FamilyMemberCard
                v-for="member in members"
                :key="member.id"
                :member="member"
                :can-remove="
                  member.id !== currentUserId && member.role !== 'FAMILY_ADMIN'
                "
                @remove="removeMember"
              />
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12">
        <v-card>
          <v-card-title>待处理邀请</v-card-title>
          <v-card-text>
            <v-progress-circular
              v-if="loadingInvitations"
              indeterminate
              color="primary"
            ></v-progress-circular>
            <div v-else-if="pendingInvitations.length === 0">
              <p class="text-body-2 text--secondary">暂无待处理的邀请</p>
            </div>
            <v-list v-else>
              <v-list-item
                v-for="invitation in pendingInvitations"
                :key="invitation.id"
              >
                <v-list-item-content>
                  <v-list-item-title>{{
                    invitation.inviteeEmail
                  }}</v-list-item-title>
                  <v-list-item-subtitle>
                    角色:
                    {{
                      invitation.role === "FAMILY_ADMIN"
                        ? "家庭管理员"
                        : "家庭成员"
                    }}
                    | 过期时间: {{ formatDate(invitation.expiresAt) }}
                  </v-list-item-subtitle>
                  <div class="mt-2">
                    <v-text-field
                      :value="invitation.token"
                      label="邀请码"
                      readonly
                      dense
                      outlined
                      hide-details
                      class="mb-2"
                    >
                      <template v-slot:append>
                        <v-btn icon small @click="copyToken(invitation.token)">
                          <v-icon small>mdi-content-copy</v-icon>
                        </v-btn>
                      </template>
                    </v-text-field>
                  </div>
                </v-list-item-content>
                <v-list-item-action>
                  <v-btn
                    icon
                    color="error"
                    @click="cancelInvitation(invitation.id)"
                  >
                    <v-icon>mdi-close</v-icon>
                  </v-btn>
                </v-list-item-action>
              </v-list-item>
            </v-list>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-dialog v-model="showAddMemberDialog" max-width="500">
      <v-card>
        <v-card-title>邀请家庭成员</v-card-title>
        <v-card-text>
          <p class="text-body-2 mb-4">
            输入要邀请的成员邮箱，系统将发送邀请链接。被邀请人需要自行完成注册。
          </p>
          <v-form ref="form">
            <v-text-field
              label="邮箱"
              v-model="newInvitation.inviteeEmail"
              type="email"
              required
            ></v-text-field>
            <v-select
              label="角色"
              v-model="newInvitation.role"
              :items="roleOptions"
              item-text="text"
              item-value="value"
            ></v-select>
          </v-form>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn text @click="showAddMemberDialog = false">取消</v-btn>
          <v-btn color="primary" @click="sendInvitation">发送邀请</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="removeDialog" max-width="400">
      <v-card>
        <v-card-title>确认移除</v-card-title>
        <v-card-text>确定要移除此成员吗？此操作不可撤销。</v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn text @click="removeDialog = false">取消</v-btn>
          <v-btn color="error" @click="confirmRemove">移除</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Family, User } from "@/api/familyApi";
import FamilyApi from "@/api/familyApi";
import InvitationApi, {
  CreateInvitationRequest,
  FamilyInvitation,
} from "@/api/invitationApi";
import FamilyMemberCard from "@/components/family/FamilyMemberCard.component.vue";
import { formatDate } from "@/utils/formatDate";
import { ErrorHandler } from "@/utils/errorHandler";
import { SUCCESS_MESSAGES } from "@/constants/messages";

@Component({
  components: {
    FamilyMemberCard,
  },
})
export default class FamilyManagement extends Vue {
  familyInfo: Family | null = null;
  showAddMemberDialog = false;
  removeDialog = false;
  userToRemove: number | null = null;
  pendingInvitations: FamilyInvitation[] = [];
  loadingInvitations = false;
  newInvitation: CreateInvitationRequest = {
    inviteeEmail: "",
    role: "FAMILY_MEMBER",
  };
  roleOptions = [
    { text: "家庭成员", value: "FAMILY_MEMBER" },
    { text: "家庭管理员", value: "FAMILY_ADMIN" },
  ];

  get members(): User[] {
    return this.$store.getters["family/members"];
  }

  get loadingMembers(): boolean {
    return this.$store.getters["family/loadingMembers"];
  }

  get familyId(): number | null {
    return this.$store.getters["user/familyId"];
  }

  get currentUserId(): number | null {
    const user = this.$store.getters["user/user"];
    return user ? user.id : null;
  }

  async mounted(): Promise<void> {
    if (this.familyId) {
      await this.loadFamilyInfo();
      await this.$store.dispatch("family/fetchFamilyMembers", this.familyId);
      await this.loadPendingInvitations();
    }
  }

  async loadFamilyInfo(): Promise<void> {
    if (!this.familyId) return;
    try {
      const response = await FamilyApi.getById(this.familyId);
      this.familyInfo = response.data;
    } catch (error) {
      console.error("Failed to load family info:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    }
  }

  async loadPendingInvitations(): Promise<void> {
    if (!this.familyId) return;
    try {
      this.loadingInvitations = true;
      const response = await InvitationApi.getFamilyInvitations(this.familyId);
      this.pendingInvitations = response.data;
    } catch (error) {
      console.error("Failed to load invitations:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.loadingInvitations = false;
    }
  }

  async sendInvitation(): Promise<void> {
    if (!this.familyId) return;
    try {
      await InvitationApi.createInvitation(this.familyId, this.newInvitation);
      this.showAddMemberDialog = false;
      this.newInvitation = {
        inviteeEmail: "",
        role: "FAMILY_MEMBER",
      };
      this.$store.dispatch("snackbar/showSnack", {
        text: "邀请已发送成功",
        color: "success",
      });

      await this.loadPendingInvitations();
    } catch (error) {
      console.error("Failed to send invitation:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    }
  }

  copyToken(token: string): void {
    navigator.clipboard
      .writeText(token)
      .then(() => {
        this.$store.dispatch("snackbar/showSnack", {
          text: "邀请码已复制到剪贴板",
          color: "success",
        });
      })
      .catch(() => {
        this.$store.dispatch("snackbar/showSnack", {
          text: "复制失败，请手动复制",
          color: "error",
        });
      });
  }

  async cancelInvitation(invitationId: number): Promise<void> {
    if (!this.familyId) return;
    try {
      await InvitationApi.cancelInvitation(this.familyId, invitationId);
      this.$store.dispatch("snackbar/showSnack", {
        text: "邀请已取消",
        color: "success",
      });

      this.pendingInvitations = this.pendingInvitations.filter(
        (inv) => inv.id !== invitationId
      );
    } catch (error) {
      console.error("Failed to cancel invitation:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    }
  }

  removeMember(userId: number): void {
    this.userToRemove = userId;
    this.removeDialog = true;
  }

  async confirmRemove(): Promise<void> {
    if (!this.familyId || !this.userToRemove) return;

    try {
      await FamilyApi.removeMember(this.familyId, this.userToRemove);
      this.$store.commit("family/removeMember", this.userToRemove);
      this.$store.dispatch("snackbar/showSnack", {
        text: SUCCESS_MESSAGES.MEMBER_REMOVED,
        color: "success",
      });
    } catch (error) {
      console.error("Failed to remove member:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.removeDialog = false;
      this.userToRemove = null;
    }
  }

  formatDate(date: string): string {
    return formatDate(date);
  }
}
</script>
