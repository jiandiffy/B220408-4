<template>
  <section class="max-width main">
    <PendingInvitationsSection />
    <AccountsSection class="mb-10" />
    <RecordsSection />
  </section>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import AccountsSection from "@/components/dashboard/AccountSection.component.vue";
import RecordsSection from "@/components/dashboard/RecordsSection.component.vue";
import PendingInvitationsSection from "@/components/dashboard/PendingInvitationsSection.component.vue";

@Component({
  components: { AccountsSection, RecordsSection, PendingInvitationsSection },
})
export default class Dashboard extends Vue {}
</script>

<style scoped></style>
