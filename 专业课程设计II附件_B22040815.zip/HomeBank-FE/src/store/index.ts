import Vue from "vue";
import Vuex from "vuex";
import user from "@/store/modules/user";
import snackbar from "@/store/modules/snackbar";
import family from "@/store/modules/family";
import alert from "@/store/modules/alert";

Vue.use(Vuex);

class State {}

const Store = new Vuex.Store<State>({
  state: new State(),
  mutations: {},
  actions: {},
  getters: {},
  modules: {
    user: user,
    snackbar: snackbar,
    family: family,
    alert: alert,
  },
});

export default Store;
export { Store, State };
