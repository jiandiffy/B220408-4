import { Commit } from "vuex";

class State {
  show = false;
  text = "";
  color = "";
}

interface SnackbarPayload {
  text: string;
  color?: string;
}

const snackbar = {
  namespaced: true,
  state: new State(),
  mutations: {
    setShow: (state: State, data: boolean): void => {
      state.show = data;
    },
    setText: (state: State, data: string): void => {
      state.text = data;
    },
    setColor: (state: State, data: string): void => {
      state.color = data;
    },
  },
  getters: {
    show: (state: State): boolean => {
      return state.show;
    },
    text: (state: State): string => {
      return state.text;
    },
    color: (state: State): string => {
      return state.color;
    },
  },
  actions: {
    showSnack: (
      { commit }: { commit: Commit },
      payload: string | SnackbarPayload
    ): void => {
      if (typeof payload === "string") {
        commit("setText", payload);
        commit("setColor", "");
      } else {
        commit("setText", payload.text);
        commit("setColor", payload.color || "");
      }
      commit("setShow", true);
    },
  },
};

export default snackbar;
