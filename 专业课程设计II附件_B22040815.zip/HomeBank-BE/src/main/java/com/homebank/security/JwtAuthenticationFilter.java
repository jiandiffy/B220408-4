package com.homebank.security;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

  private final UserDetailsService userDetailsService;
  private final JwtService jwtService;

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    String requestURI = request.getRequestURI();
    log.debug("=== JWT Filter Processing: {} {}", request.getMethod(), requestURI);

    final String authHeader = request.getHeader(AUTHORIZATION);
    final String userEmail;
    final String jwtToken;

    if (authHeader == null || !authHeader.startsWith("Bearer ")) {
      log.debug("No Bearer token found, skipping JWT authentication");
      filterChain.doFilter(request, response);
      return;
    }

    jwtToken = authHeader.substring(7);
    log.debug("JWT token extracted: {}...", jwtToken.substring(0, Math.min(20, jwtToken.length())));

    try {
      userEmail = jwtService.extractUsername(jwtToken);
      log.debug("Extracted username from JWT: {}", userEmail);
    } catch (ExpiredJwtException e) {
      log.error("JWT token expired for request: {}", requestURI);
      throw new AccessDeniedException("JWT token expired");
    }

    if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
      log.debug("Loading user details for: {}", userEmail);
      UserDetails userDetails = userDetailsService.loadUserByUsername(userEmail);
      log.debug("User details loaded, authorities: {}", userDetails.getAuthorities());

      if (jwtService.isTokenValid(jwtToken, userDetails)) {
        log.debug("JWT token is valid, setting authentication");
        UsernamePasswordAuthenticationToken authToken =
            new UsernamePasswordAuthenticationToken(
                userDetails, null, userDetails.getAuthorities());
        authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authToken);
        log.debug("Authentication set in SecurityContext: {}", authToken.getAuthorities());
      } else {
        log.warn("JWT token is NOT valid for user: {}", userEmail);
      }
    } else {
      log.debug("Skipping authentication - userEmail: {}, existing auth: {}",
          userEmail, SecurityContextHolder.getContext().getAuthentication() != null);
    }

    log.debug("Continuing filter chain for: {}", requestURI);
    filterChain.doFilter(request, response);
    log.debug("=== JWT Filter Completed: {}", requestURI);
  }
}
