package com.homebank.repository;

import com.homebank.model.FamilyInvitation;
import com.homebank.model.enums.InvitationStatus;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FamilyInvitationRepository extends JpaRepository<FamilyInvitation, Long> {

  Optional<FamilyInvitation> findByToken(String token);

  List<FamilyInvitation> findByFamilyId(Long familyId);

  List<FamilyInvitation> findByFamilyIdAndStatus(Long familyId, InvitationStatus status);

  List<FamilyInvitation> findByInviterId(Long inviterId);

  List<FamilyInvitation> findByInviteeEmail(String email);

  @Query(
      "SELECT fi FROM FamilyInvitation fi JOIN FETCH fi.family WHERE fi.inviteeEmail = :email AND fi.status ="
          + " com.homebank.model.enums.InvitationStatus.PENDING AND fi.expiresAt > :now")
  List<FamilyInvitation> findPendingByInviteeEmail(
      @Param("email") String email, @Param("now") LocalDateTime now);

  @Query(
      "SELECT fi FROM FamilyInvitation fi JOIN FETCH fi.family WHERE fi.family.id = :familyId AND fi.status ="
          + " com.homebank.model.enums.InvitationStatus.PENDING AND fi.expiresAt > :now")
  List<FamilyInvitation> findPendingByFamilyId(
      @Param("familyId") Long familyId, @Param("now") LocalDateTime now);

  boolean existsByToken(String token);

  @Query(
      "SELECT COUNT(fi) > 0 FROM FamilyInvitation fi WHERE fi.family.id = :familyId AND"
          + " fi.inviteeEmail = :email AND fi.status ="
          + " com.homebank.model.enums.InvitationStatus.PENDING AND fi.expiresAt > :now")
  boolean existsPendingInvitation(
      @Param("familyId") Long familyId,
      @Param("email") String email,
      @Param("now") LocalDateTime now);

  @Modifying
  @Query(
      "UPDATE FamilyInvitation fi SET fi.status = :expired"
          + " WHERE fi.status = :pending AND fi.expiresAt <= :now")
  int expireOldInvitations(
      @Param("expired") InvitationStatus expired,
      @Param("pending") InvitationStatus pending,
      @Param("now") LocalDateTime now);

  @Modifying
  @Query(
      "DELETE FROM FamilyInvitation fi WHERE fi.status IN"
          + " (com.homebank.model.enums.InvitationStatus.EXPIRED,"
          + " com.homebank.model.enums.InvitationStatus.REJECTED) AND fi.createdAt < :beforeDate")
  int deleteOldInvitations(@Param("beforeDate") LocalDateTime beforeDate);
}
