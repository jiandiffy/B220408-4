package com.homebank.dto.response;

import com.homebank.model.Category;
import com.homebank.model.enums.RecordType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CategoryResponse {

  private Long id;
  private Long familyId;
  private String name;
  private RecordType type;
  private String icon;
  private String color;
  private Boolean isCustom;

  public static CategoryResponse fromCategory(Category category) {
    return CategoryResponse.builder()
        .id(category.getId())
        .familyId(category.getFamily().getId())
        .name(category.getName())
        .type(category.getType())
        .icon(category.getIcon())
        .color(category.getColor())
        .isCustom(category.getIsCustom())
        .build();
  }
}
