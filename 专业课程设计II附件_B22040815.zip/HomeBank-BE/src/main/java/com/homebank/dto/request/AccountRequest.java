package com.homebank.dto.request;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountRequest {

  @NotBlank(message = "Account name is required")
  @Size(max = 100, message = "Account name must not exceed 100 characters")
  private String name;

  @NotNull(message = "Balance is required")
  @DecimalMin(value = "0.00", message = "Balance cannot be negative")
  private BigDecimal balance;

  @NotBlank(message = "Currency is required")
  @Size(min = 3, max = 3, message = "Currency must be 3 characters (e.g., CNY, USD)")
  private String currency;

  @Size(max = 20, message = "Color must not exceed 20 characters")
  private String color = "#1976D2";

  @Size(max = 50, message = "Icon must not exceed 50 characters")
  private String icon = "mdi-wallet";

  private Boolean includeInStatistics = true;
}
