package com.homebank.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.homebank.model.enums.InvitationStatus;
import com.homebank.model.enums.UserRole;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "family_invitations")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FamilyInvitation {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "family_id", nullable = false)
  @JsonIgnoreProperties({"memberships", "categories", "accounts", "invitations", "budgets", "alerts"})
  private Family family;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "inviter_id", nullable = false)
  @JsonIgnoreProperties({"memberships", "password", "passwordHash"})
  private User inviter;

  @Column(name = "invitee_email", nullable = false)
  private String inviteeEmail;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  @Builder.Default
  private UserRole role = UserRole.FAMILY_MEMBER;

  @Column(nullable = false, unique = true, length = 64)
  private String token;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  @Builder.Default
  private InvitationStatus status = InvitationStatus.PENDING;

  @Column(name = "expires_at", nullable = false)
  private LocalDateTime expiresAt;

  @Column(name = "accepted_at")
  private LocalDateTime acceptedAt;

  @CreationTimestamp
  @Column(name = "created_at", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "updated_at")
  private LocalDateTime updatedAt;

  public boolean isExpired() {
    return LocalDateTime.now().isAfter(expiresAt)
        || InvitationStatus.EXPIRED.equals(status);
  }

  public boolean isPending() {
    return InvitationStatus.PENDING.equals(status) && !isExpired();
  }

  public boolean isAccepted() {
    return InvitationStatus.ACCEPTED.equals(status);
  }

  public void markAsAccepted() {
    this.status = InvitationStatus.ACCEPTED;
    this.acceptedAt = LocalDateTime.now();
  }

  public void markAsRejected() {
    this.status = InvitationStatus.REJECTED;
  }

  public void markAsExpired() {
    this.status = InvitationStatus.EXPIRED;
  }
}
