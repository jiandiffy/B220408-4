package com.homebank.model.enums;

public enum UserRole {
  FAMILY_ADMIN,
  FAMILY_MEMBER
}
