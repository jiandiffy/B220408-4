package com.homebank.controller;

import com.homebank.dto.request.CreateInvitationRequest;
import com.homebank.dto.response.FamilyInvitationResponse;
import com.homebank.model.FamilyInvitation;
import com.homebank.model.User;
import com.homebank.model.enums.UserRole;
import com.homebank.service.FamilyInvitationService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families/{familyId}/invitations")
@RequiredArgsConstructor
public class FamilyInvitationController {

  private final FamilyInvitationService invitationService;

  @PostMapping
  public ResponseEntity<FamilyInvitationResponse> createInvitation(
      @PathVariable Long familyId,
      @Valid @RequestBody CreateInvitationRequest request,
      Authentication authentication) {

    User currentUser = (User) authentication.getPrincipal();

    UserRole role = request.getRole() != null ? request.getRole() : UserRole.FAMILY_MEMBER;
    FamilyInvitation invitation = invitationService.createInvitation(familyId, request.getInviteeEmail(), role,
        currentUser.getId());

    FamilyInvitationResponse response = FamilyInvitationResponse.builder()
        .id(invitation.getId())
        .familyId(invitation.getFamily().getId())
        .familyName(invitation.getFamily().getName())
        .inviteeEmail(invitation.getInviteeEmail())
        .role(invitation.getRole())
        .token(invitation.getToken())
        .status(invitation.getStatus())
        .expiresAt(invitation.getExpiresAt())
        .createdAt(invitation.getCreatedAt())
        .build();

    return ResponseEntity.ok(response);
  }

  @GetMapping
  public ResponseEntity<List<FamilyInvitationResponse>> getFamilyInvitations(
      @PathVariable Long familyId, Authentication authentication) {

    List<FamilyInvitation> invitations = invitationService.getFamilyPendingInvitations(familyId);

    List<FamilyInvitationResponse> response = invitations.stream()
        .map(invitation -> FamilyInvitationResponse.builder()
            .id(invitation.getId())
            .familyId(invitation.getFamily().getId())
            .familyName(invitation.getFamily().getName())
            .inviteeEmail(invitation.getInviteeEmail())
            .role(invitation.getRole())
            .token(invitation.getToken())
            .status(invitation.getStatus())
            .expiresAt(invitation.getExpiresAt())
            .createdAt(invitation.getCreatedAt())
            .build())
        .collect(java.util.stream.Collectors.toList());

    return ResponseEntity.ok(response);
  }

  @GetMapping("/me")
  public ResponseEntity<List<FamilyInvitationResponse>> getMyInvitations(Authentication authentication) {

    User currentUser = (User) authentication.getPrincipal();
    List<FamilyInvitation> invitations = invitationService.getUserPendingInvitations(currentUser.getEmail());

    List<FamilyInvitationResponse> response = invitations.stream()
        .map(invitation -> FamilyInvitationResponse.builder()
            .id(invitation.getId())
            .familyId(invitation.getFamily().getId())
            .familyName(invitation.getFamily().getName())
            .inviteeEmail(invitation.getInviteeEmail())
            .role(invitation.getRole())
            .token(invitation.getToken())
            .status(invitation.getStatus())
            .expiresAt(invitation.getExpiresAt())
            .createdAt(invitation.getCreatedAt())
            .build())
        .collect(java.util.stream.Collectors.toList());

    return ResponseEntity.ok(response);
  }

  @PostMapping("/{token}/accept")
  public ResponseEntity<FamilyInvitation> acceptInvitation(
      @PathVariable Long familyId, @PathVariable String token, Authentication authentication) {

    User currentUser = (User) authentication.getPrincipal();
    FamilyInvitation invitation = invitationService.acceptInvitation(token, currentUser.getId());

    return ResponseEntity.ok(invitation);
  }

  @PostMapping("/{token}/reject")
  public ResponseEntity<Void> rejectInvitation(
      @PathVariable Long familyId, @PathVariable String token, Authentication authentication) {

    User currentUser = (User) authentication.getPrincipal();
    invitationService.rejectInvitation(token, currentUser.getId());

    return ResponseEntity.ok().build();
  }

  @DeleteMapping("/{invitationId}")
  public ResponseEntity<Void> cancelInvitation(
      @PathVariable Long familyId,
      @PathVariable Long invitationId,
      Authentication authentication) {

    User currentUser = (User) authentication.getPrincipal();
    invitationService.cancelInvitation(invitationId, currentUser.getId());

    return ResponseEntity.ok().build();
  }

  @GetMapping("/validate/{token}")
  public ResponseEntity<FamilyInvitation> validateInvitation(@PathVariable String token) {

    FamilyInvitation invitation = invitationService.validateInvitation(token);

    return ResponseEntity.ok(invitation);
  }
}
