package com.homebank.controller;

import com.homebank.dto.response.TimeSeriesEntryResponse;
import com.homebank.dto.response.TotalAnalyticResponse;
import com.homebank.model.User;
import com.homebank.service.AnalyticService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families/{familyId}/analytics")
@RequiredArgsConstructor
@Tag(name = "Analytics", description = "分析统计API")
@SecurityRequirement(name = "bearer-key")
public class AnalyticController {

  private final AnalyticService analyticService;

  @GetMapping("/total")
  @Operation(summary = "获取总体统计分析", description = "获取家庭的总体统计分析。支持scope_user_id过滤特定成员数据")
  public ResponseEntity<TotalAnalyticResponse> getTotalAnalytic(
      @PathVariable Long familyId,
      @AuthenticationPrincipal User currentUser,
      @Parameter(description = "范围用户ID（可选，null=全家庭，非null=特定成员）") @RequestParam(required = false) Long scope_user_id,
      @Parameter(description = "开始日期（包含）") @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateGe,
      @Parameter(description = "结束日期（不包含）") @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateLt) {

    LocalDateTime dateGeTime = dateGe != null ? dateGe.atStartOfDay() : null;
    LocalDateTime dateLtTime = dateLt != null ? dateLt.atStartOfDay() : null;

    TotalAnalyticResponse analytic = analyticService.getTotalAnalytic(
        currentUser.getId(), familyId, scope_user_id, dateGeTime, dateLtTime);
    return ResponseEntity.ok(analytic);
  }

  @GetMapping("/balance-evolution")
  @Operation(summary = "获取余额变化趋势", description = "获取余额随时间变化的时间序列数据。支持scope_user_id过滤特定成员数据")
  public ResponseEntity<List<TimeSeriesEntryResponse>> getBalanceEvolution(
      @PathVariable Long familyId,
      @AuthenticationPrincipal User currentUser,
      @Parameter(description = "范围用户ID（可选，null=全家庭，非null=特定成员）") @RequestParam(required = false) Long scope_user_id,
      @Parameter(description = "开始日期（包含）") @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateGe,
      @Parameter(description = "结束日期（不包含）") @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateLt) {

    LocalDateTime dateGeTime = dateGe != null ? dateGe.atStartOfDay() : null;
    LocalDateTime dateLtTime = dateLt != null ? dateLt.atStartOfDay() : null;

    List<TimeSeriesEntryResponse> evolution = analyticService.getBalanceEvolution(
        currentUser.getId(), familyId, scope_user_id, dateGeTime, dateLtTime);
    return ResponseEntity.ok(evolution);
  }
}
