package com.homebank.controller;

import com.homebank.dto.request.RecordRequest;
import com.homebank.dto.request.UpdateRecordRequest;
import com.homebank.dto.response.RecordResponse;
import com.homebank.model.Record;
import com.homebank.model.User;
import com.homebank.service.RecordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families/{familyId}/records")
@RequiredArgsConstructor
@Tag(name = "Record", description = "收支记录管理API")
@SecurityRequirement(name = "bearer-key")
public class RecordController {

  private final RecordService recordService;

  @GetMapping
  @Operation(summary = "获取家庭记录", description = "获取家庭的所有记录，支持分页和过滤")
  public ResponseEntity<Page<RecordResponse>> getAllRecords(
      @PathVariable Long familyId,
      @AuthenticationPrincipal User currentUser,
      Pageable pageable,
      @RequestParam(required = false) Long accountId,
      @RequestParam(required = false) Long categoryId,
      @RequestParam(required = false) Long userId,
      @RequestParam(required = false) String label,
      @RequestParam(required = false) String note,
      @RequestParam(required = false) String type) {

    Specification<Record> spec = Specification.where(null);

    if (accountId != null) {
      spec = spec.and((root, query, cb) -> cb.equal(root.get("account").get("id"), accountId));
    }
    if (categoryId != null) {
      spec = spec.and((root, query, cb) -> cb.equal(root.get("category").get("id"), categoryId));
    }
    if (userId != null) {
      spec = spec.and((root, query, cb) -> cb.equal(root.get("user").get("id"), userId));
    }
    if (label != null && !label.isEmpty()) {
      spec = spec.and(
          (root, query, cb) -> cb.like(cb.lower(root.get("label")), "%" + label.toLowerCase() + "%"));
    }
    if (note != null && !note.isEmpty()) {
      spec = spec.and(
          (root, query, cb) -> cb.like(cb.lower(root.get("note")), "%" + note.toLowerCase() + "%"));
    }
    if (type != null && !type.isEmpty()) {
      spec = spec.and(
          (root, query, cb) -> cb.equal(root.get("type"), com.homebank.model.enums.RecordType.valueOf(type)));
    }

    Page<RecordResponse> records = recordService.getAllRecordsWithFilter(currentUser.getId(), familyId, spec, pageable);
    return ResponseEntity.ok(records);
  }

  @GetMapping("/{recordId}")
  @Operation(summary = "根据ID获取记录", description = "根据ID获取记录详情（需要账户访问权限）")
  public ResponseEntity<RecordResponse> getRecordById(
      @PathVariable Long familyId,
      @PathVariable Long recordId,
      @AuthenticationPrincipal User currentUser) {
    RecordResponse record = recordService.getRecordById(recordId, currentUser.getId());
    return ResponseEntity.ok(record);
  }

  @GetMapping("/account/{accountId}")
  @Operation(summary = "根据账户ID获取记录", description = "获取特定账户的所有记录")
  public ResponseEntity<List<RecordResponse>> getRecordsByAccountId(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @AuthenticationPrincipal User currentUser) {
    List<RecordResponse> records = recordService.getRecordsByAccountId(accountId, currentUser.getId());
    return ResponseEntity.ok(records);
  }

  @PostMapping
  @Operation(summary = "创建记录", description = "创建新的收入或支出记录（需要账户编辑权限）")
  public ResponseEntity<RecordResponse> createRecord(
      @PathVariable Long familyId,
      @Valid @RequestBody RecordRequest request,
      @AuthenticationPrincipal User currentUser) {
    RecordResponse record = recordService.createRecord(request, currentUser.getId(), familyId);
    return ResponseEntity.status(HttpStatus.CREATED).body(record);
  }

  @PutMapping("/{recordId}")
  @Operation(summary = "更新记录", description = "更新现有记录（需要权限）")
  public ResponseEntity<RecordResponse> updateRecord(
      @PathVariable Long familyId,
      @PathVariable Long recordId,
      @Valid @RequestBody UpdateRecordRequest request,
      @AuthenticationPrincipal User currentUser) {
    RecordResponse record = recordService.updateRecord(recordId, request, currentUser.getId());
    return ResponseEntity.ok(record);
  }

  @DeleteMapping("/{recordId}")
  @Operation(summary = "删除记录", description = "删除记录（需要权限）")
  public ResponseEntity<Void> deleteRecord(
      @PathVariable Long familyId,
      @PathVariable Long recordId,
      @AuthenticationPrincipal User currentUser) {
    recordService.deleteRecord(recordId, currentUser.getId());
    return ResponseEntity.noContent().build();
  }
}
