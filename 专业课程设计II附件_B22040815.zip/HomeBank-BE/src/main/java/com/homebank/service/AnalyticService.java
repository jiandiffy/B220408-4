package com.homebank.service;

import com.homebank.dto.response.CategoryAnalyticResponse;
import com.homebank.dto.response.CategoryResponse;
import com.homebank.dto.response.TimeSeriesEntryResponse;
import com.homebank.dto.response.TotalAnalyticResponse;
import com.homebank.model.Account;
import com.homebank.model.Category;
import com.homebank.model.Family;
import com.homebank.repository.AccountRepository;
import com.homebank.repository.CategoryRepository;
import com.homebank.repository.FamilyRepository;
import com.homebank.repository.RecordRepository;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AnalyticService {

  private final RecordRepository recordRepository;
  private final AccountRepository accountRepository;
  private final CategoryRepository categoryRepository;
  private final FamilyRepository familyRepository;
  private final FamilyMembershipService membershipService;

  public TotalAnalyticResponse getTotalAnalytic(
      Long userId, Long familyId, Long scopeUserId, LocalDateTime dateGe, LocalDateTime dateLt) {
    log.debug(
        "Getting total analytic for user {} in family {}, scope={}",
        userId,
        familyId,
        scopeUserId);

    membershipService.requireMember(userId, familyId);

    if (scopeUserId != null) {
      membershipService.requireMember(scopeUserId, familyId);
    }

    BigDecimal totalIncomes =
        recordRepository.getTotalIncomes(familyId, scopeUserId, dateGe, dateLt);
    BigDecimal totalExpenses =
        recordRepository.getTotalExpenses(familyId, scopeUserId, dateGe, dateLt);
    BigDecimal cashFlow = totalIncomes.subtract(totalExpenses);
    BigDecimal totalBalance = getTotalBalance(familyId, scopeUserId, dateLt);

    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new RuntimeException("Family not found"));
    String currency = family.getCurrency();

    return TotalAnalyticResponse.builder()
        .incomes(totalIncomes)
        .expenses(totalExpenses)
        .cashFlow(cashFlow)
        .balance(totalBalance)
        .currency(currency)
        .build();
  }

  public BigDecimal getTotalBalance(Long familyId, Long scopeUserId, LocalDateTime dateLt) {
    BigDecimal totalBalance = accountRepository.getTotalBalanceByFamily(familyId);

    if (dateLt != null) {
      LocalDateTime now = LocalDateTime.now();
      BigDecimal incomesAfter =
          recordRepository.getTotalIncomes(familyId, scopeUserId, dateLt, now);
      BigDecimal expensesAfter =
          recordRepository.getTotalExpenses(familyId, scopeUserId, dateLt, now);
      totalBalance = totalBalance.subtract(incomesAfter).add(expensesAfter);
    }

    return totalBalance;
  }

  public List<TimeSeriesEntryResponse> getBalanceEvolution(
      Long userId, Long familyId, Long scopeUserId, LocalDateTime dateGe, LocalDateTime dateLt) {
    log.debug(
        "Getting balance evolution for user {} in family {}, scope={}",
        userId,
        familyId,
        scopeUserId);

    membershipService.requireMember(userId, familyId);

    if (scopeUserId != null) {
      membershipService.requireMember(scopeUserId, familyId);
    }

    BigDecimal totalBalance = getTotalBalance(familyId, scopeUserId, dateLt);
    List<Object[]> rawData =
        recordRepository.getSpendingEvolution(familyId, scopeUserId, dateGe, dateLt);

    List<TimeSeriesEntryResponse> result = new ArrayList<>();

    BigDecimal runningBalance = totalBalance;
    for (int i = rawData.size() - 1; i >= 0; i--) {
      Object[] row = rawData.get(i);
      BigDecimal amount = (BigDecimal) row[0]; 
      LocalDateTime date = (LocalDateTime) row[1];

      TimeSeriesEntryResponse entry = new TimeSeriesEntryResponse();
      entry.setY(runningBalance);
      entry.setX(date);
      result.add(0, entry);

      runningBalance = runningBalance.subtract(amount);
    }

    if (result.isEmpty()) {
      TimeSeriesEntryResponse entry = new TimeSeriesEntryResponse();
      entry.setY(totalBalance);
      entry.setX(LocalDateTime.now());
      result.add(entry);
    } else {
      TimeSeriesEntryResponse firstEntry = new TimeSeriesEntryResponse();
      firstEntry.setY(runningBalance);
      firstEntry.setX(dateGe != null ? dateGe : result.get(0).getX());
      result.add(0, firstEntry);

      TimeSeriesEntryResponse lastEntry = new TimeSeriesEntryResponse();
      lastEntry.setY(result.get(result.size() - 1).getY());
      lastEntry.setX(dateLt != null ? dateLt.minusDays(1) : LocalDateTime.now());
      result.add(lastEntry);
    }

    return result;
  }

  public List<CategoryAnalyticResponse> getCategoryAnalytic(
      Long userId, Long familyId, Long scopeUserId, LocalDateTime dateGe, LocalDateTime dateLt) {
    log.debug(
        "Getting category analytic for user {} in family {}, scope={}",
        userId,
        familyId,
        scopeUserId);

    membershipService.requireMember(userId, familyId);

    if (scopeUserId != null) {
      membershipService.requireMember(scopeUserId, familyId);
    }

    List<Object[]> rawData =
        categoryRepository.findCategoriesAnalytic(familyId, scopeUserId, dateGe, dateLt);

    List<CategoryAnalyticResponse> result = new ArrayList<>();
    for (Object[] row : rawData) {
      Category category = (Category) row[0];
      BigDecimal amount = (BigDecimal) row[1];
      Long numberOfRecords = (Long) row[2];

      CategoryAnalyticResponse analytic =
          CategoryAnalyticResponse.builder()
              .category(CategoryResponse.fromCategory(category))
              .amount(amount)
              .numberOfRecords(numberOfRecords)
              .build();
      result.add(analytic);
    }

    return result;
  }
}
