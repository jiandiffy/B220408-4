package com.homebank.service;

import com.homebank.dto.response.CategoryResponse;
import com.homebank.model.Category;
import com.homebank.model.Family;
import com.homebank.model.enums.RecordType;
import com.homebank.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository categoryRepository;

    @Transactional
    public void createDefaultCategories(Family family) {
        List<Category> categories = new ArrayList<>();

        categories.add(createCategory(family, "餐饮", RecordType.EXPENSE, "mdi-food", "#FF9800"));
        categories.add(createCategory(family, "交通", RecordType.EXPENSE, "mdi-car", "#2196F3"));
        categories.add(createCategory(family, "住房", RecordType.EXPENSE, "mdi-home", "#9C27B0"));
        categories.add(createCategory(family, "购物", RecordType.EXPENSE, "mdi-cart", "#E91E63"));
        categories.add(createCategory(family, "娱乐", RecordType.EXPENSE, "mdi-gamepad-variant", "#673AB7"));
        categories.add(createCategory(family, "医疗", RecordType.EXPENSE, "mdi-hospital", "#F44336"));
        categories.add(createCategory(family, "教育", RecordType.EXPENSE, "mdi-school", "#3F51B5"));
        categories.add(createCategory(family, "通讯", RecordType.EXPENSE, "mdi-cellphone", "#00BCD4"));
        categories.add(createCategory(family, "宠物支出", RecordType.EXPENSE, "mdi-paw", "#795548"));
        categories.add(createCategory(family, "旅行基金", RecordType.EXPENSE, "mdi-airplane", "#009688"));
        categories.add(createCategory(family, "其他支出", RecordType.EXPENSE, "mdi-dots-horizontal", "#757575"));

        categories.add(createCategory(family, "工资", RecordType.INCOME, "mdi-cash", "#4CAF50"));
        categories.add(createCategory(family, "奖金", RecordType.INCOME, "mdi-trophy", "#8BC34A"));
        categories.add(createCategory(family, "投资收益", RecordType.INCOME, "mdi-chart-line", "#CDDC39"));
        categories.add(createCategory(family, "其他收入", RecordType.INCOME, "mdi-plus-circle", "#689F38"));

        categoryRepository.saveAll(categories);
    }

    private Category createCategory(Family family, String name, RecordType type, String icon, String color) {
        return Category.builder()
                .family(family)
                .name(name)
                .type(type)
                .icon(icon)
                .color(color)
                .isCustom(false)
                .build();
    }

    public List<CategoryResponse> getFamilyCategories(Long familyId) {
        List<Category> categories = categoryRepository.findByFamilyId(familyId);
        return categories.stream()
                .map(this::buildCategoryResponse)
                .toList();
    }

    private CategoryResponse buildCategoryResponse(Category category) {
        return CategoryResponse.builder()
                .id(category.getId())
                .familyId(category.getFamily().getId())
                .name(category.getName())
                .type(category.getType())
                .icon(category.getIcon())
                .color(category.getColor())
                .isCustom(category.getIsCustom())
                .build();
    }
}
