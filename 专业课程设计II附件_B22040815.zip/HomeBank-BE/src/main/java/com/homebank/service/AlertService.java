package com.homebank.service;

import com.homebank.dto.response.AlertResponse;
import com.homebank.dto.response.BudgetStatusResponse;
import com.homebank.exception.FamilyAccessDeniedException;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Alert;
import com.homebank.model.Budget;
import com.homebank.model.User;
import com.homebank.model.enums.AlertType;
import com.homebank.repository.AlertRepository;
import com.homebank.repository.BudgetRepository;
import com.homebank.repository.UserRepository;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AlertService {

  private final AlertRepository alertRepository;
  private final BudgetRepository budgetRepository;
  private final UserRepository userRepository;
  private final BudgetService budgetService;
  private final FamilyMembershipService membershipService;

  @Transactional(readOnly = true)
  public List<AlertResponse> getAllAlerts(Long userId) {
    return alertRepository.findByUserId(userId).stream()
        .map(AlertResponse::fromAlert)
        .collect(Collectors.toList());
  }

  @Transactional(readOnly = true)
  public List<AlertResponse> getUnreadAlerts(Long userId) {
    return alertRepository.findByUserIdAndIsRead(userId, false).stream()
        .map(AlertResponse::fromAlert)
        .collect(Collectors.toList());
  }

  @Transactional
  public AlertResponse markAsRead(Long alertId, Long userId) {
    Alert alert =
        alertRepository
            .findById(alertId)
            .orElseThrow(() -> new ResourceNotFoundException("Alert not found"));

    if (!alert.getUser().getId().equals(userId)) {
      throw new FamilyAccessDeniedException("You don't have permission to access this alert");
    }

    alert.setIsRead(true);
    alert = alertRepository.save(alert);
    return AlertResponse.fromAlert(alert);
  }

  @Transactional
  public void deleteAlert(Long alertId, Long userId) {
    Alert alert =
        alertRepository
            .findById(alertId)
            .orElseThrow(() -> new ResourceNotFoundException("Alert not found"));

    if (!alert.getUser().getId().equals(userId)) {
      throw new FamilyAccessDeniedException("You don't have permission to delete this alert");
    }

    alertRepository.delete(alert);
  }

  @Transactional
  public void createAlert(Budget budget, User user, AlertType type, Double usagePercentage) {
    Integer thresholdPercentage = type == AlertType.BUDGET_WARNING ? 80 : 100;

    List<Alert> existingAlerts = alertRepository.findByBudgetId(budget.getId());
    boolean alertExists =
        existingAlerts.stream()
            .anyMatch(
                a ->
                    a.getThresholdPercentage().equals(thresholdPercentage)
                        && a.getUser().getId().equals(user.getId()));

    if (alertExists) {
      
      log.debug(
          "Alert already exists for budget {} at {}% threshold for user {}",
          budget.getId(), thresholdPercentage, user.getId());
      return;
    }

    String message =
        String.format(
            "预算预警：分类\"%s\"的预算已使用 %.1f%%，%s",
            budget.getCategory().getName(),
            usagePercentage,
            type == AlertType.BUDGET_WARNING ? "请注意控制支出" : "已超出预算");

    Alert alert =
        Alert.builder()
            .budget(budget)
            .user(user)
            .message(message)
            .type(type)
            .thresholdPercentage(thresholdPercentage)
            .isRead(false)
            .build();

    alertRepository.save(alert);
    log.info("Created alert for user {} on budget {}: {}", user.getId(), budget.getId(), message);
  }

  @Transactional
  public void checkBudgetsAndCreateAlerts() {
    log.info("Starting budget check for alerts...");

    List<BudgetStatusResponse> budgetStatuses = budgetService.checkAllActiveBudgets();

    for (BudgetStatusResponse status : budgetStatuses) {
      Budget budget =
          budgetRepository
              .findById(status.getBudgetId())
              .orElseThrow(
                  () ->
                      new ResourceNotFoundException(
                          "Budget not found with id: " + status.getBudgetId()));

      List<User> familyMembers =
          membershipService.getFamilyMembers(budget.getFamily().getId()).stream()
              .map(membership -> membership.getUser())
              .collect(Collectors.toList());

      for (User user : familyMembers) {
        
        if (status.getIsExceeded()) {
          
          createAlert(budget, user, AlertType.BUDGET_EXCEEDED, status.getUsagePercentage());
        } else if (status.getIsWarning()) {
          
          createAlert(budget, user, AlertType.BUDGET_WARNING, status.getUsagePercentage());
        }
      }
    }

    log.info("Budget check completed. Processed {} budgets.", budgetStatuses.size());
  }

  @Transactional
  public void checkBudgetAndCreateAlertForCategory(Long familyId, Long categoryId) {
    log.debug("Checking budget for family {} and category {}", familyId, categoryId);

    List<BudgetStatusResponse> budgetStatuses = budgetService.checkAllActiveBudgets();

    List<BudgetStatusResponse> relevantBudgets = budgetStatuses.stream()
        .filter(status -> {
          Budget budget = budgetRepository.findById(status.getBudgetId()).orElse(null);
          return budget != null
              && budget.getFamily().getId().equals(familyId)
              && budget.getCategory().getId().equals(categoryId);
        })
        .collect(Collectors.toList());

    for (BudgetStatusResponse status : relevantBudgets) {
      Budget budget =
          budgetRepository
              .findById(status.getBudgetId())
              .orElseThrow(
                  () ->
                      new ResourceNotFoundException(
                          "Budget not found with id: " + status.getBudgetId()));

      List<User> familyMembers =
          membershipService.getFamilyMembers(budget.getFamily().getId()).stream()
              .map(membership -> membership.getUser())
              .collect(Collectors.toList());

      for (User user : familyMembers) {
        
        if (status.getIsExceeded()) {
          
          createAlert(budget, user, AlertType.BUDGET_EXCEEDED, status.getUsagePercentage());
        } else if (status.getIsWarning()) {
          
          createAlert(budget, user, AlertType.BUDGET_WARNING, status.getUsagePercentage());
        }
      }
    }

    log.debug(
        "Real-time budget check completed. Processed {} relevant budgets.", relevantBudgets.size());
  }
}
