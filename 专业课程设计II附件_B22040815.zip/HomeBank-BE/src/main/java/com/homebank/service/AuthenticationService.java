package com.homebank.service;

import com.homebank.dto.request.LoginRequest;
import com.homebank.dto.request.RegisterRequest;
import com.homebank.dto.request.RegisterWithInvitationRequest;
import com.homebank.dto.response.AuthenticationResponse;
import com.homebank.dto.response.UserResponse;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.exception.UserAlreadyExistsException;
import com.homebank.model.Family;
import com.homebank.model.FamilyInvitation;
import com.homebank.model.FamilyMembership;
import com.homebank.model.User;
import com.homebank.model.enums.UserRole;
import com.homebank.repository.FamilyRepository;
import com.homebank.repository.UserRepository;
import com.homebank.security.JwtService;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthenticationService {

  private final UserRepository userRepository;
  private final FamilyRepository familyRepository;
  private final PasswordEncoder passwordEncoder;
  private final JwtService jwtService;
  private final AuthenticationManager authenticationManager;
  private final CategoryService categoryService;
  private final FamilyMembershipService membershipService;
  private final FamilyInvitationService invitationService;
  private final jakarta.persistence.EntityManager entityManager;

  @Transactional
  public AuthenticationResponse register(RegisterRequest request) {
    log.info("Registering new user: {}", request.getEmail());

    if (userRepository.existsByEmail(request.getEmail())) {
      throw new UserAlreadyExistsException(
          "User with email " + request.getEmail() + " already exists");
    }

    User user =
        User.builder()
            .email(request.getEmail())
            .password(passwordEncoder.encode(request.getPassword()))
            .firstName(request.getFirstName())
            .lastName(request.getLastName())
            .isActive(true)
            .build();
    user = userRepository.save(user);
    log.debug("Created user: {}", user.getId());

    Family family;
    UserRole role;

    if (request.getInvitationToken() != null && !request.getInvitationToken().isEmpty()) {
      
      log.info("User {} registering via invitation token", user.getId());
      FamilyInvitation invitation = invitationService.validateInvitation(request.getInvitationToken());

      if (!invitation.getInviteeEmail().equalsIgnoreCase(request.getEmail())) {
        throw new IllegalStateException("Email does not match invitation");
      }

      family = invitation.getFamily();
      role = invitation.getRole();

      invitation.markAsAccepted();
      invitationService.save(invitation);

    } else if (request.getAdminEmail() != null && !request.getAdminEmail().isEmpty()) {
      
      log.info("User {} registering via admin email: {}", user.getId(), request.getAdminEmail());
      User admin = userRepository.findByEmail(request.getAdminEmail())
          .orElseThrow(() -> new ResourceNotFoundException("Admin user not found with email: " + request.getAdminEmail()));

      List<FamilyMembership> adminMemberships = membershipService.getUserMemberships(admin.getId());
      if (adminMemberships.isEmpty()) {
        throw new IllegalStateException("Admin user has no family");
      }

      FamilyMembership adminMembership = adminMemberships.stream()
          .filter(m -> m.getRole() == UserRole.FAMILY_ADMIN)
          .findFirst()
          .orElseThrow(() -> new IllegalStateException("Specified user is not a family admin"));

      family = adminMembership.getFamily();
      role = UserRole.FAMILY_MEMBER;

    } else {
      
      log.info("User {} creating new family", user.getId());

      if (request.getFamilyName() == null || request.getFamilyName().isEmpty()) {
        throw new IllegalArgumentException("Family name is required when creating a new family");
      }
      if (request.getCurrency() == null || request.getCurrency().isEmpty()) {
        throw new IllegalArgumentException("Currency is required when creating a new family");
      }

      family = Family.builder()
          .name(request.getFamilyName())
          .currency(request.getCurrency())
          .build();
      family = familyRepository.save(family);
      role = UserRole.FAMILY_ADMIN;

      categoryService.createDefaultCategories(family);
    }

    membershipService.createMembership(user, family, role);
    log.debug("Created {} membership for user {} in family {}", role, user.getId(), family.getId());

    entityManager.flush();
    entityManager.clear();
    user = userRepository.findByIdWithMemberships(user.getId())
        .orElseThrow(() -> new ResourceNotFoundException("User not found after membership creation"));

    String token = jwtService.generateToken(user);

    UserResponse userResponse = buildUserResponse(user, family.getId());
    return new AuthenticationResponse(token, userResponse);
  }

  @Transactional
  public AuthenticationResponse registerWithInvitation(RegisterWithInvitationRequest request) {
    log.info("Registering user via invitation: {}", request.getEmail());

    FamilyInvitation invitation = invitationService.validateInvitation(request.getInvitationToken());

    if (!invitation.getInviteeEmail().equalsIgnoreCase(request.getEmail())) {
      throw new IllegalStateException("Email does not match invitation");
    }

    if (userRepository.existsByEmail(request.getEmail())) {
      throw new UserAlreadyExistsException(
          "User with email " + request.getEmail() + " already exists");
    }

    User user =
        User.builder()
            .email(request.getEmail())
            .password(passwordEncoder.encode(request.getPassword()))
            .firstName(request.getFirstName())
            .lastName(request.getLastName())
            .isActive(true)
            .build();
    user = userRepository.save(user);
    log.debug("Created user: {}", user.getId());

    invitationService.acceptInvitation(request.getInvitationToken(), user.getId());
    log.debug(
        "User {} accepted invitation and joined family {}",
        user.getId(),
        invitation.getFamily().getId());

    entityManager.flush(); 
    entityManager.clear(); 
    user = userRepository.findByIdWithMemberships(user.getId())
        .orElseThrow(() -> new ResourceNotFoundException("User not found after accepting invitation"));

    String token = jwtService.generateToken(user);

    UserResponse userResponse = buildUserResponse(user, invitation.getFamily().getId());
    return new AuthenticationResponse(token, userResponse);
  }

  @Transactional(readOnly = true)
  public AuthenticationResponse login(LoginRequest request) {
    log.debug("User login attempt: {}", request.getEmail());

    authenticationManager.authenticate(
        new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

    User user =
        userRepository
            .findByEmail(request.getEmail())
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    List<FamilyMembership> memberships = membershipService.getUserMemberships(user.getId());
    Long primaryFamilyId =
        memberships.isEmpty() ? null : memberships.get(0).getFamily().getId();

    String token = jwtService.generateToken(user);

    UserResponse userResponse = buildUserResponse(user, primaryFamilyId);
    return new AuthenticationResponse(token, userResponse);
  }

  private UserResponse buildUserResponse(User user, Long primaryFamilyId) {
    
    List<FamilyMembership> memberships = membershipService.getUserMemberships(user.getId());

    List<UserResponse.FamilyMembershipSummary> membershipSummaries =
        memberships.stream()
            .map(
                m ->
                    UserResponse.FamilyMembershipSummary.builder()
                        .familyId(m.getFamily().getId())
                        .familyName(m.getFamily().getName())
                        .role(m.getRole())
                        .isActive(m.getIsActive())
                        .build())
            .collect(Collectors.toList());

    FamilyMembership primaryMembership =
        primaryFamilyId != null
            ? user.getMembershipInFamily(primaryFamilyId)
            : (memberships.isEmpty() ? null : memberships.get(0));

    return UserResponse.builder()
        .id(user.getId())
        .familyId(primaryFamilyId)
        .firstName(user.getFirstName())
        .lastName(user.getLastName())
        .email(user.getEmail())
        .currency(
            primaryMembership != null
                ? primaryMembership.getFamily().getCurrency()
                : "CNY")
        .role(primaryMembership != null ? primaryMembership.getRole() : null)
        .memberships(membershipSummaries)
        .accountIds(new ArrayList<>())
        .build();
  }
}

