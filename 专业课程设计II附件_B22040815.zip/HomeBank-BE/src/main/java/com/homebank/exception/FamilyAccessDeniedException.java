package com.homebank.exception;

public class FamilyAccessDeniedException extends RuntimeException {
  public FamilyAccessDeniedException(String message) {
    super(message);
  }
}
