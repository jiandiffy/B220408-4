// 全局变量
let currentUser = null;
let authToken = null;
let selectedFood = null;

// API基础URL
const API_BASE = '';

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    // 检查是否有保存的认证令牌
    const savedToken = localStorage.getItem('authToken');
    if (savedToken) {
        authToken = savedToken;
        // 验证令牌有效性
        validateToken();
    }
    
    // 设置默认日期
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('diet-date').value = today;
    document.getElementById('analysis-start-date').value = today;
    document.getElementById('analysis-end-date').value = today;
    
    // 绑定表单事件
    bindFormEvents();
});

// 绑定表单事件
function bindFormEvents() {
    // 登录表单
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    
    // 注册表单
    document.getElementById('register-form').addEventListener('submit', handleRegister);
    
    // 个人资料表单
    document.getElementById('profile-form').addEventListener('submit', handleProfileUpdate);
}

// 显示登录表单
function showLogin() {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('register-form').style.display = 'none';
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// 显示注册表单
function showRegister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// 处理登录
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            showMainApp();
            showMessage('登录成功！', 'success');
        } else {
            showMessage(data.message || '登录失败', 'error');
        }
    } catch (error) {
        showMessage('网络错误，请稍后重试', 'error');
    }
}

// 处理注册
async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('注册成功！请登录', 'success');
            showLogin();
        } else {
            showMessage(data.message || '注册失败', 'error');
        }
    } catch (error) {
        showMessage('网络错误，请稍后重试', 'error');
    }
}

// 验证令牌
async function validateToken() {
    try {
        const response = await fetch('/api/user/profile', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            currentUser = JSON.parse(localStorage.getItem('currentUser'));
            showMainApp();
        } else {
            logout();
        }
    } catch (error) {
        logout();
    }
}

// 显示主应用
function showMainApp() {
    document.getElementById('auth-container').style.display = 'none';
    document.getElementById('main-app').style.display = 'block';
    
    // 显示用户名
    if (currentUser) {
        document.getElementById('user-name').textContent = currentUser.username;
    }
    
    // 加载仪表盘数据
    loadDashboard();
    loadUserProfile();
}

// 退出登录
function logout() {
    authToken = null;
    currentUser = null;
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    
    document.getElementById('auth-container').style.display = 'block';
    document.getElementById('main-app').style.display = 'none';
    
    // 重置表单
    document.getElementById('login-form').reset();
    document.getElementById('register-form').reset();
}

// 显示消息
function showMessage(message, type = 'info') {
    // 移除现有消息
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // 创建新消息
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;
    
    // 插入到页面顶部
    const app = document.getElementById('app');
    app.insertBefore(messageDiv, app.firstChild);
    
    // 3秒后自动移除
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}

// 导航功能
function showDashboard() {
    showSection('dashboard');
    updateNavButtons(event.target);
    loadDashboard();
}

function showDietRecord() {
    showSection('diet-record');
    updateNavButtons(event.target);
    loadDietRecords();
}

function showRecipes() {
    showSection('recipes');
    updateNavButtons(event.target);
    loadRecommendedRecipes();
}

function showAnalysis() {
    showSection('analysis');
    updateNavButtons(event.target);
}

function showProfile() {
    showSection('profile');
    updateNavButtons(event.target);
    loadUserProfile();
}

function showSection(sectionId) {
    // 隐藏所有内容区域
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // 显示目标区域
    document.getElementById(sectionId).style.display = 'block';
}

function updateNavButtons(activeButton) {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    activeButton.classList.add('active');
}

// 加载仪表盘数据
async function loadDashboard() {
    try {
        // 加载用户资料
        const profileResponse = await fetch('/api/user/profile', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (profileResponse.ok) {
            const profileData = await profileResponse.json();
            if (profileData.profile) {
                document.getElementById('current-weight').textContent = `${profileData.profile.weight || '--'} kg`;
                document.getElementById('health-goal').textContent = getHealthGoalText(profileData.profile.health_goal);
            }
        }
        
        // 加载今日营养数据
        const today = new Date().toISOString().split('T')[0];
        const nutritionResponse = await fetch(`/api/nutrition/analysis?start_date=${today}&end_date=${today}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (nutritionResponse.ok) {
            const nutritionData = await nutritionResponse.json();
            if (nutritionData.analysis && nutritionData.analysis.length > 0) {
                const todayData = nutritionData.analysis[0];
                document.getElementById('today-calories').textContent = `${Math.round(todayData.total_calories)} / 2000 kcal`;
                document.getElementById('today-protein').textContent = `${Math.round(todayData.total_protein)} / 150g`;
            } else {
                document.getElementById('today-calories').textContent = '0 / 2000 kcal';
                document.getElementById('today-protein').textContent = '0 / 150g';
            }
        }
    } catch (error) {
        console.error('加载仪表盘数据失败:', error);
    }
    // 仪表盘加载后，加载营养摄入对比图表
    loadDashboardNutritionAnalysis();
}

// 仪表盘营养分析图表
async function loadDashboardNutritionAnalysis() {
    // 获取近7天日期
    const days = 7;
    const today = new Date();
    const endDate = today.toISOString().split('T')[0];
    const weekAgo = new Date(today.getTime() - (days-1) * 86400000);
    const startDate = weekAgo.toISOString().split('T')[0];
    try {
        const response = await fetch(`/api/nutrition/analysis?start_date=${startDate}&end_date=${endDate}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        if (response.ok) {
            const data = await response.json();
            renderDashboardNutritionCharts(data.analysis || []);
        }
    } catch (error) {
        console.error('加载仪表盘分析图表失败:', error);
    }
}

// 用于绘制仪表盘营养分析图表（使用ECharts）
function renderDashboardNutritionCharts(analysis) {
    // 动态加载 ECharts（若尚未加载）
    if (!window.echarts) {
        const script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js";
        script.onload = () => renderDashboardNutritionCharts(analysis);
        document.body.appendChild(script);
        return;
    }
    const container = document.getElementById('dashboard-nutrition-charts');
    if (!analysis || analysis.length === 0) {
        container.innerHTML = '<div class="message info">近7天无营养记录</div>';
        return;
    }
    container.innerHTML = '<div id="chart-bar" style="width:100%;height:300px;"></div><div id="chart-pie" style="width:100%;height:320px;margin-top:20px;"></div>';
    // 构造日期、宏量元素
    const dates = analysis.map(day => day.record_date.slice(5)); // MM-DD
    const cals = analysis.map(day => Math.round(day.total_calories));
    const proteins = analysis.map(day => Math.round(day.total_protein));
    const carbs = analysis.map(day => Math.round(day.total_carbs));
    const fats = analysis.map(day => Math.round(day.total_fat));
    // 柱状图
    const chartBar = echarts.init(document.getElementById('chart-bar'));
    chartBar.setOption({
        title: { text: '近7天每日主要营养素摄入', left: 'center' },
        tooltip: { trigger: 'axis' },
        legend: { data: ['热量', '蛋白质', '碳水', '脂肪'], top: 30 },
        xAxis: { type: 'category', data: dates },
        yAxis: { type: 'value' },
        series: [
            { name: '热量', type: 'bar', data: cals, itemStyle: { color: '#f6c263' } },
            { name: '蛋白质', type: 'bar', data: proteins, itemStyle: { color: '#7bc27f' } },
            { name: '碳水', type: 'bar', data: carbs, itemStyle: { color: '#81b2e6' } },
            { name: '脂肪', type: 'bar', data: fats, itemStyle: { color: '#e28296' } },
        ]
    });
    // 饼图 —— 累计比例
    const sum = arr => arr.reduce((a, b) => a + b, 0);
    const proteinSum = sum(proteins), carbSum = sum(carbs), fatSum = sum(fats);
    const pieData = [
        { value: proteinSum, name: '蛋白质' },
        { value: carbSum, name: '碳水化合物' },
        { value: fatSum, name: '脂肪' },
    ];
    const chartPie = echarts.init(document.getElementById('chart-pie'));
    chartPie.setOption({
        title: { text: '7天宏量营养素比例', left: 'center' },
        tooltip: { trigger: 'item' },
        legend: { orient: 'vertical', left: 'left' },
        series: [
            {
                name: '宏量比例',
                type: 'pie',
                radius: '60%',
                data: pieData,
                label: {
                    formatter: '{b}: {d}%'
                }
            }
        ]
    });
}

// 获取健康目标文本
function getHealthGoalText(goal) {
    const goals = {
        'lose_weight': '减脂',
        'gain_weight': '增肌',
        'maintain': '维持'
    };
    return goals[goal] || '--';
}

// 加载用户资料
async function loadUserProfile() {
    try {
        const response = await fetch('/api/user/profile', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.profile) {
                // 填充表单
                document.getElementById('height').value = data.profile.height || '';
                document.getElementById('weight').value = data.profile.weight || '';
                document.getElementById('age').value = data.profile.age || '';
                document.getElementById('gender').value = data.profile.gender || '';
                document.getElementById('activity-level').value = data.profile.activity_level || '';
                document.getElementById('health-goal').value = data.profile.health_goal || '';
                document.getElementById('target-weight').value = data.profile.target_weight || '';
            }
        }
    } catch (error) {
        console.error('加载用户资料失败:', error);
    }
}

// 处理个人资料更新
async function handleProfileUpdate(e) {
    e.preventDefault();
    
    const formData = {
        height: parseFloat(document.getElementById('height').value),
        weight: parseFloat(document.getElementById('weight').value),
        age: parseInt(document.getElementById('age').value),
        gender: document.getElementById('gender').value,
        activity_level: document.getElementById('activity-level').value,
        health_goal: document.getElementById('health-goal').value,
        target_weight: parseFloat(document.getElementById('target-weight').value)
    };
    
    try {
        const response = await fetch('/api/user/profile', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('个人资料更新成功！', 'success');
            loadDashboard(); // 刷新仪表盘
        } else {
            showMessage(data.message || '更新失败', 'error');
        }
    } catch (error) {
        showMessage('网络错误，请稍后重试', 'error');
    }
}

// 加载饮食记录
async function loadDietRecords() {
    const date = document.getElementById('diet-date').value;
    const mealFilter = document.getElementById('meal-filter').value;
    
    try {
        let url = `/api/diet/records?date=${date}`;
        if (mealFilter) {
            url += `&meal_type=${mealFilter}`;
        }
        
        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayDietRecords(data.records);
        }
    } catch (error) {
        console.error('加载饮食记录失败:', error);
    }
}

// 显示饮食记录
function displayDietRecords(records) {
    const container = document.getElementById('diet-records-list');
    
    if (records.length === 0) {
        container.innerHTML = '<div class="message info">暂无饮食记录</div>';
        return;
    }
    
    container.innerHTML = records.map(record => `
        <div class="record-item">
            <div class="record-info">
                <h4>${record.food_name}</h4>
                <p>${getMealTypeText(record.meal_type)} • ${record.quantity}g</p>
            </div>
            <div class="record-nutrition">
                <div>${Math.round(record.quantity * record.calories / 100)} kcal</div>
                <div>蛋白质: ${Math.round(record.quantity * record.protein / 100)}g</div>
            </div>
        </div>
    `).join('');
}

// 获取餐次文本
function getMealTypeText(mealType) {
    const types = {
        'breakfast': '早餐',
        'lunch': '午餐',
        'dinner': '晚餐',
        'snack': '零食'
    };
    return types[mealType] || mealType;
}

// 显示添加食物模态框
function showAddFoodModal() {
    document.getElementById('add-food-modal').style.display = 'block';
    document.getElementById('food-search').value = '';
    document.getElementById('food-search-results').innerHTML = '';
    document.getElementById('selected-food').style.display = 'none';
    selectedFood = null;
    // 打开时加载全部可选食物
    loadAllFoods();
}

// 关闭添加食物模态框
function closeAddFoodModal() {
    document.getElementById('add-food-modal').style.display = 'none';
}

// 搜索食物
async function searchFoods() {
    const query = document.getElementById('food-search').value;
    
    if (query.length < 2) {
        document.getElementById('food-search-results').innerHTML = '';
        return;
    }
    
    try {
        const response = await fetch(`/api/foods?search=${encodeURIComponent(query)}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayFoodSearchResults(data.foods);
        }
    } catch (error) {
        console.error('搜索食物失败:', error);
    }
}

// 显示食物搜索结果
function displayFoodSearchResults(foods) {
    const container = document.getElementById('food-search-results');
    
    if (foods.length === 0) {
        container.innerHTML = '<div class="message info">未找到相关食物</div>';
        return;
    }
    
    container.innerHTML = foods.map(food => `
        <div class="food-item" onclick="selectFood(${JSON.stringify(food).replace(/"/g, '&quot;')})">
            <div class="food-name">${food.name}</div>
            <div class="food-nutrition">
                热量: ${food.calories}kcal/100g | 蛋白质: ${food.protein}g | 碳水: ${food.carbs}g | 脂肪: ${food.fat}g
            </div>
        </div>
    `).join('');
}

// 选择食物
function selectFood(food) {
    selectedFood = food;
    document.getElementById('selected-food').style.display = 'block';
    document.getElementById('selected-food-info').innerHTML = `
        <div class="food-name">${food.name}</div>
        <div class="food-nutrition">
            热量: ${food.calories}kcal/100g | 蛋白质: ${food.protein}g | 碳水: ${food.carbs}g | 脂肪: ${food.fat}g
        </div>
    `;
    document.getElementById('food-quantity').value = '100';
}

// 添加食物记录
async function addFoodRecord() {
    if (!selectedFood) {
        showMessage('请先选择食物', 'error');
        return;
    }
    
    const quantity = parseFloat(document.getElementById('food-quantity').value);
    const mealType = document.getElementById('meal-type').value;
    const date = document.getElementById('diet-date').value;
    
    if (!quantity || quantity <= 0) {
        showMessage('请输入有效的数量', 'error');
        return;
    }
    
    // 调试信息
    console.log('添加食物记录:', {
        selectedFood,
        quantity,
        mealType,
        date,
        authToken: authToken ? '存在' : '不存在'
    });
    
    if (!authToken) {
        showMessage('请先登录', 'error');
        console.error('认证令牌缺失，请重新登录');
        return;
    }
    
    try {
        const response = await fetch('/api/diet/record', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                food_id: selectedFood.id,
                quantity: quantity,
                meal_type: mealType,
                record_date: date
            })
        });
        
        const data = await response.json();
        console.log('API响应:', { status: response.status, data });
        
        if (response.ok) {
            showMessage('饮食记录添加成功！', 'success');
            closeAddFoodModal();
            loadDietRecords(); // 刷新记录列表
            loadDashboard(); // 刷新仪表盘
        } else {
            showMessage(data.message || '添加失败', 'error');
        }
    } catch (error) {
        console.error('添加食物记录错误:', error);
        showMessage('网络错误，请稍后重试', 'error');
    }
}

// 加载推荐食谱
async function loadRecommendedRecipes() {
    try {
        const response = await fetch('/api/recipes/recommend', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayRecipes(data.recipes);
        }
    } catch (error) {
        console.error('加载推荐食谱失败:', error);
    }
}

// 显示食谱
function displayRecipes(recipes) {
    const container = document.getElementById('recipes-list');
    
    if (recipes.length === 0) {
        container.innerHTML = '<div class="message info">暂无推荐食谱</div>';
        return;
    }
    
    container.innerHTML = recipes.map(recipe => `
        <div class="recipe-card">
            <div class="recipe-header">
                <h3>${recipe.name}</h3>
                <p>${recipe.description || '营养均衡的健康食谱'}</p>
            </div>
            <div class="recipe-content">
                <div class="recipe-stats">
                    <div class="stat-item">
                        <div class="stat-value">${Math.round(recipe.recipe_calories || recipe.total_calories)}</div>
                        <div class="stat-label">热量 (kcal)</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${recipe.prep_time || '--'}</div>
                        <div class="stat-label">准备时间 (分钟)</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${recipe.servings || '--'}</div>
                        <div class="stat-label">份数</div>
                    </div>
                </div>
                <div class="recipe-ingredients">
                    <h4>主要食材</h4>
                    <ul class="ingredient-list">
                        <li class="ingredient-item">营养均衡</li>
                        <li class="ingredient-item">健康食材</li>
                    </ul>
                </div>
            </div>
        </div>
    `).join('');
}

// 加载营养分析
async function loadNutritionAnalysis() {
    const startDate = document.getElementById('analysis-start-date').value;
    const endDate = document.getElementById('analysis-end-date').value;
    
    if (!startDate || !endDate) {
        showMessage('请选择开始和结束日期', 'error');
        return;
    }
    
    try {
        const response = await fetch(`/api/nutrition/analysis?start_date=${startDate}&end_date=${endDate}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayNutritionAnalysis(data.analysis);
        }
    } catch (error) {
        console.error('加载营养分析失败:', error);
    }
}

// 显示营养分析
function displayNutritionAnalysis(analysis) {
    const container = document.getElementById('nutrition-charts');
    
    if (analysis.length === 0) {
        container.innerHTML = '<div class="message info">所选时间段内无营养数据</div>';
        return;
    }
    
    // 计算平均值
    const avgCalories = analysis.reduce((sum, day) => sum + day.total_calories, 0) / analysis.length;
    const avgProtein = analysis.reduce((sum, day) => sum + day.total_protein, 0) / analysis.length;
    const avgCarbs = analysis.reduce((sum, day) => sum + day.total_carbs, 0) / analysis.length;
    const avgFat = analysis.reduce((sum, day) => sum + day.total_fat, 0) / analysis.length;
    
    container.innerHTML = `
        <div class="analysis-summary">
            <h3>营养分析报告</h3>
            <div class="summary-stats">
                <div class="stat-card">
                    <h4>平均每日热量</h4>
                    <p class="stat-value">${Math.round(avgCalories)} kcal</p>
                </div>
                <div class="stat-card">
                    <h4>平均每日蛋白质</h4>
                    <p class="stat-value">${Math.round(avgProtein)}g</p>
                </div>
                <div class="stat-card">
                    <h4>平均每日碳水</h4>
                    <p class="stat-value">${Math.round(avgCarbs)}g</p>
                </div>
                <div class="stat-card">
                    <h4>平均每日脂肪</h4>
                    <p class="stat-value">${Math.round(avgFat)}g</p>
                </div>
            </div>
        </div>
        <div class="daily-breakdown">
            <h4>每日详细数据</h4>
            <div class="daily-list">
                ${analysis.map(day => `
                    <div class="daily-item">
                        <div class="daily-date">${day.record_date}</div>
                        <div class="daily-nutrition">
                            <span>热量: ${Math.round(day.total_calories)}kcal</span>
                            <span>蛋白质: ${Math.round(day.total_protein)}g</span>
                            <span>碳水: ${Math.round(day.total_carbs)}g</span>
                            <span>脂肪: ${Math.round(day.total_fat)}g</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// 点击模态框外部关闭
window.onclick = function(event) {
    const modal = document.getElementById('add-food-modal');
    if (event.target === modal) {
        closeAddFoodModal();
    }
}

// 加载全部可选食物
async function loadAllFoods() {
    try {
        const response = await fetch('/api/foods', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        if (response.ok) {
            const data = await response.json();
            displayFoodSearchResults(data.foods);
        }
    } catch (error) {
        console.error('加载全部食物失败:', error);
    }
}

// Google Gemini API 密钥
const GEMINI_API_KEY = "AIzaSyDM8XN_av6hanPD47B86yGHylLiOhrhiOo";
let geminiImageBase64 = "";

// 图片选择与预览
function handleGeminiImageChange(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        geminiImageBase64 = e.target.result.split(',')[1];
        const imgPre = document.getElementById('gemini-image-preview');
        imgPre.src = e.target.result;
        imgPre.style.display = 'inline-block';
        document.getElementById('gemini-image-analyze').disabled = false;
        document.getElementById('gemini-image-result').textContent = '图片上传成功, 可AI分析';
    };
    reader.readAsDataURL(file);
}

// Gemini图片分析md转HTML
function renderGeminiMarkdown(md) {
    if (!window.marked) {
        // 动态引入 marked.js
        const script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/npm/marked/marked.min.js";
        script.onload = () => renderGeminiMarkdown(md);
        document.body.appendChild(script);
        return;
    }
    const html = window.marked.parse(md);
    document.getElementById('gemini-image-result').innerHTML = html;
}

// AI图片内容识别和营养分析
async function handleGeminiImageAnalyze() {
    if (!geminiImageBase64) {
        document.getElementById('gemini-image-result').textContent = '请先上传图片';
        return;
    }
    document.getElementById('gemini-image-result').textContent = "AI识别分析中，请稍候...";
    const url = `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const requestBody = {
        contents: [
            {
                parts: [
                    {
                        inline_data: {
                            mime_type: "image/jpeg",
                            data: geminiImageBase64
                        }
                    },
                    {
                        text: "请识别图片内所有食物种类，并估算每种的热量、蛋白质、碳水和脂肪总量，结构化成表格或详细清单。"
                    }
                ]
            }
        ]
    };
    try {
        const resp = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestBody)
        });
        if (!resp.ok) throw new Error("AI请求失败");
        const data = await resp.json();
        let result = "";
        if (data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0].text) {
            result = data.candidates[0].content.parts[0].text;
        }
        if(result){
            renderGeminiMarkdown(result);
        }else{
            document.getElementById('gemini-image-result').textContent = "AI未识别到任何内容";
        }
    } catch (e) {
        document.getElementById('gemini-image-result').textContent = 'Google Gemini 识别出错:' + e.message;
    }
}
