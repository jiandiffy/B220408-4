#!/bin/bash

echo "🚀 启动个人健康饮食管理系统"
echo "================================"

# 检查Node.js是否安装
if ! command -v node &> /dev/null; then
    echo "❌ 错误: 未找到Node.js，请先安装Node.js"
    exit 1
fi

# 检查MySQL是否运行
if ! command -v mysql &> /dev/null; then
    echo "❌ 错误: 未找到MySQL，请先安装并启动MySQL"
    exit 1
fi

# 检查数据库是否存在
echo "📊 检查数据库连接..."
mysql -u root -pB22040819 -e "USE health_diet_db;" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "📊 初始化数据库..."
    mysql -u root -pB22040819 < database/init.sql
    if [ $? -eq 0 ]; then
        echo "✅ 数据库初始化成功"
    else
        echo "❌ 数据库初始化失败，请检查MySQL连接"
        exit 1
    fi
fi

# 安装依赖
echo "📦 安装项目依赖..."
npm install

# 启动服务器
echo "🌟 启动服务器..."
echo "访问地址: http://localhost:3000"
echo "按 Ctrl+C 停止服务器"
echo "================================"

node server.js
