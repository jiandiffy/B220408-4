const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const config = require('./config');

const app = express();
const PORT = config.port;

// 中间件
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// 数据库连接
const db = mysql.createConnection(config.database);

db.connect((err) => {
  if (err) {
    console.error('数据库连接失败:', err);
    return;
  }
  console.log('数据库连接成功');
});

// JWT验证中间件
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: '访问令牌缺失' });
  }

  jwt.verify(token, config.jwtSecret, (err, user) => {
    if (err) {
      return res.status(403).json({ message: '无效的访问令牌' });
    }
    req.user = user;
    next();
  });
};

// 用户注册
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    // 检查用户是否已存在
    const checkUser = 'SELECT * FROM users WHERE username = ? OR email = ?';
    db.query(checkUser, [username, email], (err, results) => {
      if (err) {
        return res.status(500).json({ message: '数据库查询错误' });
      }
      
      if (results.length > 0) {
        return res.status(400).json({ message: '用户名或邮箱已存在' });
      }
      
      // 加密密码
      const saltRounds = 10;
      bcrypt.hash(password, saltRounds, (err, hash) => {
        if (err) {
          return res.status(500).json({ message: '密码加密失败' });
        }
        
        // 插入新用户
        const insertUser = 'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)';
        db.query(insertUser, [username, email, hash], (err, result) => {
          if (err) {
            return res.status(500).json({ message: '用户创建失败' });
          }
          
          res.status(201).json({ 
            message: '用户注册成功',
            userId: result.insertId 
          });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 用户登录
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  const getUser = 'SELECT * FROM users WHERE username = ? OR email = ?';
  db.query(getUser, [username, username], (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    
    if (results.length === 0) {
      return res.status(401).json({ message: '用户名或密码错误' });
    }
    
    const user = results[0];
    bcrypt.compare(password, user.password_hash, (err, isMatch) => {
      if (err) {
        return res.status(500).json({ message: '密码验证错误' });
      }
      
      if (!isMatch) {
        return res.status(401).json({ message: '用户名或密码错误' });
      }
      
      // 生成JWT令牌
      const token = jwt.sign(
        { userId: user.id, username: user.username },
        config.jwtSecret,
        { expiresIn: '24h' }
      );
      
      res.json({
        message: '登录成功',
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email
        }
      });
    });
  });
});

// 获取用户个人信息
app.get('/api/user/profile', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  
  const getProfile = `
    SELECT up.*, u.username, u.email 
    FROM user_profiles up 
    JOIN users u ON up.user_id = u.id 
    WHERE up.user_id = ?
  `;
  
  db.query(getProfile, [userId], (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    
    if (results.length === 0) {
      return res.json({ profile: null });
    }
    
    res.json({ profile: results[0] });
  });
});

// 更新用户个人信息
app.put('/api/user/profile', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  const { height, weight, age, gender, activity_level, health_goal, target_weight } = req.body;
  
  // 检查是否已有个人资料
  const checkProfile = 'SELECT * FROM user_profiles WHERE user_id = ?';
  db.query(checkProfile, [userId], (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    
    if (results.length === 0) {
      // 创建新个人资料
      const insertProfile = `
        INSERT INTO user_profiles 
        (user_id, height, weight, age, gender, activity_level, health_goal, target_weight) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;
      db.query(insertProfile, [userId, height, weight, age, gender, activity_level, health_goal, target_weight], (err, result) => {
        if (err) {
          return res.status(500).json({ message: '个人资料创建失败' });
        }
        res.json({ message: '个人资料创建成功' });
      });
    } else {
      // 更新现有个人资料
      const updateProfile = `
        UPDATE user_profiles 
        SET height = ?, weight = ?, age = ?, gender = ?, activity_level = ?, health_goal = ?, target_weight = ?
        WHERE user_id = ?
      `;
      db.query(updateProfile, [height, weight, age, gender, activity_level, health_goal, target_weight, userId], (err, result) => {
        if (err) {
          return res.status(500).json({ message: '个人资料更新失败' });
        }
        res.json({ message: '个人资料更新成功' });
      });
    }
  });
});

// 获取食物列表
app.get('/api/foods', (req, res) => {
  const { search, category } = req.query;
  let query = 'SELECT * FROM food_nutrition WHERE 1=1';
  let params = [];
  
  if (search) {
    query += ' AND name LIKE ?';
    params.push(`%${search}%`);
  }
  
  if (category) {
    query += ' AND category = ?';
    params.push(category);
  }
  
  query += ' ORDER BY name';
  
  db.query(query, params, (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    res.json({ foods: results });
  });
});

// 添加饮食记录
app.post('/api/diet/record', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  const { food_id, quantity, meal_type, record_date } = req.body;
  
  const insertRecord = `
    INSERT INTO diet_records (user_id, food_id, quantity, meal_type, record_date) 
    VALUES (?, ?, ?, ?, ?)
  `;
  
  db.query(insertRecord, [userId, food_id, quantity, meal_type, record_date], (err, result) => {
    if (err) {
      return res.status(500).json({ message: '饮食记录添加失败' });
    }
    res.json({ message: '饮食记录添加成功', recordId: result.insertId });
  });
});

// 获取饮食记录
app.get('/api/diet/records', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  const { date } = req.query;
  
  let query = `
    SELECT dr.*, fn.name as food_name, fn.calories, fn.protein, fn.carbs, fn.fat
    FROM diet_records dr
    JOIN food_nutrition fn ON dr.food_id = fn.id
    WHERE dr.user_id = ?
  `;
  let params = [userId];
  
  if (date) {
    query += ' AND dr.record_date = ?';
    params.push(date);
  }
  
  query += ' ORDER BY dr.record_date DESC, dr.created_at DESC';
  
  db.query(query, params, (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    res.json({ records: results });
  });
});

// 获取营养分析报告
app.get('/api/nutrition/analysis', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  const { start_date, end_date } = req.query;
  
  let query = `
    SELECT 
      dr.record_date,
      SUM(dr.quantity * fn.calories / 100) as total_calories,
      SUM(dr.quantity * fn.protein / 100) as total_protein,
      SUM(dr.quantity * fn.carbs / 100) as total_carbs,
      SUM(dr.quantity * fn.fat / 100) as total_fat
    FROM diet_records dr
    JOIN food_nutrition fn ON dr.food_id = fn.id
    WHERE dr.user_id = ?
  `;
  let params = [userId];
  
  if (start_date && end_date) {
    query += ' AND dr.record_date BETWEEN ? AND ?';
    params.push(start_date, end_date);
  }
  
  query += ' GROUP BY dr.record_date ORDER BY dr.record_date DESC';
  
  db.query(query, params, (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    res.json({ analysis: results });
  });
});

// 获取食谱推荐
app.get('/api/recipes/recommend', authenticateToken, (req, res) => {
  const { calories_needed, preferences } = req.query;
  
  let query = `
    SELECT rt.*, 
           SUM(ri.quantity * fn.calories / 100) as recipe_calories
    FROM recipe_templates rt
    JOIN recipe_ingredients ri ON rt.id = ri.recipe_id
    JOIN food_nutrition fn ON ri.food_id = fn.id
    WHERE 1=1
  `;
  let params = [];
  
  if (calories_needed) {
    query += ' HAVING recipe_calories <= ?';
    params.push(calories_needed);
  }
  
  query += ' GROUP BY rt.id ORDER BY RAND() LIMIT 10';
  
  db.query(query, params, (err, results) => {
    if (err) {
      return res.status(500).json({ message: '数据库查询错误' });
    }
    res.json({ recipes: results });
  });
});

// 静态文件服务
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});
