module.exports = {
  database: {
    host: 'localhost',
    user: 'root',
    password: 'MY-B22040819',
    database: 'health_diet_db'
  },
  jwtSecret: 'your_jwt_secret_key_here',
  port: 3000
};
