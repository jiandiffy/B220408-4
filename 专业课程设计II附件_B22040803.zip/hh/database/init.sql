-- 创建数据库
CREATE DATABASE IF NOT EXISTS health_diet_db;
USE health_diet_db;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 用户个人信息表
CREATE TABLE IF NOT EXISTS user_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    height DECIMAL(5,2), -- 身高(cm)
    weight DECIMAL(5,2), -- 体重(kg)
    age INT, -- 年龄
    gender ENUM('male', 'female'), -- 性别
    activity_level ENUM('sedentary', 'light', 'moderate', 'active', 'very_active'), -- 活动水平
    health_goal ENUM('lose_weight', 'gain_weight', 'maintain'), -- 健康目标
    target_weight DECIMAL(5,2), -- 目标体重
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 食物营养库表
CREATE TABLE IF NOT EXISTS food_nutrition (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50), -- 食物类别
    calories DECIMAL(8,2) NOT NULL, -- 热量(每100g)
    protein DECIMAL(8,2) NOT NULL, -- 蛋白质(g)
    carbs DECIMAL(8,2) NOT NULL, -- 碳水化合物(g)
    fat DECIMAL(8,2) NOT NULL, -- 脂肪(g)
    fiber DECIMAL(8,2) DEFAULT 0, -- 纤维(g)
    sugar DECIMAL(8,2) DEFAULT 0, -- 糖(g)
    sodium DECIMAL(8,2) DEFAULT 0, -- 钠(mg)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 用户饮食记录表
CREATE TABLE IF NOT EXISTS diet_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity DECIMAL(8,2) NOT NULL, -- 摄入量(g)
    meal_type ENUM('breakfast', 'lunch', 'dinner', 'snack'), -- 餐次
    record_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (food_id) REFERENCES food_nutrition(id) ON DELETE CASCADE
);

-- 食谱模板表
CREATE TABLE IF NOT EXISTS recipe_templates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    difficulty ENUM('easy', 'medium', 'hard'),
    prep_time INT, -- 准备时间(分钟)
    cook_time INT, -- 烹饪时间(分钟)
    servings INT, -- 份数
    total_calories DECIMAL(8,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 食谱食材表
CREATE TABLE IF NOT EXISTS recipe_ingredients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    recipe_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity DECIMAL(8,2) NOT NULL,
    unit VARCHAR(20) DEFAULT 'g',
    FOREIGN KEY (recipe_id) REFERENCES recipe_templates(id) ON DELETE CASCADE,
    FOREIGN KEY (food_id) REFERENCES food_nutrition(id) ON DELETE CASCADE
);

-- 用户偏好设置表
CREATE TABLE IF NOT EXISTS user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    preferred_cuisine VARCHAR(50), -- 偏好菜系
    dietary_restrictions TEXT, -- 饮食限制
    disliked_foods TEXT, -- 不喜欢的食物
    allergies TEXT, -- 过敏原
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 插入示例食物数据
INSERT INTO food_nutrition (name, category, calories, protein, carbs, fat, fiber, sugar, sodium) VALUES
-- 主食类
('Rice', 'Staple', 130, 2.6, 28, 0.3, 0.4, 0.1, 5),
('Oats', 'Staple', 389, 17, 66, 7, 11, 1, 2),
('Whole Wheat Bread', 'Staple', 247, 13, 41, 4.2, 7, 4.3, 681),
('Noodles', 'Staple', 131, 5, 25, 1.1, 1.8, 0.4, 5),
('Potato', 'Staple', 77, 2, 17, 0.1, 2.2, 0.8, 6),
('Sweet Potato', 'Staple', 86, 1.6, 20, 0.1, 3, 4.2, 4),

-- 肉类
('Chicken Breast', 'Meat', 165, 31, 0, 3.6, 0, 0, 74),
('Beef', 'Meat', 250, 26, 0, 15, 0, 0, 72),
('Pork', 'Meat', 242, 27, 0, 14, 0, 0, 62),
('Lamb', 'Meat', 294, 25, 0, 21, 0, 0, 72),
('Duck', 'Meat', 337, 19, 0, 28, 0, 0, 74),

-- 蛋类
('Egg', 'Egg', 155, 13, 1.1, 11, 0, 1.1, 124),
('Duck Egg', 'Egg', 185, 13, 1.4, 14, 0, 0.6, 146),

-- 乳制品
('Milk', 'Dairy', 42, 3.4, 5, 1, 0, 4.8, 44),
('Yogurt', 'Dairy', 59, 10, 3.6, 0.4, 0, 3.6, 36),
('Cheese', 'Dairy', 113, 25, 1.3, 0.4, 0, 0.1, 621),
('Butter', 'Dairy', 717, 0.9, 0.1, 81, 0, 0.1, 11),

-- 水果
('Apple', 'Fruit', 52, 0.3, 14, 0.2, 2.4, 10, 1),
('Banana', 'Fruit', 89, 1.1, 23, 0.3, 2.6, 12, 1),
('Orange', 'Fruit', 47, 0.9, 12, 0.1, 2.4, 9, 0),
('Grape', 'Fruit', 67, 0.6, 17, 0.4, 0.9, 16, 2),
('Strawberry', 'Fruit', 32, 0.7, 8, 0.3, 2, 4.9, 1),
('Blueberry', 'Fruit', 57, 0.7, 14, 0.3, 2.4, 10, 1),

-- 蔬菜
('Broccoli', 'Vegetable', 34, 2.8, 7, 0.4, 2.6, 1.5, 33),
('Carrot', 'Vegetable', 41, 0.9, 10, 0.2, 2.8, 4.7, 69),
('Spinach', 'Vegetable', 23, 2.9, 3.6, 0.4, 2.2, 0.4, 79),
('Tomato', 'Vegetable', 18, 0.9, 3.9, 0.2, 1.2, 2.6, 5),
('Cucumber', 'Vegetable', 16, 0.7, 4, 0.1, 0.5, 1.7, 2),
('Eggplant', 'Vegetable', 25, 1, 6, 0.2, 3, 3.5, 2),

-- 鱼类
('Salmon', 'Fish', 208, 20, 0, 13, 0, 0, 44),
('Tuna', 'Fish', 144, 30, 0, 1, 0, 0, 37),
('Sea Bass', 'Fish', 97, 20, 0, 1.2, 0, 0, 68),
('Hairtail', 'Fish', 127, 18, 0, 5.6, 0, 0, 150),

-- 坚果类
('Almond', 'Nuts', 579, 21, 22, 50, 12, 4.4, 1),
('Walnut', 'Nuts', 654, 15, 14, 65, 6.7, 2.6, 2),
('Peanut', 'Nuts', 567, 26, 16, 49, 8.5, 4.7, 18),

-- 豆类
('Tofu', 'Beans', 76, 8, 2, 4.8, 0.3, 1.2, 7),
('Soybean', 'Beans', 446, 36, 30, 20, 9, 7, 2),
('Mung Bean', 'Beans', 347, 24, 63, 1.2, 16, 0.8, 2);

-- 插入示例食谱数据
INSERT INTO recipe_templates (name, description, category, difficulty, prep_time, cook_time, servings, total_calories) VALUES
('Healthy Oatmeal Breakfast', 'Nutritious oatmeal rich in fiber and protein', 'Breakfast', 'easy', 5, 10, 1, 300),
('Steamed Chicken Breast', 'Low-fat, high-protein chicken breast, perfect for weight loss', 'Main Course', 'easy', 10, 20, 1, 200),
('Fresh Vegetable Salad', 'Fresh vegetable combination rich in vitamins', 'Salad', 'easy', 15, 0, 1, 150),
('Salmon with Broccoli', 'High-quality protein with green vegetables', 'Main Course', 'medium', 15, 25, 1, 350),
('Fruit Yogurt Cup', 'Refreshing fruit yogurt, perfect for afternoon tea', 'Dessert', 'easy', 10, 0, 1, 200),
('Whole Wheat Sandwich', 'Healthy whole wheat bread with vegetables and protein', 'Light Meal', 'easy', 10, 5, 1, 400),
('Steamed Egg Custard', 'Smooth steamed eggs, nutritious and easy to digest', 'Soup', 'easy', 5, 15, 1, 120),
('Vegetable Soup', 'Light vegetable soup, perfect for dinner', 'Soup', 'easy', 10, 20, 1, 80);

-- 插入食谱食材数据
INSERT INTO recipe_ingredients (recipe_id, food_id, quantity, unit) VALUES
-- 健康早餐燕麦粥
(1, 2, 50, 'g'),  -- 燕麦
(1, 4, 200, 'ml'), -- 牛奶
(1, 5, 1, '个'),   -- 苹果

-- 清蒸鸡胸肉
(2, 2, 150, 'g'), -- 鸡胸肉
(2, 7, 100, 'g'), -- 西兰花

-- 蔬菜沙拉
(3, 7, 50, 'g'),  -- 西兰花
(3, 8, 50, 'g'),  -- 胡萝卜
(3, 9, 30, 'g'),  -- 菠菜
(3, 10, 50, 'g'), -- 番茄

-- 三文鱼配西兰花
(4, 11, 120, 'g'), -- 三文鱼
(4, 7, 100, 'g'),  -- 西兰花

-- 水果酸奶杯
(5, 3, 200, 'g'), -- 酸奶
(5, 5, 1, '个'),   -- 苹果
(5, 6, 1, '个'),   -- 香蕉

-- 全麦三明治
(6, 3, 2, '片'),   -- 全麦面包
(6, 2, 80, 'g'),   -- 鸡胸肉
(6, 10, 30, 'g'),  -- 番茄
(6, 9, 20, 'g');   -- 菠菜
