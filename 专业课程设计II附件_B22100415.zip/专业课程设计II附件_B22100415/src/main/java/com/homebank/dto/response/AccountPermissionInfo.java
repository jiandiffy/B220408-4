package com.homebank.dto.response;

import com.homebank.model.AccountPermission;
import com.homebank.model.enums.AccountPermissionType;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountPermissionInfo {

  private Long userId;
  private String userEmail;
  private String userFirstName;
  private String userLastName;
  private AccountPermissionType permission;
  private LocalDateTime grantedAt;

  public static AccountPermissionInfo fromAccountPermission(AccountPermission permission) {
    return AccountPermissionInfo.builder()
        .userId(permission.getUser().getId())
        .userEmail(permission.getUser().getEmail())
        .userFirstName(permission.getUser().getFirstName())
        .userLastName(permission.getUser().getLastName())
        .permission(permission.getPermission())
        .grantedAt(permission.getGrantedAt())
        .build();
  }
}
