package com.homebank.controller;

import com.homebank.dto.request.LoginRequest;
import com.homebank.dto.request.RegisterRequest;
import com.homebank.dto.response.AuthenticationResponse;
import com.homebank.service.AuthenticationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "认证API")
public class AuthenticationController {

  private final AuthenticationService authenticationService;

  @PostMapping("/register")
  @Operation(summary = "注册新的家庭管理员", description = "注册新用户作为家庭管理员并创建新家庭")
  public ResponseEntity<AuthenticationResponse> register(
      @Valid @RequestBody RegisterRequest request) {
    AuthenticationResponse response = authenticationService.register(request);
    return new ResponseEntity<>(response, HttpStatus.CREATED);
  }

  @PostMapping("/login")
  @Operation(summary = "用户登录", description = "验证用户身份并返回JWT令牌")
  public ResponseEntity<AuthenticationResponse> login(@Valid @RequestBody LoginRequest request) {
    AuthenticationResponse response = authenticationService.login(request);
    return ResponseEntity.ok(response);
  }
}
