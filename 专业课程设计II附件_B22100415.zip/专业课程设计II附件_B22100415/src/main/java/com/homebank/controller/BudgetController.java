package com.homebank.controller;

import com.homebank.dto.request.BudgetRequest;
import com.homebank.dto.request.UpdateBudgetRequest;
import com.homebank.dto.response.BudgetResponse;
import com.homebank.dto.response.BudgetStatusResponse;
import com.homebank.model.User;
import com.homebank.service.BudgetService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families/{familyId}/budgets")
@RequiredArgsConstructor
@Tag(name = "Budget", description = "预算管理API")
@SecurityRequirement(name = "bearer-key")
public class BudgetController {

  private final BudgetService budgetService;

  @GetMapping
  @Operation(summary = "获取所有预算", description = "获取当前家庭的所有预算")
  public ResponseEntity<List<BudgetResponse>> getAllBudgets(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    List<BudgetResponse> budgets = budgetService.getAllBudgets(currentUser.getId(), familyId);
    return ResponseEntity.ok(budgets);
  }

  @GetMapping("/{id}")
  @Operation(summary = "根据ID获取预算", description = "根据ID获取预算详情")
  public ResponseEntity<BudgetResponse> getBudgetById(
      @PathVariable Long familyId,
      @PathVariable Long id,
      @AuthenticationPrincipal User currentUser) {
    BudgetResponse budget = budgetService.getBudgetById(id, currentUser.getId());
    return ResponseEntity.ok(budget);
  }

  @PostMapping
  @Operation(summary = "创建预算", description = "创建新预算（仅管理员）")
  public ResponseEntity<BudgetResponse> createBudget(
      @PathVariable Long familyId,
      @Valid @RequestBody BudgetRequest request,
      @AuthenticationPrincipal User currentUser) {
    BudgetResponse budget = budgetService.createBudget(request, currentUser.getId(), familyId);
    return ResponseEntity.status(HttpStatus.CREATED).body(budget);
  }

  @PutMapping("/{id}")
  @Operation(summary = "更新预算", description = "更新现有预算（仅管理员）")
  public ResponseEntity<BudgetResponse> updateBudget(
      @PathVariable Long familyId,
      @PathVariable Long id,
      @Valid @RequestBody UpdateBudgetRequest request,
      @AuthenticationPrincipal User currentUser) {
    BudgetResponse budget = budgetService.updateBudget(id, request, currentUser.getId());
    return ResponseEntity.ok(budget);
  }

  @DeleteMapping("/{id}")
  @Operation(summary = "删除预算", description = "删除预算（仅管理员）")
  public ResponseEntity<Void> deleteBudget(
      @PathVariable Long familyId,
      @PathVariable Long id,
      @AuthenticationPrincipal User currentUser) {
    budgetService.deleteBudget(id, currentUser.getId());
    return ResponseEntity.noContent().build();
  }

  @GetMapping("/{id}/status")
  @Operation(summary = "获取预算状态", description = "获取预算执行状态及使用百分比")
  public ResponseEntity<BudgetStatusResponse> getBudgetStatus(
      @PathVariable Long familyId,
      @PathVariable Long id,
      @AuthenticationPrincipal User currentUser) {
    BudgetStatusResponse status = budgetService.getBudgetStatus(id, currentUser.getId());
    return ResponseEntity.ok(status);
  }
}
