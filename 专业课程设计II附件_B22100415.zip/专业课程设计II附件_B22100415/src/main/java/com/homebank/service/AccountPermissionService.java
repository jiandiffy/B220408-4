package com.homebank.service;

import com.homebank.exception.FamilyAccessDeniedException;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Account;
import com.homebank.model.AccountPermission;
import com.homebank.model.User;
import com.homebank.model.enums.AccountPermissionType;
import com.homebank.repository.AccountPermissionRepository;
import com.homebank.repository.AccountRepository;
import com.homebank.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountPermissionService {

  private final AccountPermissionRepository permissionRepository;
  private final AccountRepository accountRepository;
  private final UserRepository userRepository;
  private final FamilyMembershipService membershipService;

  @Transactional
  public AccountPermission grantPermission(
      Long accountId,
      Long targetUserId,
      AccountPermissionType permissionType,
      Long grantedByUserId) {
    log.debug(
        "User {} granting {} permission on account {} to user {}",
        grantedByUserId,
        permissionType,
        accountId,
        targetUserId);

    Account account =
        accountRepository
            .findById(accountId)
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    requireEditPermission(grantedByUserId, accountId, account.getFamily().getId());

    membershipService.requireMember(targetUserId, account.getFamily().getId());

    User targetUser =
        userRepository
            .findById(targetUserId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    User grantedByUser =
        userRepository
            .findById(grantedByUserId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    AccountPermission existingPermission =
        permissionRepository.findByAccountIdAndUserId(accountId, targetUserId).orElse(null);

    if (existingPermission != null) {
      
      log.debug("Updating existing permission for user {} on account {}", targetUserId, accountId);
      existingPermission.setPermission(permissionType);
      existingPermission.setGrantedBy(grantedByUser);
      existingPermission.setGrantedAt(LocalDateTime.now());
      return permissionRepository.save(existingPermission);
    }

    AccountPermission permission =
        AccountPermission.builder()
            .account(account)
            .user(targetUser)
            .permission(permissionType)
            .grantedBy(grantedByUser)
            .grantedAt(LocalDateTime.now())
            .build();

    return permissionRepository.save(permission);
  }

  @Transactional
  public void revokePermission(Long accountId, Long targetUserId, Long operatorUserId) {
    log.debug(
        "User {} revoking permission on account {} from user {}",
        operatorUserId,
        accountId,
        targetUserId);

    Account account =
        accountRepository
            .findById(accountId)
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    requireEditPermission(operatorUserId, accountId, account.getFamily().getId());

    if (targetUserId.equals(operatorUserId)) {
      throw new IllegalStateException("Cannot revoke your own permission");
    }

    permissionRepository.deleteByAccountIdAndUserId(accountId, targetUserId);
  }

  public List<Long> getVisibleAccountIds(Long userId) {
    return permissionRepository.findVisibleAccountIdsByUserId(userId);
  }

  public List<Long> getEditableAccountIds(Long userId) {
    return permissionRepository.findEditableAccountIdsByUserId(userId);
  }

  @Transactional(readOnly = true)
  public List<AccountPermission> getAccountPermissions(Long accountId) {
    return permissionRepository.findByAccountIdWithUser(accountId);
  }

  public AccountPermissionType getPermissionType(Long userId, Long accountId) {
    return permissionRepository.getPermissionType(userId, accountId).orElse(null);
  }

  public boolean hasPermission(Long userId, Long accountId) {
    return permissionRepository.hasPermission(userId, accountId);
  }

  public boolean hasEditPermission(Long userId, Long accountId) {
    return permissionRepository.hasEditPermission(userId, accountId);
  }

  public void requirePermission(Long userId, Long accountId, Long familyId) {
    
    if (membershipService.isAdmin(userId, familyId)) {
      return;
    }

    if (!hasPermission(userId, accountId)) {
      throw new FamilyAccessDeniedException("You don't have permission to access this account");
    }
  }

  public void requireEditPermission(Long userId, Long accountId, Long familyId) {
    
    if (membershipService.isAdmin(userId, familyId)) {
      return;
    }

    if (!hasEditPermission(userId, accountId)) {
      throw new FamilyAccessDeniedException("You don't have permission to edit this account");
    }
  }

  @Transactional
  public AccountPermission grantCreatorPermission(Account account, User creator) {
    log.debug(
        "Granting creator permission on account {} to user {}", account.getId(), creator.getId());

    AccountPermission permission =
        AccountPermission.builder()
            .account(account)
            .user(creator)
            .permission(AccountPermissionType.EDIT)
            .grantedBy(null) 
            .grantedAt(LocalDateTime.now())
            .build();

    return permissionRepository.save(permission);
  }

  @Transactional
  public List<AccountPermission> batchGrantPermission(
      Long accountId,
      List<Long> targetUserIds,
      AccountPermissionType permissionType,
      Long grantedByUserId) {
    return targetUserIds.stream()
        .map(userId -> grantPermission(accountId, userId, permissionType, grantedByUserId))
        .toList();
  }

  @Transactional
  public void deleteAllAccountPermissions(Long accountId) {
    log.debug("Deleting all permissions for account {}", accountId);
    permissionRepository.deleteByAccountId(accountId);
  }
}
