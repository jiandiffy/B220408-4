package com.homebank.service;

import com.homebank.exception.FamilyAccessDeniedException;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Family;
import com.homebank.model.FamilyMembership;
import com.homebank.model.User;
import com.homebank.model.enums.UserRole;
import com.homebank.repository.FamilyMembershipRepository;
import com.homebank.repository.FamilyRepository;
import com.homebank.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class FamilyMembershipService {

  private final FamilyMembershipRepository membershipRepository;
  private final UserRepository userRepository;
  private final FamilyRepository familyRepository;

  @Transactional
  public FamilyMembership createMembership(User user, Family family, UserRole role) {
    log.debug("Creating membership for user {} in family {}", user.getId(), family.getId());

    if (membershipRepository.existsActiveByUserIdAndFamilyId(user.getId(), family.getId())) {
      throw new IllegalStateException("User is already a member of this family");
    }

    FamilyMembership membership =
        FamilyMembership.builder()
            .user(user)
            .family(family)
            .role(role)
            .isActive(true)
            .joinedAt(LocalDateTime.now())
            .build();

    return membershipRepository.save(membership);
  }

  public FamilyMembership getMembership(Long userId, Long familyId) {
    return membershipRepository
        .findActiveByUserIdAndFamilyId(userId, familyId)
        .orElseThrow(
            () ->
                new ResourceNotFoundException(
                    "User is not a member of family " + familyId));
  }

  public List<FamilyMembership> getFamilyMembers(Long familyId) {
    return membershipRepository.findActiveByFamilyIdWithUser(familyId);
  }

  public List<FamilyMembership> getUserMemberships(Long userId) {
    return membershipRepository.findActiveByUserId(userId);
  }

  public boolean isMember(Long userId, Long familyId) {
    return membershipRepository.existsActiveByUserIdAndFamilyId(userId, familyId);
  }

  public boolean isAdmin(Long userId, Long familyId) {
    return membershipRepository.isUserAdminInFamily(userId, familyId);
  }

  public void requireAdmin(Long userId, Long familyId) {
    if (!isAdmin(userId, familyId)) {
      throw new FamilyAccessDeniedException("Only family admins can perform this action");
    }
  }

  public void requireMember(Long userId, Long familyId) {
    if (!isMember(userId, familyId)) {
      throw new FamilyAccessDeniedException("User is not a member of this family");
    }
  }

  @Transactional
  public FamilyMembership updateMemberRole(
      Long familyId, Long targetUserId, UserRole newRole, Long operatorUserId) {
    log.debug(
        "Admin {} updating role for user {} in family {} to {}",
        operatorUserId,
        targetUserId,
        familyId,
        newRole);

    requireAdmin(operatorUserId, familyId);

    FamilyMembership membership = getMembership(targetUserId, familyId);

    if (membership.getRole() == UserRole.FAMILY_ADMIN
        && newRole == UserRole.FAMILY_MEMBER) {
      long adminCount = membershipRepository.countAdminsByFamilyId(familyId);
      if (adminCount <= 1) {
        throw new IllegalStateException("Cannot demote the last admin of the family");
      }
    }

    membership.setRole(newRole);
    return membershipRepository.save(membership);
  }

  @Transactional
  public void deactivateMember(Long familyId, Long targetUserId, Long operatorUserId) {
    log.debug("Admin {} deactivating user {} in family {}", operatorUserId, targetUserId, familyId);

    requireAdmin(operatorUserId, familyId);

    if (targetUserId.equals(operatorUserId)) {
      throw new IllegalStateException("Cannot deactivate yourself");
    }

    FamilyMembership membership = getMembership(targetUserId, familyId);

    if (membership.getRole() == UserRole.FAMILY_ADMIN) {
      long adminCount = membershipRepository.countAdminsByFamilyId(familyId);
      if (adminCount <= 1) {
        throw new IllegalStateException("Cannot deactivate the last admin of the family");
      }
    }

    membership.setIsActive(false);
    membershipRepository.save(membership);
  }

  @Transactional
  public void activateMember(Long familyId, Long targetUserId, Long operatorUserId) {
    log.debug("Admin {} activating user {} in family {}", operatorUserId, targetUserId, familyId);

    requireAdmin(operatorUserId, familyId);

    FamilyMembership membership =
        membershipRepository
            .findByUserIdAndFamilyId(targetUserId, familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Membership not found"));

    membership.setIsActive(true);
    membershipRepository.save(membership);
  }

  @Transactional
  public void leaveFam(Long userId, Long familyId) {
    log.debug("User {} leaving family {}", userId, familyId);

    FamilyMembership membership = getMembership(userId, familyId);

    if (membership.getRole() == UserRole.FAMILY_ADMIN) {
      long adminCount = membershipRepository.countAdminsByFamilyId(familyId);
      if (adminCount <= 1) {
        long memberCount = membershipRepository.countActiveByFamilyId(familyId);
        if (memberCount > 1) {
          throw new IllegalStateException(
              "Cannot leave family as the last admin. Please transfer admin role first");
        }
        
        log.info("Last member leaving family {}, family will be deleted", familyId);
        familyRepository.deleteById(familyId);
        return;
      }
    }

    membershipRepository.delete(membership);
  }

  @Transactional
  public void removeMember(Long familyId, Long targetUserId, Long operatorUserId) {
    log.debug("Admin {} removing user {} from family {}", operatorUserId, targetUserId, familyId);

    requireAdmin(operatorUserId, familyId);

    if (targetUserId.equals(operatorUserId)) {
      throw new IllegalStateException("Cannot remove yourself. Use leave family instead");
    }

    FamilyMembership membership = getMembership(targetUserId, familyId);

    if (membership.getRole() == UserRole.FAMILY_ADMIN) {
      long adminCount = membershipRepository.countAdminsByFamilyId(familyId);
      if (adminCount <= 1) {
        throw new IllegalStateException("Cannot remove the last admin of the family");
      }
    }

    membershipRepository.delete(membership);
  }

  public long countFamilyMembers(Long familyId) {
    return membershipRepository.countActiveByFamilyId(familyId);
  }

  public long countFamilyAdmins(Long familyId) {
    return membershipRepository.countAdminsByFamilyId(familyId);
  }

  public User getUserById(Long userId) {
    return userRepository
        .findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("User not found"));
  }

  public List<Long> getUserFamilyIds(Long userId) {
    return getUserMemberships(userId).stream()
        .map(membership -> membership.getFamily().getId())
        .toList();
  }
}
