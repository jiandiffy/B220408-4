package com.homebank.model.enums;

public enum AccountPermissionType {
  VISIBLE,  
  EDIT      
}
