package com.homebank.model;

import com.homebank.model.enums.RecordType;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "categories")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Category {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne
  @JoinColumn(name = "family_id", nullable = false)
  private Family family;

  @Column(nullable = false, length = 100)
  private String name;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  private RecordType type;

  @Column(length = 50)
  private String icon;

  @Column(length = 20)
  private String color;

  @Column(name = "is_custom", nullable = false)
  private Boolean isCustom = false;

  @CreationTimestamp
  @Column(name = "created_at", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "updated_at")
  private LocalDateTime updatedAt;

  @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
  private List<Record> records = new ArrayList<>();

  @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
  private List<Budget> budgets = new ArrayList<>();
}
