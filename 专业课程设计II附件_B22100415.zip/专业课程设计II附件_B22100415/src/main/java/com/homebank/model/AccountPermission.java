package com.homebank.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.homebank.model.enums.AccountPermissionType;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(
    name = "account_permissions",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"account_id", "user_id"})})
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class AccountPermission {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "account_id", nullable = false)
  @com.fasterxml.jackson.annotation.JsonIgnore
  private Account account;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "user_id", nullable = false)
  @JsonIgnoreProperties({"password", "memberships", "accountPermissions", "hibernateLazyInitializer", "handler"})
  private User user;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  @Builder.Default
  private AccountPermissionType permission = AccountPermissionType.VISIBLE;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "granted_by")
  @JsonIgnoreProperties({"password", "memberships", "accountPermissions", "hibernateLazyInitializer", "handler"})
  private User grantedBy;

  @Column(name = "granted_at")
  private LocalDateTime grantedAt;

  @CreationTimestamp
  @Column(name = "created_at", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "updated_at")
  private LocalDateTime updatedAt;

  public boolean hasEditPermission() {
    return AccountPermissionType.EDIT.equals(permission);
  }

  public boolean hasVisiblePermission() {
    return permission != null;
  }
}
