package com.homebank.model.enums;

public enum BudgetPeriod {
  MONTHLY,
  QUARTERLY,
  YEARLY
}
