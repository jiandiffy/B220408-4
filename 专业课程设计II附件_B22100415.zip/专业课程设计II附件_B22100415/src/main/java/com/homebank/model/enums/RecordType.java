package com.homebank.model.enums;

public enum RecordType {
  INCOME,
  EXPENSE
}
