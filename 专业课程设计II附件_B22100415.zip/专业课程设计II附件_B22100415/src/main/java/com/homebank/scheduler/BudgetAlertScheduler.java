package com.homebank.scheduler;

import com.homebank.service.AlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class BudgetAlertScheduler {

  private final AlertService alertService;

  @Scheduled(cron = "0 0 * * * *")
  public void checkBudgetsAndTriggerAlerts() {
    log.info("=== Starting scheduled budget check ===");
    try {
      alertService.checkBudgetsAndCreateAlerts();
      log.info("=== Scheduled budget check completed successfully ===");
    } catch (Exception e) {
      log.error("Error during scheduled budget check: {}", e.getMessage(), e);
    }
  }
}
