package com.homebank.repository;

import com.homebank.model.Budget;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {

  List<Budget> findByFamilyId(Long familyId);

  List<Budget> findByCategoryId(Long categoryId);

  @Query("SELECT b FROM Budget b WHERE b.startDate <= :date AND b.endDate >= :date")
  List<Budget> findActiveBudgets(LocalDate date);
}
