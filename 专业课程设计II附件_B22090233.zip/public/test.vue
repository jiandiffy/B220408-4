<template>
    <div>
        <input v-model="inputValue" @change="debouncedFetchData">
        <br>
        <select v-model="inputValue">
            <option v-for="item in matchedData" :key="item" @click="inputValue = item">{{ item }}</option>
        </select>
    </div>  
</template>

<script>
   const inputValue = ref('');
    const keyword = ref('');

    // 匹配输入内容
    const matchInput = () => {
        keyword.value = inputValue.value;
    };

    // 总的数据
    const allData = ref([]);
    // 匹配到的数据
    const matchedData = ref([]);
    // 拿到数据匹配
    // 添加一个防抖
    const debounce = (func, delay) => {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), delay);
        };
    }

    const fetchData = async () => {
    try {
        const response = await fetch('https://api.example.com/data');
        const data = await response.json();
        allData.value = data;
        matchedData.value = data.filter(item => item.includes(keyword.value));
    } catch (error) {
        console.error('Error fetching data:', error);
    }
    const debouncedFetchData = debounce(fetchData, 300);
};
</script>