# Pet Health Platform — 启动说明

> 本说明适用于项目根目录：`实验周/`（包含 `package.json` 和 `src/server.js`）。

## 一键启动（PowerShell）

1. 打开 PowerShell，切换到项目目录：

```powershell
Set-Location -Path 'c:\Users\86184\Desktop\专业课程设计II报告_B22040809\实验周'
```

2. 安装依赖（当前 `package.json` 没有外部依赖，但执行不会有害）：

```powershell
npm install
```

3. 启动后端（使用 package.json 中的 `start` 脚本）：

```powershell
npm start
```

默认情况下，服务器会读取环境变量 `PORT` 作为端口（如果未设置则默认为 3000）。

在同一会话中指定端口示例：

```powershell
$env:PORT = "8000"; npm start
```

或者在新的 PowerShell 进程中后台打开（示例：在默认浏览器打开前端）：

```powershell
# 用默认浏览器打开首页
Start-Process "http://localhost:3000"
```

## 项目结构（简要）

- `src/server.js` - 简单的 Node.js HTTP 服务器，负责提供 `public/` 下的静态文件并实现若干 REST API（例如 `/api/login`, `/api/dashboard` 等）。
- `public/` - 前端静态资源，入口为 `public/index.html`。
- `data/store.json` - 本地数据存储（由 `src/storage.js` 读写）。

## 常见问题

- `node` 或 `npm` 未被识别：请先安装 Node.js（建议 LTS 版本），并确保安装程序将 Node 加入 PATH。可以运行 `node -v` 和 `npm -v` 检查。 
- 端口占用：如果 3000 被占用，使用 `$env:PORT = "<port>"; npm start` 指定其它端口。
- 日志与错误：服务器会在启动的 PowerShell 窗口输出日志。出现错误时请查看该窗口的 stderr 输出。

## 开发/调试提示

- 如果想让服务器在后台运行，可以使用 Windows 的任务或 PowerShell 的 `Start-Process` 启动一个新窗口：

```powershell
Start-Process powershell -ArgumentList '-NoProfile','-Command','Set-Location "C:\path\to\project"; npm start'
```

- 若要停止运行的服务器：在对应的 PowerShell 窗口按 Ctrl+C。

## API 快速概览（部分）

- POST /api/login — 登录，Body 包含 `email` 和 `password`（可选 `role`）。
- GET /api/dashboard?userId=<id> — 获取用户仪表盘数据。
- POST /api/pets — 添加宠物。

（更多端点见 `src/server.js` 中的实现）

---

如果你希望我把 README 翻译成英文、补充示例请求（curl）或添加 VS Code 任务配置（tasks.json）来一键启动，我可以继续为你实现这些改进。
