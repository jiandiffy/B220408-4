const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const db = require('./config/db');
const path = require('path');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..'))); // 提供静态文件

// ============ 用户相关 API ============

// 用户注册
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, role } = req.body;

    // 验证输入
    if (!username || !password || !role) {
      return res.status(400).json({ success: false, message: '请填写完整信息！' });
    }

    // 管理员不能注册
    if (role === 'admin') {
      return res.status(400).json({ success: false, message: '管理员账号不能注册！' });
    }

    // 检查用户名是否已存在
    const [existingUsers] = await db.query(
      'SELECT id FROM users WHERE username = ?',
      [username]
    );

    if (existingUsers.length > 0) {
      return res.status(400).json({ success: false, message: '用户名已存在！' });
    }

    // 加密密码
    const hashedPassword = await bcrypt.hash(password, 10);

    // 插入新用户
    const [result] = await db.query(
      'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
      [username, hashedPassword, role]
    );

    console.log(`✅ 新用户注册: ${username} (${role})`);
    res.json({ success: true, message: '注册成功！', userId: result.insertId });
  } catch (error) {
    console.error('注册错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 用户登录
app.post('/api/login', async (req, res) => {
  try {
    const { username, password, role } = req.body;

    // 查询用户
    const [users] = await db.query(
      'SELECT * FROM users WHERE username = ?',
      [username]
    );

    if (users.length === 0) {
      return res.status(401).json({ success: false, message: '用户名不存在！' });
    }

    const user = users[0];

    // 验证密码
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: '密码错误！' });
    }

    // 验证角色
    if (user.role !== role) {
      return res.status(401).json({ success: false, message: '角色选择错误！' });
    }

    console.log(`✅ 用户登录: ${username} (${role})`);
    
    // 返回用户信息（不包含密码）
    res.json({
      success: true,
      message: '登录成功！',
      user: {
        id: user.id,
        username: user.username,
        role: user.role
      }
    });
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取用户信息
app.get('/api/user/:id', async (req, res) => {
  try {
    const [users] = await db.query(
      'SELECT id, username, role, created_at FROM users WHERE id = ?',
      [req.params.id]
    );

    if (users.length === 0) {
      return res.status(404).json({ success: false, message: '用户不存在！' });
    }

    res.json({ success: true, user: users[0] });
  } catch (error) {
    console.error('获取用户信息错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ============ 充电桩相关 API ============

// 发布充电桩
app.post('/api/charging-stations', async (req, res) => {
  try {
    const { ownerId, location, type, price, availableTime, startTime, endTime, enablePeakValley } = req.body;

    // 验证输入
    if (!ownerId || !location || !type || !price) {
      return res.status(400).json({ success: false, message: '请填写完整信息！' });
    }

    // 验证时间格式
    if (startTime && endTime) {
      if (startTime >= endTime) {
        return res.status(400).json({ success: false, message: '结束时间必须晚于开始时间！' });
      }
    }

    const [result] = await db.query(
      'INSERT INTO charging_stations (owner_id, location, type, price, available_time, available_start_time, available_end_time, enable_peak_valley, power_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [ownerId, location, type, price, availableTime || '全天', startTime || '00:00:00', endTime || '23:59:59', enablePeakValley || false, 'off']
    );

    console.log(`✅ 新充电桩发布: ID=${result.insertId}, 位置=${location}, 可用时段=${availableTime}, 峰谷电价=${enablePeakValley ? '启用' : '禁用'}`);
    res.json({ success: true, message: '充电桩发布成功，等待管理员审核！', stationId: result.insertId });
  } catch (error) {
    console.error('发布充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取充电桩列表
app.get('/api/charging-stations', async (req, res) => {
  try {
    const { status, ownerId } = req.query;
    let query = 'SELECT cs.*, u.username as owner_name FROM charging_stations cs LEFT JOIN users u ON cs.owner_id = u.id';
    const params = [];
    const conditions = [];

    if (status) {
      conditions.push('cs.status = ?');
      params.push(status);
    }
    if (ownerId) {
      conditions.push('cs.owner_id = ?');
      params.push(ownerId);
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    query += ' ORDER BY cs.created_at DESC';

    const [stations] = await db.query(query, params);
    res.json({ success: true, stations });
  } catch (error) {
    console.error('获取充电桩列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ⚠️ 重要：搜索路由必须放在 :id 路由之前
// 搜索充电桩（支持按位置/价格/类型筛选和排序）
app.get('/api/charging-stations/search', async (req, res) => {
  try {
    const { location, type, minPrice, maxPrice, sortBy = 'price', order = 'ASC' } = req.query;
    
    let query = 'SELECT cs.*, u.username as owner_name FROM charging_stations cs LEFT JOIN users u ON cs.owner_id = u.id WHERE cs.status = ?';
    const params = ['approved'];
    
    if (location) {
      query += ' AND cs.location LIKE ?';
      params.push(`%${location}%`);
    }
    if (type) {
      query += ' AND cs.type = ?';
      params.push(type);
    }
    if (minPrice) {
      query += ' AND cs.price >= ?';
      params.push(minPrice);
    }
    if (maxPrice) {
      query += ' AND cs.price <= ?';
      params.push(maxPrice);
    }
    
    // 排序：price（价格）或 location（位置，实际按地址字母序）
    const validSortBy = ['price', 'location', 'created_at'];
    const validOrder = ['ASC', 'DESC'];
    const sortColumn = validSortBy.includes(sortBy) ? sortBy : 'price';
    const sortOrder = validOrder.includes(order.toUpperCase()) ? order.toUpperCase() : 'ASC';
    
    query += ` ORDER BY cs.${sortColumn} ${sortOrder}`;
    
    const [stations] = await db.query(query, params);
    
    console.log(`🔍 搜索充电桩: 找到 ${stations.length} 个结果`);
    res.json({ success: true, stations });
  } catch (error) {
    console.error('搜索充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取单个充电桩详情（必须放在搜索路由之后）
app.get('/api/charging-stations/:id', async (req, res) => {
  try {
    const [stations] = await db.query(
      'SELECT cs.*, u.username as owner_name FROM charging_stations cs LEFT JOIN users u ON cs.owner_id = u.id WHERE cs.id = ?',
      [req.params.id]
    );

    if (stations.length === 0) {
      return res.status(404).json({ success: false, message: '充电桩不存在！' });
    }

    res.json({ success: true, station: stations[0] });
  } catch (error) {
    console.error('获取充电桩详情错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ✅ 新增：检查充电桩可用性（是否被占用）
app.get('/api/charging-stations/:id/availability', async (req, res) => {
  try {
    const [activeBookings] = await db.query(
      'SELECT b.id FROM bookings b WHERE b.station_id = ? AND b.status IN (?, ?)',

      [req.params.id, 'pending', 'confirmed']
    );

    if (activeBookings.length > 0) {
      res.json({
        success: true,
        available: false,
        message: '充电桩正在使用中'
      });
    } else {
      res.json({
        success: true,
        available: true,
        message: '充电桩可用'
      });
    }
  } catch (error) {
    console.error('检查充电桩可用性错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 远程控制充电桩开关
app.put('/api/charging-stations/:id/power', async (req, res) => {
  try {
    const { powerStatus, ownerId } = req.body;

    // 验证充电桩所有权
    const [stations] = await db.query(
      'SELECT * FROM charging_stations WHERE id = ? AND owner_id = ?',
      [req.params.id, ownerId]
    );

    if (stations.length === 0) {
      return res.status(403).json({ success: false, message: '无权操作此充电桩！' });
    }

    if (stations[0].status !== 'approved') {
      return res.status(400).json({ success: false, message: '充电桩未通过审核，无法控制！' });
    }

    await db.query(
      'UPDATE charging_stations SET power_status = ? WHERE id = ?',
      [powerStatus, req.params.id]
    );

    console.log(`✅ 充电桩电源状态更新: ID=${req.params.id}, 状态=${powerStatus}`);
    res.json({ success: true, message: `充电桩已${powerStatus === 'on' ? '开启' : '关闭'}！` });
  } catch (error) {
    console.error('控制充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 删除充电桩
app.delete('/api/charging-stations/:id', async (req, res) => {
  try {
    const { ownerId } = req.query;

    // 验证充电桩所有权
    const [stations] = await db.query(
      'SELECT * FROM charging_stations WHERE id = ? AND owner_id = ?',
      [req.params.id, ownerId]
    );

    if (stations.length === 0) {
      return res.status(403).json({ success: false, message: '无权删除此充电桩！' });
    }

    await db.query('DELETE FROM charging_stations WHERE id = ?', [req.params.id]);

    console.log(`✅ 充电桩已删除: ID=${req.params.id}`);
    res.json({ success: true, message: '充电桩删除成功！' });
  } catch (error) {
    console.error('删除充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 审核充电桩
app.put('/api/charging-stations/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    
    await db.query(
      'UPDATE charging_stations SET status = ? WHERE id = ?',
      [status, req.params.id]
    );

    console.log(`✅ 充电桩状态更新: ID=${req.params.id}, 状态=${status}`);
    res.json({ success: true, message: '状态更新成功！' });
  } catch (error) {
    console.error('更新状态错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取收益统计
app.get('/api/revenues/stats/:ownerId', async (req, res) => {
  try {
    // 本月收益
    const [monthlyRevenue] = await db.query(
      `SELECT COALESCE(SUM(amount), 0) as monthly_revenue 
       FROM revenues 
       WHERE owner_id = ? 
       AND YEAR(created_at) = YEAR(CURRENT_DATE()) 
       AND MONTH(created_at) = MONTH(CURRENT_DATE())`,
      [req.params.ownerId]
    );

    // 累计收益
    const [totalRevenue] = await db.query(
      'SELECT COALESCE(SUM(amount), 0) as total_revenue FROM revenues WHERE owner_id = ?',
      [req.params.ownerId]
    );

    res.json({
      success: true,
      stats: {
        monthlyRevenue: monthlyRevenue[0].monthly_revenue,
        totalRevenue: totalRevenue[0].total_revenue
      }
    });
  } catch (error) {
    console.error('获取收益统计错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取收益明细列表
app.get('/api/revenues/:ownerId', async (req, res) => {
  try {
    const [revenues] = await db.query(
      `SELECT r.*, cs.location, cs.type, u.username as user_name, b.booking_time, b.end_time, b.duration
       FROM revenues r
       LEFT JOIN charging_stations cs ON r.station_id = cs.id
       LEFT JOIN bookings b ON r.booking_id = b.id
       LEFT JOIN users u ON b.user_id = u.id
       WHERE r.owner_id = ?
       ORDER BY r.created_at DESC
       LIMIT 50`,
      [req.params.ownerId]
    );

    res.json({ success: true, revenues });
  } catch (error) {
    console.error('获取收益明细错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ============ 充电用户相关 API ============

// ⚠️ 注意：具体路径的路由必须放在动态参数路由之前

// 获取用户的充电统计（具体路径，放在前面）
app.get('/api/bookings/stats/:userId', async (req, res) => {
  try {
    // 总充电次数
    const [totalCount] = await db.query(
      'SELECT COUNT(*) as total FROM bookings WHERE user_id = ? AND status = ?',
      [req.params.userId, 'completed']
    );
    
    // 总花费（确保amount不为NULL）
    const [totalAmount] = await db.query(
      'SELECT COALESCE(SUM(amount), 0) as total FROM bookings WHERE user_id = ? AND status = ? AND amount IS NOT NULL',
      [req.params.userId, 'completed']
    );
    
    // 本月花费（使用end_time而不是booking_time）
    const [monthlyAmount] = await db.query(
      `SELECT COALESCE(SUM(amount), 0) as monthly 
       FROM bookings 
       WHERE user_id = ? AND status = ? AND amount IS NOT NULL
       AND YEAR(end_time) = YEAR(CURRENT_DATE()) 
       AND MONTH(end_time) = MONTH(CURRENT_DATE())`,
      [req.params.userId, 'completed']
    );
    
    console.log(`📊 获取用户统计: 用户ID=${req.params.userId}, 完成次数=${totalCount[0].total}, 总花费=${totalAmount[0].total}, 本月花费=${monthlyAmount[0].monthly}`);
    res.json({
      success: true,
      stats: {
        totalCount: totalCount[0].total,
        totalAmount: totalAmount[0].total,
        monthlyAmount: monthlyAmount[0].monthly
      }
    });
  } catch (error) {
    console.error('获取充电统计错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取用户的预约/订单列表（具体路径，放在前面）
app.get('/api/bookings/user/:userId', async (req, res) => {
  try {
    const [bookings] = await db.query(
      `SELECT b.*, 
        cs.location, cs.type, cs.price, cs.available_time, cs.owner_id, 
        u.username as owner_name,
        r.id as review_id,
        r.rating as review_rating,
        r.comment as review_comment
       FROM bookings b
       LEFT JOIN charging_stations cs ON b.station_id = cs.id
       LEFT JOIN users u ON cs.owner_id = u.id
       LEFT JOIN reviews r ON b.id = r.booking_id
       WHERE b.user_id = ?
       ORDER BY b.booking_time DESC
       LIMIT 50`,
      [req.params.userId]
    );
    
    console.log(`📋 获取用户订单: 用户ID=${req.params.userId}, 订单数=${bookings.length}`);
    res.json({ success: true, bookings });
  } catch (error) {
    console.error('获取预约列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 预约充电桩
app.post('/api/bookings', async (req, res) => {
  try {
    const { userId, stationId } = req.body;
    
    if (!userId || !stationId) {
      return res.status(400).json({ success: false, message: '参数不完整！' });
    }
    
    // 检查充电桩是否存在且已审核通过
    const [stations] = await db.query(
      'SELECT * FROM charging_stations WHERE id = ? AND status = ?',
      [stationId, 'approved']
    );
    
    if (stations.length === 0) {
      return res.status(404).json({ success: false, message: '充电桩不存在或未通过审核！' });
    }
    
    const station = stations[0];
    
    // 检查充电桩电源状态
    if (station.power_status !== 'on') {
      return res.status(400).json({ success: false, message: '充电桩电源未开启！' });
    }
    
    // 检查是否在可用时段内
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:00`;
    
    if (station.available_start_time && station.available_end_time) {
      if (currentTime < station.available_start_time || currentTime > station.available_end_time) {
        return res.status(400).json({ 
          success: false, 
          message: `充电桩当前不在可用时段内！可用时段：${station.available_time}` 
        });
      }
    }
    
    // ✅ 新增：检查充电桩是否已被其他用户占用
    const [activeBookingsOnStation] = await db.query(
      'SELECT b.id FROM bookings b WHERE b.station_id = ? AND b.status IN (?, ?)',

      [stationId, 'pending', 'confirmed']
    );
    
    if (activeBookingsOnStation.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: '充电桩正在被其他用户使用，请稍后再试！' 
      });
    }
    
    // 检查当前用户是否有进行中的预约（任意充电桩）
    const [activeBookings] = await db.query(
      'SELECT * FROM bookings WHERE user_id = ? AND status IN (?, ?)',

      [userId, 'pending', 'confirmed']
    );
    
    if (activeBookings.length > 0) {
      return res.status(400).json({ success: false, message: '您有正在进行的充电，请先完成！' });
    }
    
    // 创建预约（设置booking_time为当前时间）
    const [result] = await db.query(
      'INSERT INTO bookings (user_id, station_id, status, booking_time) VALUES (?, ?, ?, NOW())',
      [userId, stationId, 'confirmed']
    );
    
    console.log(`✅ 新预约创建: ID=${result.insertId}, 用户=${userId}, 充电桩=${stationId}`);
    res.json({ success: true, message: '预约成功！', bookingId: result.insertId });
  } catch (error) {
    console.error('预约充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 开始充电
app.put('/api/bookings/:id/start', async (req, res) => {
  try {
    const { userId } = req.body;
    
    // 验证预约归属
    const [bookings] = await db.query(
      'SELECT b.*, cs.power_status FROM bookings b LEFT JOIN charging_stations cs ON b.station_id = cs.id WHERE b.id = ? AND b.user_id = ?',
      [req.params.id, userId]
    );
    
    if (bookings.length === 0) {
      return res.status(403).json({ success: false, message: '无权操作此预约！' });
    }
    
    const booking = bookings[0];
    
    if (booking.status !== 'confirmed') {
      return res.status(400).json({ success: false, message: '预约状态不正确！' });
    }
    
    if (booking.power_status !== 'on') {
      return res.status(400).json({ success: false, message: '充电桩电源未开启！' });
    }
    
    // 开始充电时更新开始时间为当前时间
    await db.query(
      'UPDATE bookings SET booking_time = NOW() WHERE id = ?',
      [req.params.id]
    );
    
    console.log(`✅ 开始充电: 预约ID=${req.params.id}`);
    res.json({ success: true, message: '充电已开始，计费开始计算！' });
  } catch (error) {
    console.error('开始充电错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 峰谷电价计算函数
function calculatePeakValleyRate(startTime, endTime) {
  // 将时间字符串转换为分钟数
  function timeToMinutes(timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  }

  // 定义24小时时段覆盖（分钟）- 确保覆盖所有时间
  const periods = [
    // 谷时段：00:00-07:00
    { start: 0, end: 7 * 60, rate: 0.5, name: '谷' },
    // 平时段：07:00-10:00
    { start: 7 * 60, end: 10 * 60, rate: 1.0, name: '平' },
    // 峰时段：10:00-15:00
    { start: 10 * 60, end: 15 * 60, rate: 1.5, name: '峰' },
    // 平时段：15:00-18:00
    { start: 15 * 60, end: 18 * 60, rate: 1.0, name: '平' },
    // 峰时段：18:00-21:00
    { start: 18 * 60, end: 21 * 60, rate: 1.5, name: '峰' },
    // 平时段：21:00-23:00
    { start: 21 * 60, end: 23 * 60, rate: 1.0, name: '平' },
    // 谷时段：23:00-24:00
    { start: 23 * 60, end: 24 * 60, rate: 0.5, name: '谷' }
  ];

  const start = timeToMinutes(startTime);
  const end = timeToMinutes(endTime);
  const totalDuration = end - start;

  if (totalDuration <= 0) {
    console.log('⚠️ 充电时长无效，返回默认费率1.0');
    return 1.0;
  }

  let totalWeightedRate = 0;
  const periodDetails = [];

  // 遍历每个时段，计算重叠部分
  periods.forEach(period => {
    const overlapStart = Math.max(start, period.start);
    const overlapEnd = Math.min(end, period.end);
    const overlap = Math.max(0, overlapEnd - overlapStart);

    if (overlap > 0) {
      const weightedRate = overlap * period.rate;
      totalWeightedRate += weightedRate;
      periodDetails.push({
        name: period.name,
        duration: (overlap / 60).toFixed(2),
        rate: period.rate,
        contribution: weightedRate
      });
    }
  });

  const averageRate = totalWeightedRate / totalDuration;

  // 详细日志
  console.log('📊 峰谷电价计算详情:');
  console.log(`   充电时段: ${startTime} - ${endTime}`);
  console.log(`   总时长: ${(totalDuration / 60).toFixed(2)} 小时`);
  periodDetails.forEach(p => {
    console.log(`   - ${p.name}时段: ${p.duration}h × ${p.rate} = ${(p.contribution / 60).toFixed(2)}`);
  });
  console.log(`   平均费率: ${averageRate.toFixed(4)}`);

  return averageRate;
}

// 结束充电并计算费用
app.put('/api/bookings/:id/end', async (req, res) => {
  try {
    const { userId } = req.body;
    
    // 获取预约信息
    const [bookings] = await db.query(
      `SELECT b.*, cs.price, cs.owner_id, cs.location, cs.type, cs.enable_peak_valley 
       FROM bookings b 
       LEFT JOIN charging_stations cs ON b.station_id = cs.id 
       WHERE b.id = ? AND b.user_id = ?`,
      [req.params.id, userId]
    );
    
    if (bookings.length === 0) {
      return res.status(403).json({ success: false, message: '无权操作此预约！' });
    }
    
    const booking = bookings[0];
    
    if (booking.status !== 'confirmed') {
      return res.status(400).json({ success: false, message: '预约状态不正确！' });
    }
    
    // 计算充电时长（小时）和费用
    const startTime = new Date(booking.booking_time);
    const endTime = new Date();
    const duration = (endTime - startTime) / (1000 * 60 * 60); // 转换为小时
    
    let amount = duration * booking.price;
    let priceDetail = `基础价格: ¥${booking.price}/度 × ${duration.toFixed(2)}h = ¥${amount.toFixed(2)}`;

    // 如果启用了峰谷电价
    if (booking.enable_peak_valley) {
      const startTimeStr = startTime.toTimeString().substring(0, 5);
      const endTimeStr = endTime.toTimeString().substring(0, 5);
      const rate = calculatePeakValleyRate(startTimeStr, endTimeStr);
      const originalAmount = duration * booking.price;
      amount = originalAmount * rate;
      
      priceDetail = `峰谷电价计算:\n` +
        `基础: ¥${booking.price}/度 × ${duration.toFixed(2)}h = ¥${originalAmount.toFixed(2)}\n` +
        `倍率: ${rate.toFixed(4)}\n` +
        `实际费用: ¥${originalAmount.toFixed(2)} × ${rate.toFixed(4)} = ¥${amount.toFixed(2)}`;
      
      console.log(`⚡ 峰谷电价结算: 时段${startTimeStr}-${endTimeStr}, 倍率=${rate.toFixed(4)}, 原价¥${originalAmount.toFixed(2)}, 实付¥${amount.toFixed(2)}`);
    }
    
    // 更新预约记录
    await db.query(
      'UPDATE bookings SET end_time = NOW(), duration = ?, amount = ?, status = ? WHERE id = ?',
      [duration, amount, 'completed', req.params.id]
    );
    
    // 记录收益
    await db.query(
      'INSERT INTO revenues (owner_id, station_id, booking_id, amount) VALUES (?, ?, ?, ?)',
      [booking.owner_id, booking.station_id, req.params.id, amount]
    );
    
    console.log(`✅ 结束充电: 预约ID=${req.params.id}, 时长=${duration.toFixed(2)}h, 费用=¥${amount.toFixed(2)} (${booking.enable_peak_valley ? '峰谷电价' : '固定电价'})`);
    res.json({ 
      success: true, 
      message: '充电已完成！', 
      duration: duration.toFixed(2),
      amount: amount.toFixed(2),
      priceDetail
    });
  } catch (error) {
    console.error('结束充电错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 取消预约
app.delete('/api/bookings/:id', async (req, res) => {
  try {
    const { userId } = req.query;
    
    // 验证预约归属
    const [bookings] = await db.query(
      'SELECT * FROM bookings WHERE id = ? AND user_id = ?',
      [req.params.id, userId]
    );
    
    if (bookings.length === 0) {
      return res.status(403).json({ success: false, message: '无权操作此预约！' });
    }
    
    const booking = bookings[0];
    
    if (booking.status === 'completed') {
      return res.status(400).json({ success: false, message: '已完成的订单无法取消！' });
    }
    
    // 更新状态为已取消
    await db.query(
      'UPDATE bookings SET status = ? WHERE id = ?',
      ['cancelled', req.params.id]
    );
    
    console.log(`✅ 预约已取消: ID=${req.params.id}`);
    res.json({ success: true, message: '预约已取消！' });
  } catch (error) {
    console.error('取消预约错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ============ 评价系统 API ============

// 提交评价
app.post('/api/reviews', async (req, res) => {
  try {
    const { userId, ownerId, stationId, bookingId, rating, comment } = req.body;

    // 验证订单是否完成
    const [bookings] = await db.query(
      'SELECT * FROM bookings WHERE id = ? AND user_id = ? AND status = ?',
      [bookingId, userId, 'completed']
    );

    if (bookings.length === 0) {
      return res.status(400).json({ success: false, message: '只能评价已完成的订单！' });
    }

    // 检查是否已评价
    const [existingReviews] = await db.query(
      'SELECT id FROM reviews WHERE booking_id = ?',
      [bookingId]
    );

    if (existingReviews.length > 0) {
      return res.status(400).json({ success: false, message: '该订单已评价过！' });
    }

    // 插入评价
    await db.query(
      'INSERT INTO reviews (user_id, owner_id, station_id, booking_id, rating, comment) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, ownerId, stationId, bookingId, rating, comment]
    );

    console.log(`✅ 新评价: 用户${userId}评价桩主${ownerId}, 评分${rating}星`);
    res.json({ success: true, message: '评价提交成功！' });
  } catch (error) {
    console.error('提交评价错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取充电桩的评价列表
app.get('/api/reviews/station/:stationId', async (req, res) => {
  try {
    const [reviews] = await db.query(
      `SELECT r.*, u.username as user_name 
       FROM reviews r 
       LEFT JOIN users u ON r.user_id = u.id 
       WHERE r.station_id = ? 
       ORDER BY r.created_at DESC`,
      [req.params.stationId]
    );

    res.json({ success: true, reviews });
  } catch (error) {
    console.error('获取评价列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取桩主的所有评价
app.get('/api/reviews/owner/:ownerId', async (req, res) => {
  try {
    const [reviews] = await db.query(
      `SELECT r.*, u.username as user_name, cs.location 
       FROM reviews r 
       LEFT JOIN users u ON r.user_id = u.id 
       LEFT JOIN charging_stations cs ON r.station_id = cs.id
       WHERE r.owner_id = ? 
       ORDER BY r.created_at DESC`,
      [req.params.ownerId]
    );

    // 计算平均评分
    const [avgRating] = await db.query(
      'SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews FROM reviews WHERE owner_id = ?',
      [req.params.ownerId]
    );

    res.json({ 
      success: true, 
      reviews,
      avgRating: Number(avgRating[0].avg_rating || 0).toFixed(1),
      totalReviews: avgRating[0].total_reviews
    });
  } catch (error) {
    console.error('获取桩主评价错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ============ 纠纷投诉 API ============

// 提交纠纷投诉
app.post('/api/disputes', async (req, res) => {
  try {
    const { userId, stationId, bookingId, type, description } = req.body;

    if (!userId || !stationId || !type || !description) {
      return res.status(400).json({ success: false, message: '请填写完整信息！' });
    }

    await db.query(
      'INSERT INTO disputes (user_id, station_id, booking_id, type, description) VALUES (?, ?, ?, ?, ?)',
      [userId, stationId, bookingId || null, type, description]
    );

    console.log(`✅ 新纠纷投诉: 用户${userId}投诉充电桩${stationId}, 类型${type}`);
    res.json({ success: true, message: '投诉已提交，管理员将尽快处理！' });
  } catch (error) {
    console.error('提交投诉错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取用户的投诉列表
app.get('/api/disputes/user/:userId', async (req, res) => {
  try {
    const [disputes] = await db.query(
      `SELECT d.*, cs.location, cs.owner_id, o.username as owner_name
       FROM disputes d
       LEFT JOIN charging_stations cs ON d.station_id = cs.id
       LEFT JOIN users o ON cs.owner_id = o.id
       WHERE d.user_id = ?
       ORDER BY d.created_at DESC`,
      [req.params.userId]
    );

    res.json({ success: true, disputes });
  } catch (error) {
    console.error('获取投诉列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 管理员获取所有纠纷投诉
app.get('/api/admin/disputes', async (req, res) => {
  try {
    const { status } = req.query;
    
    let query = `
      SELECT d.*, 
        u.username as user_name,
        cs.location,
        o.username as owner_name
      FROM disputes d
      LEFT JOIN users u ON d.user_id = u.id
      LEFT JOIN charging_stations cs ON d.station_id = cs.id
      LEFT JOIN users o ON cs.owner_id = o.id
    `;
    
    const params = [];
    if (status) {
      query += ' WHERE d.status = ?';
      params.push(status);
    }
    
    query += ' ORDER BY d.created_at DESC';
    
    const [disputes] = await db.query(query, params);

    res.json({ success: true, disputes });
  } catch (error) {
    console.error('获取纠纷列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 管理员处理纠纷
app.put('/api/admin/disputes/:id', async (req, res) => {
  try {
    const { status, adminReply } = req.body;

    if (!['processing', 'resolved', 'rejected'].includes(status)) {
      return res.status(400).json({ success: false, message: '无效的处理状态！' });
    }

    await db.query(
      'UPDATE disputes SET status = ?, admin_reply = ? WHERE id = ?',
      [status, adminReply || null, req.params.id]
    );

    console.log(`✅ 管理员处理纠纷: ID=${req.params.id}, 状态=${status}`);
    res.json({ success: true, message: '纠纷处理成功！' });
  } catch (error) {
    console.error('处理纠纷错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ============ 管理员相关 API ============

// 获取所有待审核的充电桩
app.get('/api/admin/charging-stations/pending', async (req, res) => {
  try {
    const [stations] = await db.query(
      `SELECT cs.*, u.username as owner_name 
       FROM charging_stations cs 
       LEFT JOIN users u ON cs.owner_id = u.id 
       WHERE cs.status = 'pending' 
       ORDER BY cs.created_at DESC`
    );
    
    res.json({ success: true, stations });
  } catch (error) {
    console.error('获取待审核充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取所有充电桩（管理员视图）
app.get('/api/admin/charging-stations/all', async (req, res) => {
  try {
    const [stations] = await db.query(
      `SELECT cs.*, u.username as owner_name 
       FROM charging_stations cs 
       LEFT JOIN users u ON cs.owner_id = u.id 
       ORDER BY cs.created_at DESC`
    );
    
    res.json({ success: true, stations });
  } catch (error) {
    console.error('获取所有充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 审核充电桩（通过/拒绝）
app.put('/api/admin/charging-stations/:id/review', async (req, res) => {
  try {
    const { status, reason } = req.body;
    
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ success: false, message: '无效的审核状态！' });
    }
    
    await db.query(
      'UPDATE charging_stations SET status = ? WHERE id = ?',
      [status, req.params.id]
    );
    
    console.log(`✅ 管理员审核: 充电桩ID=${req.params.id}, 结果=${status}`);
    res.json({ 
      success: true, 
      message: status === 'approved' ? '审核通过！' : '已拒绝该充电桩！' 
    });
  } catch (error) {
    console.error('审核充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取所有用户
app.get('/api/admin/users', async (req, res) => {
  try {
    const [users] = await db.query(
      'SELECT id, username, role, created_at FROM users ORDER BY created_at DESC'
    );
    
    res.json({ success: true, users });
  } catch (error) {
    console.error('获取用户列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取系统统计数据
app.get('/api/admin/stats', async (req, res) => {
  try {
    // 用户统计
    const [userStats] = await db.query(
      `SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN role = 'owner' THEN 1 ELSE 0 END) as owner_count,
        SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as user_count
       FROM users WHERE role != 'admin'`
    );
    
    // 充电桩统计
    const [stationStats] = await db.query(
      `SELECT 
        COUNT(*) as total_stations,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_count
       FROM charging_stations`
    );
    
    // 订单统计
    const [bookingStats] = await db.query(
      `SELECT 
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END), 0) as total_revenue
       FROM bookings`
    );
    
    res.json({
      success: true,
      stats: {
        users: userStats[0],
        stations: stationStats[0],
        bookings: bookingStats[0]
      }
    });
  } catch (error) {
    console.error('获取统计数据错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 获取所有订单（管理员视图）
app.get('/api/admin/bookings', async (req, res) => {
  try {
    const [bookings] = await db.query(
      `SELECT b.*, 
        cs.location, cs.type, cs.price,
        u.username as user_name,
        o.username as owner_name
       FROM bookings b
       LEFT JOIN charging_stations cs ON b.station_id = cs.id
       LEFT JOIN users u ON b.user_id = u.id
       LEFT JOIN users o ON cs.owner_id = o.id
       ORDER BY b.booking_time DESC
       LIMIT 100`
    );
    
    res.json({ success: true, bookings });
  } catch (error) {
    console.error('获取订单列表错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 删除充电桩（管理员权限）
app.delete('/api/admin/charging-stations/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM charging_stations WHERE id = ?', [req.params.id]);
    
    console.log(`✅ 管理员删除充电桩: ID=${req.params.id}`);
    res.json({ success: true, message: '充电桩删除成功！' });
  } catch (error) {
    console.error('删除充电桩错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// 删除用户（管理员权限）
app.delete('/api/admin/users/:id', async (req, res) => {
  try {
    // 不允许删除管理员账号
    const [users] = await db.query('SELECT role FROM users WHERE id = ?', [req.params.id]);
    
    if (users.length === 0) {
      return res.status(404).json({ success: false, message: '用户不存在！' });
    }
    
    if (users[0].role === 'admin') {
      return res.status(403).json({ success: false, message: '不能删除管理员账号！' });
    }
    
    await db.query('DELETE FROM users WHERE id = ?', [req.params.id]);
    
    console.log(`✅ 管理员删除用户: ID=${req.params.id}`);
    res.json({ success: true, message: '用户删除成功！' });
  } catch (error) {
    console.error('删除用户错误:', error);
    res.status(500).json({ success: false, message: '服务器错误！' });
  }
});

// ============ 地图服务API (新增) ============

const AMAP_WEB_KEY = 'daea1058ba61e34348d6d78d40041460'; // Web服务API Key

// 逆地理编码
app.get('/api/map/regeo', async (req, res) => {
  try {
    const { location } = req.query;
    
    if (!location) {
      return res.status(400).json({ success: false, message: '缺少location参数' });
    }

    const response = await axios.get('https://restapi.amap.com/v3/geocode/regeo', {
      params: {
        key: AMAP_WEB_KEY,
        location: location,
        radius: 1000
      }
    });

    res.json(response.data);
  } catch (error) {
    console.error('逆地理编码错误:', error);
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// ✅ 新增：地理编码（地址转坐标）
app.get('/api/map/geo', async (req, res) => {
  try {
    const { address } = req.query;
    
    if (!address) {
      return res.status(400).json({ success: false, message: '缺少address参数' });
    }

    const response = await axios.get('https://restapi.amap.com/v3/geocode/geo', {
      params: {
        key: AMAP_WEB_KEY,
        address: address
      }
    });

    res.json(response.data);
  } catch (error) {
    console.error('地理编码错误:', error);
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 路径规划（修改版：支持地址和坐标）
app.post('/api/map/route', async (req, res) => {
  try {
    let { origin, destination } = req.body;
    
    if (!origin || !destination) {
      return res.status(400).json({ success: false, message: '缺少起点或终点' });
    }

    console.log('📍 收到路径规划请求:', { origin, destination });

    // ✅ 检查是否是坐标格式（经度,纬度）
    const isCoordinate = (str) => /^[\d.]+,[\d.]+$/.test(str);

    // ✅ 如果不是坐标，先转换为坐标
    if (!isCoordinate(origin)) {
      console.log('🔄 起点是地址，转换为坐标:', origin);
      const geoResponse = await axios.get('https://restapi.amap.com/v3/geocode/geo', {
        params: {
          key: AMAP_WEB_KEY,
          address: origin
        }
      });

      if (geoResponse.data.status === '1' && geoResponse.data.geocodes.length > 0) {
        origin = geoResponse.data.geocodes[0].location;
        console.log('✅ 起点坐标:', origin);
      } else {
        return res.status(400).json({ 
          success: false, 
          message: '起点地址解析失败，请输入更详细的地址' 
        });
      }
    }

    if (!isCoordinate(destination)) {
      console.log('🔄 终点是地址，转换为坐标:', destination);
      const geoResponse = await axios.get('https://restapi.amap.com/v3/geocode/geo', {
        params: {
          key: AMAP_WEB_KEY,
          address: destination
        }
      });

      if (geoResponse.data.status === '1' && geoResponse.data.geocodes.length > 0) {
        destination = geoResponse.data.geocodes[0].location;
        console.log('✅ 终点坐标:', destination);
      } else {
        return res.status(400).json({ 
          success: false, 
          message: '终点地址解析失败，请输入更详细的地址' 
        });
      }
    }

    // ✅ 使用坐标进行路径规划
    const response = await axios.get('https://restapi.amap.com/v3/direction/driving', {
      params: {
        key: AMAP_WEB_KEY,
        origin: origin,
        destination: destination,
        strategy: 0, // 最短时间
        extensions: 'all' // 返回详细信息
      }
    });

    console.log('✅ 路径规划成功');
    res.json(response.data);
  } catch (error) {
    console.error('路径规划错误:', error);
    res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 404 处理
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'API 不存在' });
});

// 启动服务器
app.listen(PORT, () => {
  console.log('\n================================');
  console.log('⚡ 充电桩共享系统服务器');
  console.log('================================');
  console.log(`🚀 服务器运行在: http://localhost:${PORT}`);
  console.log(`📁 静态文件目录: ${path.join(__dirname, '..')}`);
  console.log('================================\n');
});