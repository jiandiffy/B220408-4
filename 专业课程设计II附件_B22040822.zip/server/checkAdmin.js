const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function checkAdmin() {
  let connection;
  try {
    connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'qazplm123',
      database: 'charging_station_db'
    });

    console.log('================================');
    console.log('  查看管理员账号信息');
    console.log('================================\n');

    const [admins] = await connection.query(
      'SELECT id, username, password, role, created_at FROM users WHERE role = ?',
      ['admin']
    );

    if (admins.length === 0) {
      console.log('❌ 没有找到管理员账号');
    } else {
      console.log('📋 管理员账号列表：\n');
      for (const admin of admins) {
        console.log(`ID: ${admin.id}`);
        console.log(`用户名: ${admin.username}`);
        console.log(`加密密码: ${admin.password.substring(0, 30)}...`);
        console.log(`创建时间: ${admin.created_at}`);
        
        // 测试密码
        const testPasswords = ['admin123', 'admin', '123456', 'qazplm123', 'password', ''];
        console.log('\n🔍 测试常用密码:');
        
        for (const pwd of testPasswords) {
          try {
            const isValid = await bcrypt.compare(pwd, admin.password);
            if (isValid) {
              console.log(`   ✅ 正确密码是: "${pwd}"`);
            } else {
              console.log(`   ❌ 不是: "${pwd}"`);
            }
          } catch (err) {
            console.log(`   ❌ 无法验证: "${pwd}"`);
          }
        }
        console.log('\n' + '─'.repeat(40) + '\n');
      }
    }

    console.log('💡 如果要重置密码，运行: node resetAdminPassword.js');
    
  } catch (error) {
    console.error('❌ 操作失败:', error.message);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

checkAdmin();