const mysql = require('mysql2/promise');

async function migrateDatabase() {
  let connection;
  try {
    console.log('================================');
    console.log('  数据库迁移 - 添加时间字段');
    console.log('================================\n');

    connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'qazplm123',
      database: 'charging_station_db'
    });

    console.log('✅ 连接数据库成功');

    // 检查 available_start_time 和 available_end_time 字段
    const [columns] = await connection.query(`
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = 'charging_station_db' 
      AND TABLE_NAME = 'charging_stations'
      AND COLUMN_NAME IN ('available_start_time', 'available_end_time')
    `);

    if (columns.length < 2) {
      console.log('📝 开始添加时间字段...');

      // 添加 available_start_time 字段
      if (!columns.find(c => c.COLUMN_NAME === 'available_start_time')) {
        await connection.query(`
          ALTER TABLE charging_stations 
          ADD COLUMN available_start_time TIME DEFAULT '00:00:00' 
          AFTER available_time
        `);
        console.log('✅ 添加 available_start_time 字段成功');
      }

      // 添加 available_end_time 字段
      if (!columns.find(c => c.COLUMN_NAME === 'available_end_time')) {
        await connection.query(`
          ALTER TABLE charging_stations 
          ADD COLUMN available_end_time TIME DEFAULT '23:59:59' 
          AFTER available_start_time
        `);
        console.log('✅ 添加 available_end_time 字段成功');
      }
    } else {
      console.log('ℹ️  时间字段已存在');
    }

    // 检查并添加 enable_peak_valley 字段
    const [peakValleyColumn] = await connection.query(`
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = 'charging_station_db' 
      AND TABLE_NAME = 'charging_stations'
      AND COLUMN_NAME = 'enable_peak_valley'
    `);

    if (peakValleyColumn.length === 0) {
      console.log('📝 开始添加峰谷电价字段...');
      await connection.query(`
        ALTER TABLE charging_stations 
        ADD COLUMN enable_peak_valley BOOLEAN DEFAULT FALSE 
        AFTER available_end_time
      `);
      console.log('✅ 添加 enable_peak_valley 字段成功');
    } else {
      console.log('ℹ️  enable_peak_valley 字段已存在');
    }

    // 验证迁移结果
    const [stations] = await connection.query(
      'SELECT id, location, available_time, available_start_time, available_end_time, enable_peak_valley FROM charging_stations LIMIT 5'
    );

    console.log('\n📊 迁移后的数据示例:');
    if (stations.length > 0) {
      stations.forEach(station => {
        console.log(`  ID: ${station.id}, 位置: ${station.location}`);
        console.log(`    可用时段文本: ${station.available_time || '全天'}`);
        console.log(`    开始时间: ${station.available_start_time}`);
        console.log(`    结束时间: ${station.available_end_time}`);
        console.log(`    峰谷电价: ${station.enable_peak_valley ? '启用' : '禁用'}`);
      });
    } else {
      console.log('  数据库中暂无充电桩数据');
    }

    console.log('\n================================');
    console.log('🎉 数据库迁移完成！');
    console.log('================================');
    console.log('\n提示:');
    console.log('- 现有数据已自动设置为全天可用 (00:00:00 - 23:59:59)');
    console.log('- 峰谷电价功能默认关闭');
    console.log('- 如需修改，请在桩主界面重新编辑。\n');

  } catch (error) {
    console.error('\n❌ 数据库迁移失败:', error.message);
    console.error('详细错误:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
    process.exit(0);
  }
}

migrateDatabase();
