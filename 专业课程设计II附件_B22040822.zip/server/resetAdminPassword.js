const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function resetAdminPassword() {
  let connection;
  try {
    console.log('================================');
    console.log('  重置管理员密码');
    console.log('================================\n');

    connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'qazplm123',
      database: 'charging_station_db'
    });

    console.log('✅ 连接数据库成功\n');

    // 检查管理员是否存在
    const [admins] = await connection.query(
      'SELECT * FROM users WHERE username = ? AND role = ?',
      ['admin', 'admin']
    );

    const newPassword = 'admin123';
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    if (admins.length > 0) {
      // 更新现有管理员密码
      await connection.query(
        'UPDATE users SET password = ? WHERE username = ? AND role = ?',
        [hashedPassword, 'admin', 'admin']
      );
      console.log('✅ 管理员密码已更新');
    } else {
      // 创建新管理员
      await connection.query(
        'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
        ['admin', hashedPassword, 'admin']
      );
      console.log('✅ 管理员账号已创建');
    }

    console.log('\n📋 新的管理员登录信息：');
    console.log('   ┌─────────────────────────┐');
    console.log('   │ 用户名：admin           │');
    console.log('   │ 密码：  admin123        │');
    console.log('   │ 角色：  管理员          │');
    console.log('   └─────────────────────────┘');

    // 验证密码
    const [verifyAdmin] = await connection.query(
      'SELECT * FROM users WHERE username = ?',
      ['admin']
    );

    if (verifyAdmin.length > 0) {
      const isValid = await bcrypt.compare(newPassword, verifyAdmin[0].password);
      console.log('\n🔍 密码验证结果：', isValid ? '✅ 成功' : '❌ 失败');
      
      if (isValid) {
        console.log('\n🎉 现在可以使用以下信息登录：');
        console.log('   http://localhost:3000/login.html');
      }
    }

    console.log('\n================================');
    console.log('✅ 操作完成！');
    console.log('================================\n');
    
  } catch (error) {
    console.error('\n❌ 操作失败:', error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
    process.exit(0);
  }
}

resetAdminPassword();