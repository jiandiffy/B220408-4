const mysql = require('mysql2');

// 数据库配置
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'qazplm123',
  database: 'charging_station_db',
  port: 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  timezone: '+08:00'
};

// 创建连接池
const pool = mysql.createPool(dbConfig);

// 测试连接
pool.getConnection((err, connection) => {
  if (err) {
    console.error('\n❌ 数据库连接失败:', err.message);
    return;
  }
  console.log('\n✅ 数据库连接成功！');
  console.log(`   → 主机: ${dbConfig.host}:${dbConfig.port}`);
  console.log(`   → 数据库: ${dbConfig.database}\n`);
  connection.release();
});

const promisePool = pool.promise();

module.exports = promisePool;