const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function resetDatabase() {
  let connection;
  try {
    console.log('================================');
    console.log('  数据库重置');
    console.log('================================\n');

    connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'qazplm123',
      database: 'charging_station_db'
    });

    console.log('✅ 连接数据库成功');

    // 确认操作
    console.log('\n⚠️  警告：此操作将删除所有数据！');
    console.log('⚠️  包括：用户、充电桩、订单、收益、评价、纠纷等所有记录');
    console.log('\n请在5秒内按 Ctrl+C 取消...\n');

    await new Promise(resolve => setTimeout(resolve, 5000));

    // 禁用外键检查
    await connection.query('SET FOREIGN_KEY_CHECKS = 0');
    console.log('✅ 禁用外键检查');

    // 清空所有表
    const tables = ['disputes', 'reviews', 'revenues', 'bookings', 'charging_stations', 'users'];
    
    for (const table of tables) {
      await connection.query(`TRUNCATE TABLE ${table}`);
      console.log(`✅ 清空表: ${table}`);
    }

    // 启用外键检查
    await connection.query('SET FOREIGN_KEY_CHECKS = 1');
    console.log('✅ 启用外键检查');

    // 重新创建管理员账号
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await connection.query(
      'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
      ['admin', hashedPassword, 'admin']
    );
    console.log('✅ 管理员账号重新创建');
    console.log('   用户名: admin');
    console.log('   密码: admin123');

    console.log('\n================================');
    console.log('🎉 数据库重置完成！');
    console.log('================================');
    console.log('\n💡 提示:');
    console.log('   - 所有数据已清空');
    console.log('   - 管理员账号已重置');
    console.log('   - 可以开始全新测试了！\n');
    
  } catch (error) {
    console.error('\n❌ 数据库重置失败:', error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
    process.exit(0);
  }
}

resetDatabase();
