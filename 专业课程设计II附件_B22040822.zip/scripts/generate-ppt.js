/* 生成：充电桩共享平台-功能展示.pptx */
const PptxGenJS = require('pptxgenjs');

const FONT = 'Microsoft YaHei';
const TITLE_COLOR = '203764'; // 深蓝
const ACCENT = '2E75B6';     // 蓝色
const SUBTLE = '7F7F7F';

function addTitle(slide, title, subtitle) {
  slide.addText(title, { x: 0.5, y: 0.6, w: 9, h: 1, bold: true, fontSize: 36, color: TITLE_COLOR, fontFace: FONT });
  if (subtitle) {
    slide.addText(subtitle, { x: 0.55, y: 1.5, w: 9, h: 0.6, fontSize: 18, color: SUBTLE, fontFace: FONT });
  }
}

function addSectionTitle(slide, text) {
  slide.addText(text, { x: 0.5, y: 0.5, w: 9, h: 0.8, bold: true, fontSize: 28, color: TITLE_COLOR, fontFace: FONT });
}

function addBullets(slide, items, x = 0.7, y = 1.3) {
  slide.addText(
    items.map(t => ({ text: t, options: { bullet: true, fontSize: 20, fontFace: FONT, color: '000000', lineSpacing: 20 } })),
    { x, y, w: 9.2, h: 5 }
  );
}

(async function main() {
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_16x9'; // 修复：使用预设常量

  // 封面
  let slide = pptx.addSlide();
  addTitle(slide, '充电桩共享平台 - 功能展示', '系统角色与核心流程概览');
  slide.addText('日期：2025-10-30', { x: 0.55, y: 2.1, fontSize: 14, color: SUBTLE, fontFace: FONT });
  slide.addShape(pptx.ShapeType.rect, { x: 0, y: 6.7, w: 13.33, h: 1, fill: { color: ACCENT } });

  // 概览
  slide = pptx.addSlide();
  addSectionTitle(slide, '一、系统概览');
  addBullets(slide, [
    '角色：用户 / 桩主 / 管理员',
    '目标：搜索、预约、充电、计费、评价、纠纷、审核与统计',
    '特色：峰谷电价计费、并发预约防护、地图导航、后台监管'
  ]);

  // 角色与职责
  slide = pptx.addSlide();
  addSectionTitle(slide, '二、系统角色与职责');
  addBullets(slide, [
    '用户：搜索→预约→开始/结束充电→支付→评价/投诉',
    '桩主：发布/管理充电桩、远程电源控制、收益统计与明细',
    '管理员：充电桩审核、用户管理、订单监控、纠纷处理、统计面板'
  ]);

  // 用户功能
  slide = pptx.addSlide();
  addSectionTitle(slide, '三、用户端核心功能');
  addBullets(slide, [
    '充电桩搜索与筛选（类型/价格/距离/评分）',
    '实时可用性检查与预约冲突检测',
    '开始/结束充电，前端秒级计时与费用预估',
    '峰谷电价分段计费，订单历史与统计',
    '订单完成后的评价与投诉'
  ]);

  // 桩主功能
  slide = pptx.addSlide();
  addSectionTitle(slide, '四、桩主端核心功能');
  addBullets(slide, [
    '发布/编辑充电桩（功率、价格、可用时段、峰谷电价）',
    '远程电源开关（对接硬件API时）',
    '收益统计与明细导出'
  ]);

  // 管理后台
  slide = pptx.addSlide();
  addSectionTitle(slide, '五、管理后台');
  addBullets(slide, [
    '充电桩审核（通过/拒绝，记录原因）',
    '用户管理（软删除、限制进行中订单删除）',
    '订单监控（状态筛选、收益统计、趋势图）',
    '纠纷处理（pending/resolved/rejected，管理员回复记录）'
  ]);

  // 关键流程：搜索与预约
  slide = pptx.addSlide();
  addSectionTitle(slide, '六、关键流程：搜索与预约');
  addBullets(slide, [
    '多条件检索与评分排序，地图联动',
    '可用性判定：状态、电源、时间段、并发冲突',
    '并发保障：事务 + 行级锁（FOR UPDATE）'
  ]);

  // 关键流程：充电与计费
  slide = pptx.addSlide();
  addSectionTitle(slide, '七、关键流程：充电与计费（峰谷电价）');
  addBullets(slide, [
    '到场后开始充电 → 前端计时与费用预估',
    '结束充电 → 后端分段计费（峰/平/谷）并入账',
    '状态机：pending → charging → completed/cancelled'
  ]);

  // 自动结束策略
  slide = pptx.addSlide();
  addSectionTitle(slide, '八、自动结束策略（可选）');
  addBullets(slide, [
    '周期扫描超时订单并自动结束（node-cron/队列）',
    '避免单进程 setTimeout；支持硬件断电回调',
    '可按 reserved_end_time 或最大时长参数执行'
  ]);

  // 评价与纠纷
  slide = pptx.addSlide();
  addSectionTitle(slide, '九、评价与纠纷');
  addBullets(slide, [
    '评价：完成订单后限一次评价；影响搜索排序（评分+数量权重）',
    '纠纷：提交→管理员处理→结果通知；全流程记录与统计'
  ]);

  // 地图与导航
  slide = pptx.addSlide();
  addSectionTitle(slide, '十、地图与导航（高德API）');
  addBullets(slide, [
    '地理编码/逆地理编码、路径规划、定位',
    '性能优化：标记聚合/按视野加载/结果缓存',
    '一键在高德地图App中打开导航'
  ]);

  // 架构与接口
  slide = pptx.addSlide();
  addSectionTitle(slide, '十一、架构与接口');
  addBullets(slide, [
    '前端：用户端/桩主端/管理员端（VS Code + 浏览器）',
    '后端：Express API，MySQL 持久化，静态资源服务',
    '核心接口：充电桩、预约/订单、评价、纠纷、统计、地图代理'
  ]);

  // 演示脚本
  slide = pptx.addSlide();
  addSectionTitle(slide, '十二、演示脚本（5–8分钟）');
  addBullets(slide, [
    '搜索并预约 → 到场开始充电 → 结束计费与收益',
    '提交评价或投诉 → 管理后台审核/处理',
    '展示统计与趋势 →（可选）演示自动结束日志'
  ]);

  // FAQ
  slide = pptx.addSlide();
  addSectionTitle(slide, '十三、常见问题');
  addBullets(slide, [
    '是否自动结束？默认不自动，可配置周期扫描与硬件联动',
    '并发预约如何保证？数据库事务 + FOR UPDATE',
    '峰谷电价如何验证？分段计算与示例校验'
  ]);

  // Roadmap
  slide = pptx.addSlide();
  addSectionTitle(slide, '十四、后续增强');
  addBullets(slide, [
    '任务队列（Bull + Redis）保证自动结束可靠性',
    '支付/退款对接与风控',
    '管理员审计与回滚、更多硬件适配层',
    '自动化测试与 CI'
  ]);

  // 封底
  slide = pptx.addSlide();
  addTitle(slide, '感谢观看', 'Q&A');
  slide.addShape(pptx.ShapeType.rect, { x: 0, y: 6.7, w: 13.33, h: 1, fill: { color: ACCENT } });

  await pptx.writeFile({ fileName: '充电桩共享平台-功能展示.pptx' });
  console.log('✅ 已生成：充电桩共享平台-功能展示.pptx');
})().catch(err => {
  console.error('❌ 生成PPT失败：', err);
});